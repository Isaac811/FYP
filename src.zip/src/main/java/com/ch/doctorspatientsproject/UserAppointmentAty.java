package com.ch.doctorspatientsproject;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.ch.doctorspatientsproject.adapters.RvAppointmentDoctorAdapter;
import com.ch.doctorspatientsproject.beans.AppointmentBean;
import com.ch.doctorspatientsproject.beans.DoctorBean;
import com.ch.doctorspatientsproject.widget.StatusBarCommonTitleWidget;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.List;
import java.util.UUID;


public class UserAppointmentAty extends AppCompatActivity implements StatusBarCommonTitleWidget.OnClickBackListener, RvAppointmentDoctorAdapter.AppointmentListener {

    private FirebaseFirestore db;
    private CollectionReference userCollection;

    private StatusBarCommonTitleWidget ctv;
    private RecyclerView rcv;
    private RvAppointmentDoctorAdapter adapter;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.aty_appointment_layout);

        db = FirebaseFirestore.getInstance();
        userCollection = db.collection("_user");

        ctv = findViewById(R.id.cvTilteCustom);
        ctv.isHiddenCloseBtn();
        ctv.setLeftContent("");
        ctv.setMiddelContent("Appointment");
        ctv.setOnClickBackListener(this);

        rcv = findViewById(R.id.rv_appointment);

        userCollection
                .whereEqualTo("role", "medic")
                .get().addOnSuccessListener(queryDocumentSnapshots -> {

                    Log.e("fk", "queryDocumentSnapshots " + queryDocumentSnapshots.isEmpty());
                    if (queryDocumentSnapshots.isEmpty()) {
                        return;
                    }
                    List<DoctorBean> doctorBeans = queryDocumentSnapshots.toObjects(DoctorBean.class);

                    Log.e("fk", "queryDocumentSnapshots " + doctorBeans.size());

                    if (adapter == null) {
                        adapter = new RvAppointmentDoctorAdapter(doctorBeans, UserAppointmentAty.this);
                        adapter.setAppointmentListener(UserAppointmentAty.this);
                        rcv.setLayoutManager(new LinearLayoutManager(UserAppointmentAty.this));
                        rcv.setAdapter(adapter);
                    } else {
                        adapter.notifyDataSetChanged();
                    }
                });
    }

    @Override
    public void appointment(DoctorBean doctorBean) {

        AppointmentBean bean = new AppointmentBean();
        bean.setAppoint_id(UUID.randomUUID().toString());
        bean.setDoctor_id(doctorBean.getId());
        bean.setDoctor_name(doctorBean.getUsername());
        bean.setUser_id(ParameterInfo.userBean.getId());
        bean.setUser_name(ParameterInfo.userBean.getUsername());

        Intent intent =new Intent(UserAppointmentAty.this,AppointmentConfirmAty.class);
        Bundle bundle =new Bundle();
        bundle.putParcelable("doctor",bean);
        intent.putExtras(bundle);
        startActivity(intent);
    }

    @Override
    public void OnClickBack() {
        finish();
    }

    @Override
    public void OnClickFinch() {
        finish();
    }


}
