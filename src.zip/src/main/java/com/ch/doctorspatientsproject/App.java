package com.ch.doctorspatientsproject;

import android.app.Application;

import com.ch.doctorspatientsproject.beans.UserBean;

public class App extends Application {

    public static UserBean loginUser;

    @Override
    public void onCreate() {
        super.onCreate();
    }
}
