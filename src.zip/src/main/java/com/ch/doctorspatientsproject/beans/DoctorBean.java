package com.ch.doctorspatientsproject.beans;

public class DoctorBean extends UserBean {
}
