package com.ch.doctorspatientsproject.beans;

import android.text.TextUtils;

import java.io.Serializable;

public class AppointmentBean implements Serializable {
    private String appoint_id;
    private String doctor_id;
    private String doctor_name;
    private String doctor_gender;
    private String user_id;
    private String user_name;
    private String user_email;

    private String appoint_date;
    private String appoint_time;
    private String appoint_remark;
    private String inquiry;
    private String prescribe;
    private String is_complete;
    private String is_record;
    private String userTemp;
    private String userPress;

    private String prescribeDate;
    private String prescribeDosage;
    private String prescribeIns;

    private String date_id;

    public String getAppoint_id() {
        return appoint_id;
    }

    public void setAppoint_id(String appoint_id) {
        this.appoint_id = appoint_id;
    }

    public String getDoctor_id() {
        return doctor_id;
    }

    public void setDoctor_id(String doctor_id) {
        this.doctor_id = doctor_id;
    }

    public String getDoctor_name() {
        return doctor_name;
    }

    public void setDoctor_name(String doctor_name) {
        this.doctor_name = doctor_name;
    }

    public String getDoctor_gender() {
        return doctor_gender;
    }

    public void setDoctor_gender(String doctor_gender) {
        this.doctor_gender = doctor_gender;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getUser_name() {
        return user_name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public String getUser_email() {
        return user_email;
    }

    public void setUser_email(String user_email) {
        this.user_email = user_email;
    }

    public String getAppoint_date() {
        return appoint_date;
    }

    public void setAppoint_date(String appoint_date) {
        this.appoint_date = appoint_date;
    }

    public String getAppoint_time() {
        return appoint_time;
    }

    public void setAppoint_time(String appoint_time) {
        this.appoint_time = appoint_time;
    }

    public String getAppoint_remark() {
        return appoint_remark;
    }

    public void setAppoint_remark(String appoint_remark) {
        this.appoint_remark = appoint_remark;
    }

    public String getInquiry() {
        return inquiry;
    }

    public void setInquiry(String inquiry) {
        this.inquiry = inquiry;
    }

    public String getPrescribe() {
        return prescribe;
    }

    public void setPrescribe(String prescribe) {
        this.prescribe = prescribe;
    }

    public String getIs_complete() {
        return is_complete;
    }

    public void setIs_complete(String is_complete) {
        this.is_complete = is_complete;
    }

    public String getIs_record() {
        return is_record;
    }

    public void setIs_record(String is_record) {
        this.is_record = is_record;
    }

    public String getUserTemp() {
        if (TextUtils.isEmpty(userTemp)) {
            return "";
        }
        return userTemp;
    }

    public void setUserTemp(String userTemp) {
        this.userTemp = userTemp;
    }

    public String getUserPress() {
        if (TextUtils.isEmpty(userPress)) {
            return "";
        }
        return userPress;
    }

    public void setUserPress(String userPress) {
        this.userPress = userPress;
    }

    public String getPrescribeDate() {
        return prescribeDate;
    }

    public void setPrescribeDate(String prescribeDate) {
        this.prescribeDate = prescribeDate;
    }

    public String getPrescribeDosage() {
        return prescribeDosage;
    }

    public void setPrescribeDosage(String prescribeDosage) {
        this.prescribeDosage = prescribeDosage;
    }

    public String getPrescribeIns() {
        return prescribeIns;
    }

    public void setPrescribeIns(String prescribeIns) {
        this.prescribeIns = prescribeIns;
    }

    public String getDate_id() {
        return date_id;
    }

    public void setDate_id(String date_id) {
        this.date_id = date_id;
    }
}
