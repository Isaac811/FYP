package com.ch.doctorspatientsproject.beans;

import java.io.Serializable;


public class AppointDateBean implements Serializable {

    private String date_id;
    private String doctor_time;
    private String doctor_date;
    private String doctor_id;
    private String is_appoint;

    public String getDate_id() {
        return date_id;
    }

    public void setDate_id(String date_id) {
        this.date_id = date_id;
    }

    public String getDoctor_time() {
        return doctor_time;
    }

    public void setDoctor_time(String doctor_time) {
        this.doctor_time = doctor_time;
    }

    public String getDoctor_date() {
        return doctor_date;
    }

    public void setDoctor_date(String doctor_date) {
        this.doctor_date = doctor_date;
    }

    public String getDoctor_id() {
        return doctor_id;
    }

    public void setDoctor_id(String doctor_id) {
        this.doctor_id = doctor_id;
    }

    public String getIs_appoint() {
        return is_appoint;
    }

    public void setIs_appoint(String is_appoint) {
        this.is_appoint = is_appoint;
    }
}
