package com.ch.doctorspatientsproject.beans;

public class RespCommentBean {

    private String id;
    private String comment_text;
    private String comment_date;
    private String comment_doctor_id;
    private String comment_uid;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getComment_text() {
        return comment_text;
    }

    public void setComment_text(String comment_text) {
        this.comment_text = comment_text;
    }

    public String getComment_date() {
        return comment_date;
    }

    public void setComment_date(String comment_date) {
        this.comment_date = comment_date;
    }

    public String getComment_doctor_id() {
        return comment_doctor_id;
    }

    public void setComment_doctor_id(String comment_doctor_id) {
        this.comment_doctor_id = comment_doctor_id;
    }

    public String getComment_uid() {
        return comment_uid;
    }

    public void setComment_uid(String comment_uid) {
        this.comment_uid = comment_uid;
    }
}
