package com.ch.doctorspatientsproject.ui.mine;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.ch.doctorspatientsproject.MyAppointmentAty;
import com.ch.doctorspatientsproject.ParameterInfo;
import com.ch.doctorspatientsproject.SelCaseAty;
import com.ch.doctorspatientsproject.UserAppointmentAty;
import com.ch.doctorspatientsproject.UserConsultationAty;
import com.ch.doctorspatientsproject.adapters.RvAppointmentDoctorAdapter;
import com.ch.doctorspatientsproject.beans.AppointmentBean;
import com.ch.doctorspatientsproject.beans.ChatRoom;
import com.ch.doctorspatientsproject.beans.DoctorBean;
import com.ch.doctorspatientsproject.databinding.FragmentMineBinding;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.List;

public class MineFragment extends Fragment {

    private FirebaseFirestore db;
    private CollectionReference userCollection;

    private FragmentMineBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentMineBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        db = FirebaseFirestore.getInstance();
        userCollection = db.collection("appointment");

        binding.txtUsername.setText(ParameterInfo.userBean.getUsername());
        binding.txtRoleType.setText(ParameterInfo.userBean.getRole());
        getAppointmentCount();
        getConsultationCount();
        binding.yuYueRLLyt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), MyAppointmentAty.class);
                startActivity(intent);
            }
        });

        binding.kefuRLLyt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), UserConsultationAty.class);
                startActivity(intent);
            }
        });

        binding.outlogin.setOnClickListener(v -> getActivity().finish());
        return root;
    }


    private void getAppointmentCount() {
        Log.e("fk", "getId= " + ParameterInfo.userBean.getId());
        userCollection
                .whereEqualTo("user_id", ParameterInfo.userBean.getId())
                .get().addOnSuccessListener(queryDocumentSnapshots -> {
                    Log.e("fk", "queryDocumentSnapshots " + queryDocumentSnapshots.isEmpty());
                    if (queryDocumentSnapshots.isEmpty()) {
                        return;
                    }
                    List<AppointmentBean> doctorBeans = queryDocumentSnapshots.toObjects(AppointmentBean.class);

                    Log.e("fk", "doctorBeans " + doctorBeans.size());
                    // appointment count
                    binding.parentUserNameTxt.setText(String.valueOf(doctorBeans.size()));
                });


    }

    private void getConsultationCount() {
        Log.e("fk", "getId= " + ParameterInfo.userBean.getId());
        db.collection("chatRoom")
                .whereEqualTo("userId", ParameterInfo.userBean.getUsername())
                .get().addOnSuccessListener(queryDocumentSnapshots -> {
                    Log.e("fk", "queryDocumentSnapshots " + queryDocumentSnapshots.isEmpty());
                    if (queryDocumentSnapshots.isEmpty()) {
                        return;
                    }
                    List<ChatRoom> doctorBeans = queryDocumentSnapshots.toObjects(ChatRoom.class);

                    Log.e("fk", "doctorBeans " + doctorBeans.size());
                    // appointment count
                    binding.tvConsultation.setText(String.valueOf(doctorBeans.size()));
                });


    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        if (!hidden) {
            getAppointmentCount();
            getConsultationCount();
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}