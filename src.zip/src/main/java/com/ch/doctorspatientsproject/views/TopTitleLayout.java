package com.ch.doctorspatientsproject.views;

import android.app.Activity;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.ch.doctorspatientsproject.R;

public class TopTitleLayout extends LinearLayout {
    public TopTitleLayout(Context context) {
        super(context);
        init(context, null);
    }

    public TopTitleLayout(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init(context, attrs);
    }

    public TopTitleLayout(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context, attrs);
    }

    public TopTitleLayout(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        init(context, attrs);
    }

    private String title;
    private ImageView iv_top_back;
    private TextView tv_top_title;

    private void init(Context context, AttributeSet attrs) {
        LayoutInflater.from(context).inflate(R.layout.view_item_top_title, this);
        iv_top_back = findViewById(R.id.iv_top_back);
        tv_top_title = findViewById(R.id.tv_top_title);

        TypedArray typedArray = getContext().obtainStyledAttributes(attrs, R.styleable.TopTitleLayout);
        setTitle(typedArray.getString(R.styleable.TopTitleLayout_top_title));
        typedArray.recycle();
    }

    public void setTitle(String title) {
        this.title = title;
        tv_top_title.setText(title);
    }

    public void setBackEnable(Activity activity) {
        iv_top_back.setVisibility(VISIBLE);
        iv_top_back.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                activity.finish();
            }
        });
    }
}
