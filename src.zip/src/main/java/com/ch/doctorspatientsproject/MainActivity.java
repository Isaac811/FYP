package com.ch.doctorspatientsproject;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.widget.Toast;

import com.ch.doctorspatientsproject.systembar.ImmersiveBarUtil;
import com.ch.doctorspatientsproject.ui.chart.ChartFragment;
import com.ch.doctorspatientsproject.ui.home.DoctorFragment;
import com.ch.doctorspatientsproject.ui.home.HomeFragment;
import com.ch.doctorspatientsproject.ui.interrogation.InterrogationFragment;
import com.ch.doctorspatientsproject.ui.mine.DoctorMineFragment;
import com.ch.doctorspatientsproject.ui.mine.MineFragment;
import com.ch.doctorspatientsproject.ui.weather.WeatherFragment;
import com.ch.doctorspatientsproject.utils.IntentActionUtil;
import com.ch.doctorspatientsproject.widget.CustomTabLayoutWidget;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.ch.doctorspatientsproject.databinding.ActivityMainBinding;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements CustomTabLayoutWidget.OnTabClickListener {

    public static MainActivity instance;
    /**
     * The module index
     */
    public static final int MODULEIDX_HOME = 0;
    public static final int MODULEIDX_PERSONCENTER = 1;
    public static final int MODULEIDX_COMMENT = 2;
    public static final int MODULEIDX_WEATHER = 3;
    public static final int MODULEIDX_CHART = 4;

    public static int moduleIdx = -1;
    private boolean[] fragmentsLiveStatus = new boolean[]{false, false, false, false, false};
    /**
     * Fragments
     */
    private Fragment homeFragment, randomFragment, mineFragment, weatherFragment, chartFragment;
    /**
     * Switch module
     */
    private BroadcastReceiver changeModuleReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            changeModule(intent.getIntExtra(getString(R.string.data), MODULEIDX_HOME));
        }
    };
    /**
     * Secondary exit
     */
    private CountDownTimer timer;
    private boolean isPreExit;
    public boolean isExiting;
    public CustomTabLayoutWidget mTabLayout;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ImmersiveBarUtil.immersiveImageBar(this);
        instance = this;
        // TabLayout
        ArrayList<CustomTabLayoutWidget.Tab> tabs = new ArrayList<>();
        tabs.add(new CustomTabLayoutWidget.Tab(R.drawable.selector_aty_main_tab_home, R.string.main_home, MODULEIDX_HOME));
        tabs.add(new CustomTabLayoutWidget.Tab(R.drawable.selector_aty_main_tab_notice, R.string.main_comment, MODULEIDX_COMMENT));
        tabs.add(new CustomTabLayoutWidget.Tab(R.drawable.selector_aty_main_tab_notice, R.string.main_tips, MODULEIDX_WEATHER));
        // tabs.add(new CustomTabLayoutWidget.Tab(R.drawable.selector_aty_main_tab_notice, R.string.main_chart, MODULEIDX_CHART));
        tabs.add(new CustomTabLayoutWidget.Tab(R.drawable.selector_aty_main_tab_mine, R.string.main_mine, MODULEIDX_PERSONCENTER));
        mTabLayout = findViewById(R.id.mTabLayout);
        mTabLayout.setUpData(tabs, this);
        mTabLayout.setCurrentTab(MODULEIDX_HOME);

        IntentFilter filter = new IntentFilter(IntentActionUtil.ACTION_CHANGE_MODULE);
        registerReceiver(changeModuleReceiver, filter);
        for (int i = 0; i < fragmentsLiveStatus.length; i++) {
            removeFragment(i);
        }

        changeModule(MODULEIDX_HOME);
        // Exit
        timer = new CountDownTimer(5000, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
            }

            @Override
            public void onFinish() {
                isPreExit = false;
            }
        };
    }


    @Override
    public void onTabClick(CustomTabLayoutWidget.Tab tab) {
        changeModule(tab.badgeCount);
    }

    public void changeModule(int... index) {
        // Main Content
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        hideCurFragment(transaction, moduleIdx);
        switch (index[0]) {
            case MODULEIDX_HOME:
                if (homeFragment == null) {
                    if ("medic".equals(ParameterInfo.userBean.getRole())) {
                        homeFragment = new DoctorFragment();
                    } else {
                        homeFragment = new HomeFragment();
                    }
                    transaction.replace(R.id.main_home, homeFragment, String.valueOf(MODULEIDX_HOME));
                } else {
                    transaction.show(homeFragment);
                }
                break;
            case MODULEIDX_COMMENT:
                if (randomFragment == null) {
                    randomFragment = new InterrogationFragment();
                    transaction.replace(R.id.main_comment, randomFragment, String.valueOf(MODULEIDX_COMMENT));
                } else {
                    transaction.show(randomFragment);
                }
                break;
            case MODULEIDX_PERSONCENTER:
                if (mineFragment == null) {
                    if ("medic".equals(ParameterInfo.userBean.getRole())) {
                        mineFragment = new DoctorMineFragment();
                    } else {
                        mineFragment = new MineFragment();
                    }
                    transaction.replace(R.id.main_mine, mineFragment, String.valueOf(MODULEIDX_PERSONCENTER));
                } else {
                    transaction.show(mineFragment);
                }
                break;
            case MODULEIDX_CHART:
                if (chartFragment == null) {
                    chartFragment = new ChartFragment();
                    transaction.replace(R.id.main_chart, chartFragment, String.valueOf(MODULEIDX_CHART));
                } else {
                    transaction.show(chartFragment);
                }
                break;
            case MODULEIDX_WEATHER:
                if (weatherFragment == null) {
                    weatherFragment = new WeatherFragment();
                    transaction.replace(R.id.main_weather, weatherFragment, String.valueOf(MODULEIDX_WEATHER));
                } else {
                    transaction.show(weatherFragment);
                }
                break;
            default:
                break;
        }
        transaction.commitAllowingStateLoss();
        moduleIdx = index[0];
    }


    private void hideCurFragment(FragmentTransaction transaction, int idx) {
        switch (idx) {
            case MODULEIDX_HOME:
                if (homeFragment != null) {
                    transaction.hide(homeFragment);
                }
                break;
            case MODULEIDX_COMMENT:
                if (randomFragment != null) {
                    transaction.hide(randomFragment);
                }
                break;
            case MODULEIDX_PERSONCENTER:
                if (mineFragment != null) {
                    transaction.hide(mineFragment);
                }
                break;
            case MODULEIDX_CHART:
                if (chartFragment != null) {
                    transaction.hide(chartFragment);
                }
                break;
            case MODULEIDX_WEATHER:
                if (weatherFragment != null) {
                    transaction.hide(weatherFragment);
                }
                break;
            default:
                break;
        }
    }

    public void removeFragment(int moduleIdx) {
        FragmentManager manager = getSupportFragmentManager();
        Fragment f = manager.findFragmentByTag(String.valueOf(moduleIdx));
        if (f != null) {
            manager.beginTransaction().remove(f).commit();
        }
    }


    @Override
    public void onBackPressed() {
        if (!isPreExit) {
            isPreExit = true;
            Toast.makeText(this, getString(R.string.exit), Toast.LENGTH_LONG).show();
            timer.start();
        } else {
            isExiting = true;
            timer.cancel();
            finish();
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        List<Fragment> fragments = getSupportFragmentManager().getFragments();
        if (fragments == null) {
            return;
        }
        for (Fragment fragment : fragments) {
            if (fragment != null) {
                fragment.onRequestPermissionsResult(requestCode, permissions, grantResults);
            }
        }
    }
}