package com.ch.doctorspatientsproject;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.ch.doctorspatientsproject.beans.AppointmentBean;
import com.ch.doctorspatientsproject.widget.StatusBarCommonTitleWidget;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.SimpleDateFormat;
import java.util.Date;

public class SelCaseAty extends AppCompatActivity implements StatusBarCommonTitleWidget.OnClickBackListener {

    private StatusBarCommonTitleWidget ctv;

    private FirebaseFirestore db;
    private CollectionReference userCollection;

    private TextView tvDate;
    private TextView tvDoctor;
    private EditText etRemark;
    private TextView tv_prescribe;
    private EditText etCase;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.aty_sel_case_layout);

        ctv = findViewById(R.id.cvTilteCustom);
        ctv.isHiddenCloseBtn();
        ctv.setLeftContent("");
        ctv.setMiddelContent("My Appointment");
        ctv.setOnClickBackListener(this);

        AppointmentBean bean = getIntent().getExtras().getParcelable("doctor");

        db = FirebaseFirestore.getInstance();
        userCollection = db.collection("_user");

        tvDate = findViewById(R.id.tv_date);

        tvDate.setText("Date：" + bean.getAppoint_date() + "-" + bean.getAppoint_time());

        tvDoctor = findViewById(R.id.tv_doctor);
        tvDoctor.setText("Doctor：" + bean.getDoctor_name());

        etRemark = findViewById(R.id.et_remark);
        etRemark.setText("Remark：" + bean.getAppoint_remark());

        etCase = findViewById(R.id.et_case);
        etCase.setText(bean.getInquiry());

        tv_prescribe = findViewById(R.id.tv_prescribe);
        tv_prescribe.setText("prescribe: "+bean.getPrescribe());


    }

    @Override
    public void OnClickBack() {
        finish();
    }

    @Override
    public void OnClickFinch() {
        finish();
    }

}
