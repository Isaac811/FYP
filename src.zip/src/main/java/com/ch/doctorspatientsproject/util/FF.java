package com.ch.doctorspatientsproject.util;

public class FF {
    public static final String USER = "_user";
    public static final String APPOINTMENT = "appointment";
    public static final String CHAT_ROOM = "chatRoom";
    public static final String COMMENT = "comment";
    public static final String DOCTOR_APPOINT_DATE = "doctor_appoint_date";
    public static final String MESSAGES = "messages";
}
