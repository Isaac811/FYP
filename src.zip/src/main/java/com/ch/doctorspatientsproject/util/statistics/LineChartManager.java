package com.ch.doctorspatientsproject.util.statistics;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.Drawable;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.listener.OnChartValueSelectedListener;

import java.util.ArrayList;
import java.util.List;

public class LineChartManager {

    private LineChart lineChart;
    private XAxis xAxis;
    private YAxis leftYAxis;
    private YAxis rightYAxis;
    private Legend legend;
    private Context mContext;


    public LineChartManager(LineChart lineChart, Context mContext) {
        this.lineChart = lineChart;
        leftYAxis = lineChart.getAxisLeft();
        rightYAxis = lineChart.getAxisRight();
        xAxis = lineChart.getXAxis();
        this.mContext = mContext;
        initChart(lineChart);
    }


    private void initChart(LineChart lineChart) {

        lineChart.setDrawGridBackground(false);
        lineChart.setBackgroundColor(Color.WHITE);
        lineChart.setDrawBorders(false);
        lineChart.setDoubleTapToZoomEnabled(false);
        Description description = new Description();
        description.setEnabled(false);
        lineChart.setDescription(description);
        xAxis = lineChart.getXAxis();
        leftYAxis = lineChart.getAxisLeft();
        rightYAxis = lineChart.getAxisRight();

        xAxis.setDrawGridLines(false);
        rightYAxis.setDrawGridLines(false);
        rightYAxis.setGridColor(Color.parseColor("#e6e6e6"));
        rightYAxis.setGridLineWidth(1f);
        leftYAxis.setDrawGridLines(true);
        leftYAxis.setGridColor(Color.parseColor("#e6e6e6"));
        leftYAxis.setGridLineWidth(1f);
        leftYAxis.enableGridDashedLine(10f, 10f, 0f);
        rightYAxis.setEnabled(false);

        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setAxisMinimum(0f);
        xAxis.setGranularity(1f);
        leftYAxis.setAxisMinimum(0f);
        rightYAxis.setAxisMinimum(0f);

        legend = lineChart.getLegend();
        legend.setForm(Legend.LegendForm.LINE);
        legend.setTextSize(16f);
        legend.setVerticalAlignment(Legend.LegendVerticalAlignment.BOTTOM);
        legend.setHorizontalAlignment(Legend.LegendHorizontalAlignment.LEFT);
        legend.setOrientation(Legend.LegendOrientation.HORIZONTAL);
        legend.setDrawInside(false);
        legend.setEnabled(false);
    }

    private void initLineDataSet(LineDataSet lineDataSet, int color, LineDataSet.Mode mode) {
        lineDataSet.setColor(color);
        lineDataSet.setCircleColor(color);
        lineDataSet.setLineWidth(1f);
        lineDataSet.setCircleRadius(3f);

        lineDataSet.setDrawCircles(true);
        lineDataSet.setDrawValues(false);
        lineDataSet.setDrawCircleHole(false);
        lineDataSet.setValueTextSize(14f);
        lineDataSet.setDrawFilled(false);
        lineDataSet.setFormLineWidth(1f);
        lineDataSet.setFormSize(15.f);
        if (mode == null) {
            lineDataSet.setMode(LineDataSet.Mode.CUBIC_BEZIER);
        } else {
            lineDataSet.setMode(mode);
        }
    }


    public void setDescription(String str) {
        Description description = new Description();
        description.setText(str);
        lineChart.setDescription(description);
        lineChart.invalidate();
    }


    public void setChartFillDrawable(Drawable drawable) {
        if (lineChart.getData() != null && lineChart.getData().getDataSetCount() > 0) {
            LineDataSet lineDataSet = (LineDataSet) lineChart.getData().getDataSetByIndex(0);
            lineDataSet.setDrawFilled(true);
            lineDataSet.setFillDrawable(drawable);
            lineChart.invalidate();
        }
    }


    public void showLineChart(final List<ChartModel> dataList, String name, int color, boolean isSetMaxValue, int maxValue, String unit) {
        List<Entry> entries = new ArrayList<>();
        for (int i = 0; i < dataList.size(); i++) {
            ChartModel data = dataList.get(i);
            Entry entry = new Entry(i + 1, (float) data.getValue());
            entries.add(entry);
        }
        xAxis.setLabelCount(dataList.size(), false);
        xAxis.setDrawAxisLine(false);
        xAxis.setTextColor(Color.parseColor("#99333333"));
        xAxis.setTextSize(10f);


        leftYAxis.setLabelCount(6, true);
        if (isSetMaxValue) {
            leftYAxis.resetAxisMaximum();
            leftYAxis.setAxisMaximum(maxValue);
        }
        leftYAxis.setTextColor(Color.parseColor("#99333333"));
        leftYAxis.setTextSize(10f);
        leftYAxis.setZeroLineColor(Color.parseColor("#E6E6E6"));
        leftYAxis.setZeroLineWidth(1f);
        leftYAxis.setAxisLineWidth(1f);
        leftYAxis.setAxisLineColor(Color.parseColor("#E6E6E6"));

        LineDataSet lineDataSet = new LineDataSet(entries, name);
        lineDataSet.setHighlightEnabled(true);
        initLineDataSet(lineDataSet, color, LineDataSet.Mode.CUBIC_BEZIER);
        LineData lineData = new LineData(lineDataSet);
        lineChart.setData(lineData);

        MyMarkView myMarkView = new MyMarkView(mContext, unit);
        myMarkView.setChartView(lineChart);
        lineChart.setMarker(myMarkView);
        lineChart.invalidate();
        lineChart.setOnChartValueSelectedListener(new OnChartValueSelectedListener() {
            @Override
            public void onValueSelected(Entry e, Highlight h) {
            }

            @Override
            public void onNothingSelected() {

            }
        });
    }
}
