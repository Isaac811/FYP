package com.ch.doctorspatientsproject.util;

import android.annotation.TargetApi;
import android.app.ActivityManager;
import android.app.ActivityManager.RunningTaskInfo;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.drawable.GradientDrawable;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.storage.StorageManager;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.ch.doctorspatientsproject.R;
import com.google.android.gms.maps.model.LatLng;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public final class T {
    private T() {
    }

    private static Toast toast = null;

    /**
     * DIP convert toPX
     * @param context context
     * @param dpValue DIP
     * @return PX
     */
    public static int dip2px(Context context, float dpValue) {
        float scale = context.getResources().getDisplayMetrics().density;
        return (int) (dpValue * scale + 0.5f);
    }

    /**
     * Returns true if the string is null or 0-length.
     * @param str the string to be examined
     * @return true if str is null or zero length
     */
    public static boolean isEmpty(CharSequence str) {
        if (str == null || str.length() == 0)
            return true;
        else
            return false;
    }

    /**
     * Trim Rules
     * @param value value
     * @param rules rules
     * @return string
     */
    public static String getTrim(double value, String rules) {
        DecimalFormat df = new DecimalFormat(rules);
        return df.format(value);
    }
    /**
     * Toast
     * @param context        context
     * @param msg            message
     * @param isShowLongTime isShowLongTime
     */
    public static void showToast(Context context, String msg, boolean isShowLongTime) {
        if (context != null && msg != null && !msg.equals("")) {
            if (toast == null) {
                LayoutInflater inflate = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                View view = inflate.inflate(R.layout.transient_notification, null);
                TextView tv = (TextView) view.findViewById(android.R.id.message);
                GradientDrawable gradientDrawable = new GradientDrawable();
                gradientDrawable.setColor(0xA6000000);
                gradientDrawable.setCornerRadius(dip2px(context, 5f));
                if (Build.VERSION.SDK_INT >= 16) {
                    view.setBackground(gradientDrawable);
                } else {
                    view.setBackgroundDrawable(gradientDrawable);
                }
                toast = new Toast(context);
                toast.setView(view);
                toast.setGravity(Gravity.CENTER, 0, 0);
            }
            if (isShowLongTime) {
                toast.setDuration(Toast.LENGTH_LONG);
            } else {
                toast.setDuration(Toast.LENGTH_SHORT);
            }
            TextView tv = (TextView) toast.getView().findViewById(android.R.id.message);
            if (tv != null) {
                tv.setText(msg);
                toast.show();
            }
        }
    }

    /**
     * Short Toast
     * @param context context
     * @param msg     message
     * @see T#showToast(Context, String, boolean)
     */
    public static void showToast(Context context, String msg) {
        showToast(context, msg, false);
    }

    /**
     * Get SD Card Location List
     * @param context
     * @return
     */
    @SuppressWarnings("all")
    @TargetApi(Build.VERSION_CODES.GINGERBREAD)
    public static List<String> getValidSDCardPathList(Context context) {
        List<String> pathList = new ArrayList<String>();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.GINGERBREAD) {
            try {
                StorageManager sm = (StorageManager) context.getSystemService(Context.STORAGE_SERVICE);
                String[] paths = (String[]) sm.getClass().getMethod("getVolumePaths").invoke(sm);
                for (int i = 0; i < paths.length; i++) {
                    String status = (String) sm.getClass().getMethod("getVolumeState", String.class).invoke(sm, paths[i]);
                    if (status.equals(Environment.MEDIA_MOUNTED)) {
                        pathList.add(paths[i]);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return pathList;
    }

    /**
     * Check SD Card
     * @return true or false
     */
    public static boolean isSdCardOK() {
        if (Environment.getExternalStorageState().equals(
                Environment.MEDIA_MOUNTED)) {
            return true;
        }
        return false;
    }

    /**
     * Get APP Files Storage Directory
     * @return file
     */
    public static File getFilesDir(Context context) {
        File appFilesDir = getExternalDir(context, "files");
        if (appFilesDir == null) {
            appFilesDir = context.getFilesDir();
        }
        if (appFilesDir != null && !appFilesDir.exists()) {
            appFilesDir.mkdirs();
        }
        return appFilesDir;
    }

    /**
     * Get APP Files External Storage Directory Name
     * @param context
     * @return dirName
     */
    public static File getExternalDir(Context context, String dirName) {
        File appFilesDir = null;
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            if (isSdCardOK()) {
                appFilesDir = getExternalFilesDir(context, dirName);
            }
            if (appFilesDir == null) {
                List<String> pathList = getValidSDCardPathList(context);
                if (pathList.size() != 0) {
                    appFilesDir = new File(pathList.get(0) + "/" + dirName);
                }
            }
        }
        return appFilesDir;
    }

    /**
     * Get APP Files External Storage Directory
     *
     * @param context
     * @return file
     */
    public static File getExternalFilesDir(Context context, String childDirName) {
        File dataDir = new File(new File(Environment.getExternalStorageDirectory(), "Android"), "data");
        File appFilesDir = new File(new File(dataDir, context.getPackageName()), childDirName);
        if (!appFilesDir.exists()) {
            if (!appFilesDir.mkdirs()) {
                return null;
            }
            try {
                new File(appFilesDir, ".nomedia").createNewFile();
            } catch (IOException e) {
                return null;
            }
        }
        return appFilesDir;
    }

    /**
     * Calculate Image compression value
     * @param options   options
     * @param reqWidth  reqWidth
     * @param reqHeight reqHeight
     * @return inSampleSize
     */
    public static int getBitmapInSampleSize(BitmapFactory.Options options, int reqWidth, int reqHeight) {
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;
        if (height > reqHeight || width > reqWidth) {
            final int heightRatio = Math.round((float) height / (float) reqHeight);
            final int widthRatio = Math.round((float) width / (float) reqWidth);
            inSampleSize = heightRatio < widthRatio ? heightRatio : widthRatio;
        }
        return inSampleSize;
    }

    /**
     * Get Image and compress
     * @param filePath filePath
     * @param targetW  targetW
     * @param targetH  targetH
     * @return bitmap
     */
    public static Bitmap getBtimapFromFile(String filePath, int targetW, int targetH) {
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(filePath, options);
        // Calculate inSampleSize
        options.inSampleSize = getBitmapInSampleSize(options, targetW, targetH);
        // Decode bitmap with inSampleSize set
        options.inJustDecodeBounds = false;
        options.inPreferredConfig = Bitmap.Config.RGB_565;
        return BitmapFactory.decodeFile(filePath, options);
    }

    public static View getNoParentView(View rootView) {
        ViewGroup parent = (ViewGroup) rootView.getParent();
        if (parent != null)
            parent.removeView(rootView);
        return rootView;
    }

    /**
     * Send Email by Use Gmail
     * @param context
     * @param recipient
     * @param subject
     * @param body
     */
    public static void sendEmail(Context context, String recipient, String subject, String body) {
        Intent emailIntent = new Intent(Intent.ACTION_SENDTO);
        emailIntent.setData(Uri.parse("mailto:"));
        emailIntent.putExtra(Intent.EXTRA_EMAIL, new String[]{recipient});
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, subject);
        emailIntent.putExtra(Intent.EXTRA_TEXT, body);

        // Check applications which support send emails
        PackageManager packageManager = context.getPackageManager();
        List<ResolveInfo> resolveInfos = packageManager.queryIntentActivities(emailIntent, 0);

        boolean gmailFound = false;

        for (ResolveInfo info : resolveInfos) {
            if (info.activityInfo.packageName.equals("com.google.android.gm")) {
                emailIntent.setPackage("com.google.android.gm");
                gmailFound = true;
                break;
            }
        }
        if (gmailFound) {
            context.startActivity(emailIntent);
        } else {
            if (emailIntent.resolveActivity(packageManager) != null) {
                context.startActivity(emailIntent);
            } else {
                Toast.makeText(context, "Email application not installed", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public static double distance(double long1, double lat1, double long2, double lat2) {
        double a, b, R;
        R = 6378137;
        lat1 = lat1 * Math.PI / 180.0;
        lat2 = lat2 * Math.PI / 180.0;
        a = lat1 - lat2;
        b = (long1 - long2) * Math.PI / 180.0;
        double d;
        double sa2, sb2;
        sa2 = Math.sin(a / 2.0);
        sb2 = Math.sin(b / 2.0);
        d = 2
                * R
                * Math.asin(Math.sqrt(sa2 * sa2 + Math.cos(lat1)
                * Math.cos(lat2) * sb2 * sb2));
        return d;
    }

    public static String getShowDistance(Context context, LatLng ll1, LatLng ll2) {
        String showDistanceStr = "";
        if (ll1 == null || ll2 == null)
            return showDistanceStr;
        double distance = -1;

        distance = distance(ll1.longitude, ll1.latitude, ll2.longitude, ll2.latitude);
        if (distance >= 0) {
            if (distance < 1000) {
                return "<1km away";
            } else {
                showDistanceStr = T.getTrim(distance / 1000d, "#0") + "km away";
                return showDistanceStr;
            }
        }
        return showDistanceStr;
    }

    public static Bitmap getBitmapFromScrollView(ScrollView scrollView) {
        int height = 0;
        for (int i = 0; i < scrollView.getChildCount(); i++) {
            height += scrollView.getChildAt(i).getHeight();
        }
        Bitmap bitmap = Bitmap.createBitmap(scrollView.getWidth(), height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        scrollView.draw(canvas);
        return bitmap;
    }

    public static void saveBitmapToPdf(Bitmap bitmap, File file) {
        PdfDocument pdfDocument = new PdfDocument();
        PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(bitmap.getWidth(), bitmap.getHeight(), 1).create();
        PdfDocument.Page page = pdfDocument.startPage(pageInfo);

        Canvas canvas = page.getCanvas();
        canvas.drawBitmap(bitmap, 0, 0, null);
        pdfDocument.finishPage(page);

        try {
            FileOutputStream outputStream = new FileOutputStream(file);
            pdfDocument.writeTo(outputStream);
            pdfDocument.close();
            outputStream.close();
            Log.d("PDF", "PDF Save Success：" + file.getAbsolutePath());
        } catch (IOException e) {
            e.printStackTrace();
            Log.e("PDF", "PDF Save Failed：" + e.getMessage());
        }
    }

    public static void exportScrollViewToPdf(ScrollView scrollView, File file) {
        Bitmap bitmap = getBitmapFromScrollView(scrollView);
        saveBitmapToPdf(bitmap, file);
    }
}
