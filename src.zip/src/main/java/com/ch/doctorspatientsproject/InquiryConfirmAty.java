package com.ch.doctorspatientsproject;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.ch.doctorspatientsproject.beans.AppointmentBean;
import com.ch.doctorspatientsproject.widget.StatusBarCommonTitleWidget;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;

public class InquiryConfirmAty extends AppCompatActivity implements StatusBarCommonTitleWidget.OnClickBackListener {

    private StatusBarCommonTitleWidget ctv;

    private FirebaseFirestore db;

    private TextView tvDate;
    private TextView tvDoctor;
    private EditText etRemark;
    private EditText etCase;
    private Spinner spPrescribe;
    private String prescribe = "Epinephrine";
    private Button btnAppointment;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.aty_inquiry_confirm_layout);

        ctv = findViewById(R.id.cvTilteCustom);
        ctv.isHiddenCloseBtn();
        ctv.setLeftContent("");
        ctv.setMiddelContent("Inquiry");
        ctv.setOnClickBackListener(this);

        AppointmentBean bean = getIntent().getExtras().getParcelable("doctor");

        db = FirebaseFirestore.getInstance();

        tvDate = findViewById(R.id.tv_date);
        tvDate.setText("Date：" + bean.getAppoint_date() + "-" + bean.getAppoint_time());

        tvDoctor = findViewById(R.id.tv_doctor);
        tvDoctor.setText("Patient：" + bean.getUser_name());
        etRemark = findViewById(R.id.et_remark);
        etRemark.setText("Remark：" + bean.getAppoint_remark());

        etCase = findViewById(R.id.et_case);
        etCase.setText(bean.getInquiry());

        spPrescribe = findViewById(R.id.sp_prescribe);
        spPrescribe.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                prescribe = getResources().getStringArray(R.array.restoratives)[position];
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        btnAppointment = findViewById(R.id.btn_appointment);
        btnAppointment.setOnClickListener(v -> {

            db.collection("appointment")
                    .whereEqualTo("user_id", bean.getUser_id())
                    .get()
                    .addOnSuccessListener(documentReference -> {
                        Log.e("fk", "size=" + documentReference.getDocuments().size());
                        documentReference
                                .getDocuments()
                                .forEach(documentSnapshot -> {
                                    if (!TextUtils.isEmpty(etCase.getText())) {
                                        Map<String, Object> user = new HashMap<>();
                                        user.put("inquiry", etCase.getText().toString());
                                        user.put("prescribe", prescribe);
                                        user.put("is_complete", "true");
                                        documentSnapshot
                                                .getReference()
                                                .update(user)
                                                .addOnSuccessListener(unused -> {
                                                    Toast.makeText(InquiryConfirmAty.this, "Inquiry Success", Toast.LENGTH_SHORT).show();
                                                    finish();
                                                }).addOnFailureListener(e -> {
                                                    Toast.makeText(InquiryConfirmAty.this, "Inquiry onFailure", Toast.LENGTH_SHORT).show();
                                                    finish();
                                                });
                                    }
                                });

                    }).addOnFailureListener(e -> Log.d("TAG", "onFailure: " + e.getLocalizedMessage()));
        });
    }

    @Override
    public void OnClickBack() {
        finish();
    }

    @Override
    public void OnClickFinch() {
        finish();
    }
}
