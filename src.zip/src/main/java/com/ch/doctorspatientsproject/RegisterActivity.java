package com.ch.doctorspatientsproject;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.ch.doctorspatientsproject.beans.UserBean;
import com.ch.doctorspatientsproject.databinding.ActivityRegisterBinding;
import com.ch.doctorspatientsproject.systembar.ImmersiveBarUtil;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.List;
import java.util.UUID;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class RegisterActivity extends AppCompatActivity {

    String departments = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ImmersiveBarUtil.immersiveBar(this);
        ActivityRegisterBinding binding = ActivityRegisterBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.btRegister.setOnClickListener(v -> {
            String username = binding.editTextText.getText().toString();
            String password = binding.editTextTextPassword.getText().toString();
            String password2 = binding.editTextTextPassword2.getText().toString();
            if (username.isEmpty()) {
                Toast.makeText(RegisterActivity.this, "Please enter a user name！", Toast.LENGTH_SHORT).show();
                return;
            }
            if (password.isEmpty()) {
                Toast.makeText(RegisterActivity.this, "Please enter password！", Toast.LENGTH_SHORT).show();
                return;
            }
            if (!password.equals(password2)) {
                Toast.makeText(RegisterActivity.this, "The two passwords are inconsistent！", Toast.LENGTH_SHORT).show();
                return;
            }

            FirebaseFirestore instance = FirebaseFirestore.getInstance();
            instance
                    .collection("_user")
                    .get()
                    .addOnSuccessListener(queryDocumentSnapshots -> {
                        List<UserBean> userList = queryDocumentSnapshots.toObjects(UserBean.class);
                        List<UserBean> collect =
                                userList
                                        .stream()
                                        .filter(new Predicate<UserBean>() {
                                            @Override
                                            public boolean test(UserBean user) {
                                                return user.getUsername().equals(username);
                                            }
                                        }).collect(Collectors.toList());
                        if (!collect.isEmpty()) {
                            Toast.makeText(RegisterActivity.this, "Registration Failed！", Toast.LENGTH_SHORT).show();
                        } else {
                            UserBean data = new UserBean();
                            data.setPassword(password);
                            data.setUsername(username);
                            data.setId(UUID.randomUUID().toString());

                            RadioButton rb = findViewById(binding.radioGroup.getCheckedRadioButtonId());
                            data.setRole(rb.getText().toString());
                            if (rb.getText().toString().equals("medic")) {
                                data.setDepartments(departments);
                                data.setMedicInfo(binding.etInfo.getText().toString());
                            } else {
                                data.setDepartments("");
                                data.setMedicInfo("");
                            }

                            instance.collection("_user")
                                    .add(data)
                                    .addOnSuccessListener(documentReference -> {
                                        Toast.makeText(RegisterActivity.this, "Registration success", Toast.LENGTH_SHORT).show();
                                        finish();
                                    }).addOnFailureListener(e -> Log.d("TAG", "onFailure: " + e.getLocalizedMessage()));

                        }
                    }).addOnFailureListener(e -> Log.d("TAG", "onFailure: " + e.getLocalizedMessage()));
        });


        binding.radioGroup.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.radioButton2) {
                binding.spDepartments.setVisibility(View.VISIBLE);
                binding.etInfo.setVisibility(View.VISIBLE);
            } else {
                binding.spDepartments.setVisibility(View.GONE);
                binding.etInfo.setVisibility(View.GONE);
            }
        });

        binding.spDepartments.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                departments = getResources().getStringArray(R.array.departments)[position];
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }
}