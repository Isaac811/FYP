package com.ch.doctorspatientsproject.dialog;


import android.app.AlertDialog;
import android.content.Context;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.ch.doctorspatientsproject.R;

public class ExportResultDialog extends AlertDialog {

    private Context context;

    public ExportResultDialog(@NonNull Context context) {
        this(context, R.style.CustomDialog);
        this.context = context;
    }

    protected ExportResultDialog(@NonNull Context context, int themeResId) {

        super(context, themeResId);
        this.context = context;
    }

    private CharSequence result;

    public void setResult(CharSequence result) {
        this.result = result;
    }

    public Button btn;
    private TextView tv_result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_export_result);
        this.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        getWindow().setGravity(Gravity.CENTER);
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM);

        tv_result = findViewById(R.id.tv_result);
        tv_result.setText(result);


        btn = findViewById(R.id.btn);
        btn.setOnClickListener(v -> {
            dismiss();
        });
    }
}
