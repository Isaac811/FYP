package com.ch.doctorspatientsproject.dialog;

import android.app.AlertDialog;
import android.content.Context;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;

import androidx.annotation.NonNull;

import com.ch.doctorspatientsproject.R;
import com.ch.doctorspatientsproject.util.T;
import com.ch.doctorspatientsproject.views.SignatureView;

import java.io.IOException;
import java.util.Date;


public class SignatureDialog extends AlertDialog {

    private Context context;

    public SignatureDialog(@NonNull Context context) {
        this(context, R.style.CustomDialog);
        this.context = context;
    }

    protected SignatureDialog(@NonNull Context context, int themeResId) {

        super(context, themeResId);
        this.context = context;
    }

    public Button btn;
    private SignatureView signature;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_signature);
        this.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        getWindow().setGravity(Gravity.CENTER);
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM);

        signature = findViewById(R.id.signature);


        btn = findViewById(R.id.btn);
        btn.setOnClickListener(v -> {
            String sign_file_path = checkSign();
            if (sign_file_path == null) {
                return;
            }
            if (dialogListener != null) {
                dismiss();
                dialogListener.Ok(sign_file_path);
            }
        });
    }

    private String checkSign() {
        if (signature.getTouched()) {
            String sign_file_path = T.getFilesDir(context) + "/sign_" + new Date().getTime() + ".jpg";
            try {
                signature.save(sign_file_path, true, T.dip2px(context, 150), T.dip2px(context, 25));
            } catch (IOException e) {
                e.printStackTrace();
                T.showToast(context, "Sign failed");
                return null;
            }
            return sign_file_path;
        } else {
            T.showToast(context, "Please sign");
            return null;
        }
    }

    private CustomDialogListener dialogListener;

    public void setDialogListener(CustomDialogListener dialogListener) {
        this.dialogListener = dialogListener;
    }

    public interface CustomDialogListener {
        void Ok(String sign_file_path);
    }
}
