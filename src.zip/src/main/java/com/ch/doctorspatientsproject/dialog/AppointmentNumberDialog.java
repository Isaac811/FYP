package com.ch.doctorspatientsproject.dialog;

import android.app.AlertDialog;
import android.content.Context;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.ch.doctorspatientsproject.R;
import com.ch.doctorspatientsproject.beans.AppointmentBean;
import com.ch.doctorspatientsproject.views.TopTitleLayout;

import java.util.List;


public class AppointmentNumberDialog extends AlertDialog {

    public AppointmentNumberDialog(@NonNull Context context) {
        this(context, R.style.CustomDialog);
    }

    protected AppointmentNumberDialog(@NonNull Context context, int themeResId) {
        super(context, themeResId);
    }

    List<AppointmentBean> doctorBeans;

    public void setContext(List<AppointmentBean> doctorBeans) {
        this.doctorBeans = doctorBeans;
    }

    public TextView tv;
    public Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_appointment_number);
        this.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        getWindow().setGravity(Gravity.CENTER);
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM);

        TopTitleLayout top_title_layout = findViewById(R.id.top_title_layout);

        tv = findViewById(R.id.tv_info_value);
        top_title_layout.setTitle("Reservation number：" + (doctorBeans.size() + 1));

        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < doctorBeans.size(); i++) {
            AppointmentBean data = doctorBeans.get(i);
            builder.append((i + 1) + "." + data.getUser_name() + "\n" + data.getAppoint_date() + " " + data.getAppoint_time() + "\n\n");
        }

        tv.setText(builder.toString());

        btn = findViewById(R.id.btn);
        btn.setOnClickListener(v -> {
            if (dialogListener != null) {
                dismiss();
                dialogListener.Ok();
            }
        });
    }

    private CustomDialogListener dialogListener;

    public void setDialogListener(CustomDialogListener dialogListener) {
        this.dialogListener = dialogListener;
    }

    public interface CustomDialogListener {
        void Ok();
    }
}
