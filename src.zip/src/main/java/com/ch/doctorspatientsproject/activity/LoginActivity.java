package com.ch.doctorspatientsproject.activity;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.ch.doctorspatientsproject.App;
import com.ch.doctorspatientsproject.R;
import com.ch.doctorspatientsproject.beans.UserBean;
import com.ch.doctorspatientsproject.util.FF;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;


public class LoginActivity extends AppCompatActivity {

    RadioGroup radioGroup;
    String radioNameStr = "Patient"; // 默认用户角色
    TextView bt_register;
    Button bt_login;
    EditText userEmail;
    EditText userPwd;

    private FirebaseFirestore db;
    private CollectionReference userCollection;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        requestLocationPermission();

        db = FirebaseFirestore.getInstance();
        userCollection = db.collection(FF.USER);
        sharedPreferences = getSharedPreferences("LoginPrefs", MODE_PRIVATE);

        radioGroup = findViewById(R.id.radioGroup);
        bt_register = findViewById(R.id.txt_login_register);
        bt_login = findViewById(R.id.btn_login);
        userEmail = findViewById(R.id.et_login_email);
        userPwd = findViewById(R.id.et_login_pwd);

        // 自动填入保存的用户名、密码和角色
        loadSavedCredentials();

        radioGroup.setOnCheckedChangeListener((group, checkedId) -> {
            RadioButton radioButton = findViewById(checkedId);
            radioNameStr = radioButton.getText().toString();
        });

        bt_register.setOnClickListener(view -> {
            Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
            startActivity(intent);
        });

        bt_login.setOnClickListener(view -> {
            if (!TextUtils.isEmpty(userEmail.getText()) && !TextUtils.isEmpty(userPwd.getText())) {
                userCollection
                        .whereEqualTo("email", userEmail.getText().toString())
                        .whereEqualTo("password", userPwd.getText().toString())
                        .whereEqualTo("role", radioNameStr)
                        .get()
                        .addOnSuccessListener(queryDocumentSnapshots -> {
                            if (queryDocumentSnapshots.isEmpty()) {
                                Toast.makeText(LoginActivity.this, "The email or password is incorrect！", Toast.LENGTH_SHORT).show();
                                return;
                            }

                            UserBean userBean = queryDocumentSnapshots.toObjects(UserBean.class).get(0);
                            if (userBean != null) {
                                App.loginUser = userBean;
                                // 保存用户名、密码和角色
                                saveCredentials(userEmail.getText().toString(), userPwd.getText().toString(), radioNameStr);
                                // 跳转到对应主界面
                                Intent intent = new Intent(LoginActivity.this, radioGroup.getCheckedRadioButtonId() == R.id.radioButton ? PatientMainActivity.class : DoctorMainActivity.class);
                                startActivity(intent);
                            } else {
                                Toast.makeText(LoginActivity.this, "Login timeout, please try again later！", Toast.LENGTH_SHORT).show();
                            }

                        });
            } else {
                Toast.makeText(LoginActivity.this, "Please enter your email and password!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    /**
     * 保存用户名、密码和角色到 SharedPreferences
     */
    private void saveCredentials(String email, String password, String role) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("email", email);
        editor.putString("password", password);
        editor.putString("role", role);
        editor.apply();
    }

    /**
     * 从 SharedPreferences 加载用户名、密码和角色
     */
    private void loadSavedCredentials() {
        String savedUsername = sharedPreferences.getString("email", "");
        String savedPassword = sharedPreferences.getString("password", "");
        String savedRole = sharedPreferences.getString("role", "Patient"); // 默认角色为 Patient

        if (!TextUtils.isEmpty(savedUsername)) {
            userEmail.setText(savedUsername);
        }
        if (!TextUtils.isEmpty(savedPassword)) {
            userPwd.setText(savedPassword);
        }

        // 根据保存的角色设置单选按钮
        for (int i = 0; i < radioGroup.getChildCount(); i++) {
            RadioButton radioButton = (RadioButton) radioGroup.getChildAt(i);
            if (radioButton.getText().toString().equals(savedRole)) {
                radioButton.setChecked(true);
                radioNameStr = savedRole;
                break;
            }
        }
    }

    private static final int REQUEST_CODE = 100;

    private void requestLocationPermission() {
        if (
                ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED ||
                        ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED ||
                        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED ||
                        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED
        ) {

            ActivityCompat.requestPermissions(this, new String[]{
                    Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
            }, REQUEST_CODE);
        } else {

        }
    }
}
