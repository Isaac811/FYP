package com.ch.doctorspatientsproject.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.ch.doctorspatientsproject.R;
import com.ch.doctorspatientsproject.beans.AppointDateBean;
import com.ch.doctorspatientsproject.beans.AppointmentBean;
import com.ch.doctorspatientsproject.util.FF;
import com.ch.doctorspatientsproject.views.TopTitleLayout;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;


public class PatientAppointmentConfirmActivity extends AppCompatActivity {

    private FirebaseFirestore db;
    private TextView tvDate;
    private TextView tvDoctor;
    private Spinner spAppointTime;
    private Spinner sp_appointDate;
    private AppointDateBean appointDoctorDate;
    private EditText etRemark;
    private EditText et_temp, et_press;
    private Button btnAppointment;

    List<AppointDateBean> appointDateBeans;
    List<String> timeList = new ArrayList<>();
    List<String> dateList = new ArrayList<>();
    private AppointmentBean bean;
    String str_date;
    String str_time;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_appointment_confirm);
        ((TopTitleLayout) findViewById(R.id.top_title_layout)).setBackEnable(this);

        bean = (AppointmentBean) getIntent().getExtras().getSerializable("doctor");

        db = FirebaseFirestore.getInstance();

        tvDate = findViewById(R.id.tv_date);
        Date currentDate = new Date();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String formattedDate = dateFormat.format(currentDate);
        tvDate.setText("Date：" + formattedDate);

        tvDoctor = findViewById(R.id.tv_doctor);
        tvDoctor.setText("Doctor：" + bean.getDoctor_name());
        spAppointTime = findViewById(R.id.sp_appoint_time);
        sp_appointDate = findViewById(R.id.sp_appoint_date);
        getDoctorAppointDate();
        spAppointTime.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                str_time = timeList.get(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        sp_appointDate.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                str_date = dateList.get(position);
                db.collection(FF.DOCTOR_APPOINT_DATE)
                        .whereEqualTo("doctor_id", bean.getDoctor_id())
                        .whereEqualTo("doctor_date", str_date)
                        .whereEqualTo("is_appoint", "false")
                        .get().addOnSuccessListener(queryDocumentSnapshots -> {

                            if (queryDocumentSnapshots.isEmpty()) {
                                return;
                            }

                            appointDateBeans = queryDocumentSnapshots.toObjects(AppointDateBean.class);
                            timeList.clear();
                            for (int i = 0; i < appointDateBeans.size(); i++) {
                                if (!timeList.contains(appointDateBeans.get(i).getDoctor_time()))
                                    timeList.add(appointDateBeans.get(i).getDoctor_time());
                            }
                            Collections.sort(timeList, new Comparator<String>() {
                                @Override
                                public int compare(String o1, String o2) {
                                    return o1.compareTo(o2);
                                }
                            });


                            spAppointTime.setAdapter(new BaseAdapter() {
                                @Override
                                public int getCount() {
                                    return timeList.size();
                                }

                                @Override
                                public Object getItem(int position) {
                                    return timeList.get(position);
                                }

                                @Override
                                public long getItemId(int position) {
                                    return position;
                                }

                                @Override
                                public View getView(int position, View convertView, ViewGroup parent) {
                                    convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_list_appoint_date, parent, false);

                                    TextView tv_appoint_date = convertView.findViewById(R.id.tv_appoint_date);
                                    tv_appoint_date.setText(timeList.get(position) + " Available");
                                    return convertView;
                                }
                            });

                        });
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        etRemark = findViewById(R.id.et_remark);
        et_temp = findViewById(R.id.et_temp);
        et_press = findViewById(R.id.et_press);
        btnAppointment = findViewById(R.id.btn_appointment);
        btnAppointment.setOnClickListener(v -> {
            if (str_date != null && str_time != null) {
                for (int i = 0; i < appointDateBeans.size(); i++) {
                    if (appointDateBeans.get(i).getDoctor_date().equals(str_date)
                            && appointDateBeans.get(i).getDoctor_time().equals(str_time)) {
                        appointDoctorDate = appointDateBeans.get(i);
                        break;
                    }
                }

                if (appointDoctorDate != null
                        && !TextUtils.isEmpty(appointDoctorDate.getDoctor_date())
                        && !TextUtils.isEmpty(appointDoctorDate.getDoctor_time())
                        && !TextUtils.isEmpty(et_temp.getText())
                        && !TextUtils.isEmpty(et_press.getText())) {


                    bean.setAppoint_date(appointDoctorDate.getDoctor_date());
                    bean.setAppoint_time(appointDoctorDate.getDoctor_time());
                    bean.setIs_complete("false");
                    bean.setInquiry("");
                    bean.setDoctor_id(appointDoctorDate.getDoctor_id());
                    bean.setUserTemp(et_temp.getText().toString());
                    bean.setUserPress(et_press.getText().toString());
                    bean.setDate_id(appointDoctorDate.getDate_id());
                    if (!TextUtils.isEmpty(etRemark.getText())) {
                        bean.setAppoint_remark(etRemark.getText().toString());
                    }

                    Intent intent = new Intent(PatientAppointmentConfirmActivity.this, PatientPayActivity.class);
                    intent.putExtra("AppointmentBean", bean);
                    intent.putExtra("AppointDateBean", appointDoctorDate);
                    startActivity(intent);
                    finish();


                } else {
                    Toast.makeText(PatientAppointmentConfirmActivity.this, "Please enter all fields!", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(PatientAppointmentConfirmActivity.this, "Please enter your date or time!", Toast.LENGTH_SHORT).show();
            }

        });
    }

    private void getDoctorAppointDate() {
        db.collection(FF.DOCTOR_APPOINT_DATE)
                .whereEqualTo("doctor_id", bean.getDoctor_id())
                .whereEqualTo("is_appoint", "false")
                .get().addOnSuccessListener(queryDocumentSnapshots -> {

                    if (queryDocumentSnapshots.isEmpty()) {
                        return;
                    }

                    appointDateBeans = queryDocumentSnapshots.toObjects(AppointDateBean.class);
                    timeList.clear();
                    dateList.clear();
                    for (int i = 0; i < appointDateBeans.size(); i++) {
                        String date = appointDateBeans.get(i).getDoctor_date();
                        if (!dateList.contains(date)) {
                            String now_date = LocalDate.now() + "";
                            if (now_date.compareTo(date) > 0)
                                continue;
                            else
                                dateList.add(date);
                        }
                        if (!timeList.contains(appointDateBeans.get(i).getDoctor_time()))
                            timeList.add(appointDateBeans.get(i).getDoctor_time());
                    }
                    Collections.sort(timeList, new Comparator<String>() {
                        @Override
                        public int compare(String o1, String o2) {
                            return o1.compareTo(o2);
                        }
                    });
                    Collections.sort(dateList, new Comparator<String>() {
                        @Override
                        public int compare(String o1, String o2) {
                            return o1.compareTo(o2);
                        }
                    });


                    spAppointTime.setAdapter(new BaseAdapter() {
                        @Override
                        public int getCount() {
                            return timeList.size();
                        }

                        @Override
                        public Object getItem(int position) {
                            return timeList.get(position);
                        }

                        @Override
                        public long getItemId(int position) {
                            return position;
                        }

                        @Override
                        public View getView(int position, View convertView, ViewGroup parent) {
                            convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_list_appoint_date, parent, false);

                            TextView tv_appoint_date = convertView.findViewById(R.id.tv_appoint_date);
                            tv_appoint_date.setText(timeList.get(position) + " Available");
                            return convertView;
                        }
                    });

                    sp_appointDate.setAdapter(new BaseAdapter() {
                        @Override
                        public int getCount() {
                            return dateList.size();
                        }

                        @Override
                        public Object getItem(int position) {
                            return dateList.get(position);
                        }

                        @Override
                        public long getItemId(int position) {
                            return position;
                        }

                        @Override
                        public View getView(int position, View convertView, ViewGroup parent) {
                            convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_list_appoint_date, parent, false);

                            TextView tv_appoint_date = convertView.findViewById(R.id.tv_appoint_date);
                            tv_appoint_date.setText(dateList.get(position));
                            return convertView;
                        }
                    });
                });
    }
}
