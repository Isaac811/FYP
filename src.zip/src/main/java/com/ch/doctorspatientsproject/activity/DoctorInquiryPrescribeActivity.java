package com.ch.doctorspatientsproject.activity;

import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.text.Html;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.ch.doctorspatientsproject.R;
import com.ch.doctorspatientsproject.dialog.ExportResultDialog;
import com.ch.doctorspatientsproject.util.FF;
import com.ch.doctorspatientsproject.util.T;
import com.ch.doctorspatientsproject.views.TopTitleLayout;
import com.google.firebase.firestore.FirebaseFirestore;

import java.io.File;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class DoctorInquiryPrescribeActivity extends AppCompatActivity {

    private FirebaseFirestore db;

    private Spinner spPrescribe;
    private String prescribe = "Epinephrine";

    private Button btnAppointment;

    private EditText etDate;
    private EditText etDosage;
    private EditText etInstructions;
    private String sign_file_path;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_inquiry_prescribe);
        ((TopTitleLayout) findViewById(R.id.top_title_layout)).setBackEnable(this);

        db = FirebaseFirestore.getInstance();

        spPrescribe = findViewById(R.id.sp_prescribe);
        spPrescribe.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                prescribe = getResources().getStringArray(R.array.restoratives)[position];
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        etDate = findViewById(R.id.tv_date);
        etDosage = findViewById(R.id.tv_doctor);
        etInstructions = findViewById(R.id.et_remark);

        btnAppointment = findViewById(R.id.btn_appointment);
        btnAppointment = findViewById(R.id.btn_appointment);
        btnAppointment = findViewById(R.id.btn_appointment);
        btnAppointment.setOnClickListener(v -> {

            if (!TextUtils.isEmpty(etDate.getText())
                    && !TextUtils.isEmpty(etDosage.getText())
                    && !TextUtils.isEmpty(etInstructions.getText())) {

                db.collection(FF.APPOINTMENT)
                        .whereEqualTo("user_id", getIntent().getExtras().getString("user_id"))
                        .whereEqualTo("doctor_id", getIntent().getExtras().getString("doctor_id"))
                        .whereEqualTo("date_id", getIntent().getExtras().getString("date_id"))
                        .get()
                        .addOnSuccessListener(documentReference -> {
                            Log.e("fk", "size=" + documentReference.getDocuments().size());
                            documentReference
                                    .getDocuments()
                                    .forEach(documentSnapshot -> {
                                        if (!TextUtils.isEmpty(prescribe)) {
                                            Map<String, Object> user = new HashMap<>();
                                            user.put("prescribeDate", etDate.getText().toString());
                                            user.put("prescribeDosage", etDosage.getText().toString());
                                            user.put("prescribeIns", etInstructions.getText().toString());
                                            user.put("prescribe", prescribe);
                                            user.put("is_complete", "true");
                                            user.put("is_appoint", "false");
                                            documentSnapshot
                                                    .getReference()
                                                    .update(user)
                                                    .addOnSuccessListener(unused -> {
                                                        updateAppointDate();
                                                    }).addOnFailureListener(e -> {
                                                        Toast.makeText(DoctorInquiryPrescribeActivity.this, "Inquiry onFailure", Toast.LENGTH_SHORT).show();
                                                        finish();
                                                    });
                                        }
                                    });

                        }).addOnFailureListener(e -> Log.d("TAG", "onFailure: " + e.getLocalizedMessage()));
            } else {
                Toast.makeText(DoctorInquiryPrescribeActivity.this, "Incomplete data entry", Toast.LENGTH_SHORT).show();
            }
        });


        findViewById(R.id.btn_export).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(DoctorInquiryPrescribeActivity.this, "export pdf now ......", Toast.LENGTH_SHORT).show();
                File downloadsFolder = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                File file = new File(downloadsFolder, "export_" + new Date().getTime() + ".pdf");
                T.exportScrollViewToPdf(findViewById(R.id.sv_export), file);

                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        ExportResultDialog customDialog = new ExportResultDialog(DoctorInquiryPrescribeActivity.this);
                        customDialog.setResult(Html.fromHtml("The PDF file has been successfully exported and is located in the Download directory. The file name is <font color=red><b>" + file.getName() + "</b></font>. You can send it to the patient or hospital institution via email attachment."));
                        customDialog.show();
                    }
                }, 2000);

            }
        });
    }

    private void updateAppointDate() {
        db.collection(FF.DOCTOR_APPOINT_DATE)
                .whereEqualTo("date_id", getIntent().getExtras().getString("date_id"))
                .get()
                .addOnSuccessListener(documentReference -> {
                    Log.e("fk", "size=" + documentReference.getDocuments().size());
                    documentReference
                            .getDocuments()
                            .forEach(documentSnapshot -> {
                                Map<String, Object> user = new HashMap<>();
                                user.put("is_appoint", "false");
                                documentSnapshot
                                        .getReference()
                                        .update(user)
                                        .addOnSuccessListener(unused -> {
                                            Toast.makeText(DoctorInquiryPrescribeActivity.this, "Inquiry Success", Toast.LENGTH_SHORT).show();
                                            finish();
                                        }).addOnFailureListener(e -> {
                                            Toast.makeText(DoctorInquiryPrescribeActivity.this, "Appointment onFailure", Toast.LENGTH_SHORT).show();
                                            finish();
                                        });
                            });

                }).addOnFailureListener(e -> Log.d("TAG", "onFailure: " + e.getLocalizedMessage()));
    }
}
