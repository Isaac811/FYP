package com.ch.doctorspatientsproject.activity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.text.Html;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.ch.doctorspatientsproject.R;
import com.ch.doctorspatientsproject.beans.AppointmentBean;
import com.ch.doctorspatientsproject.dialog.ExportResultDialog;
import com.ch.doctorspatientsproject.dialog.SignatureDialog;
import com.ch.doctorspatientsproject.util.FF;
import com.ch.doctorspatientsproject.util.T;
import com.ch.doctorspatientsproject.util.statistics.ChartModel;
import com.ch.doctorspatientsproject.util.statistics.LineChartManager;
import com.ch.doctorspatientsproject.views.TopTitleLayout;
import com.github.mikephil.charting.charts.LineChart;
import com.google.firebase.firestore.FirebaseFirestore;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DoctorInquiryConfirmActivity extends AppCompatActivity {

    private FirebaseFirestore db;

    private TextView tvDate;
    private TextView tvDoctor;
    private TextView tvEmail;
    private EditText etRemark;
    private EditText etCase;
    private Button btnAppointment;

    public LineChartManager weightLineChartTempManager, weightLineChartPressManager;
    private LineChart lineChartTemp, lineChartPress;
    private LinearLayout empty_view_temp, empty_view_press;
    private ImageView iv_signature;
    private String sign_file_path;

    private Switch switch0;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_inquiry_confirm);
        ((TopTitleLayout) findViewById(R.id.top_title_layout)).setBackEnable(this);

        AppointmentBean bean = (AppointmentBean) getIntent().getExtras().getSerializable("doctor");

        db = FirebaseFirestore.getInstance();

        lineChartTemp = findViewById(R.id.line_chart_temp).findViewById(R.id.lineChartTemp);
        empty_view_temp = findViewById(R.id.line_chart_temp).findViewById(R.id.empty_view_temp);
        lineChartTemp.setNoDataText("");
        weightLineChartTempManager = new LineChartManager(lineChartTemp, this);
        lineChartPress = findViewById(R.id.line_chart_press).findViewById(R.id.lineChartPress);
        empty_view_press = findViewById(R.id.line_chart_press).findViewById(R.id.empty_view_press);
        lineChartPress.setNoDataText("");
        weightLineChartPressManager = new LineChartManager(lineChartPress, this);

        iv_signature = findViewById(R.id.iv_signature);
        iv_signature.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SignatureDialog customDialog = new SignatureDialog(DoctorInquiryConfirmActivity.this);
                customDialog.setDialogListener(new SignatureDialog.CustomDialogListener() {
                    @Override
                    public void Ok(String sign_file_path) {
                        DoctorInquiryConfirmActivity.this.sign_file_path = sign_file_path;
                        iv_signature.setImageBitmap(T.getBtimapFromFile(sign_file_path, 400, 400));
                    }
                });
                customDialog.show();
            }
        });

        findViewById(R.id.btn_email).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                T.sendEmail(DoctorInquiryConfirmActivity.this, bean.getUser_email(), "Inquiry Report", "This is a prescription label regarding the patient's symptoms. Please refer to the attached document for detailed information.");
            }
        });

        findViewById(R.id.btn_export).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (TextUtils.isEmpty(sign_file_path)) {
                    Toast.makeText(DoctorInquiryConfirmActivity.this, "Please complete the signature first !", Toast.LENGTH_SHORT).show();
                    return;
                }
                Toast.makeText(DoctorInquiryConfirmActivity.this, "export pdf now ......", Toast.LENGTH_SHORT).show();
                File downloadsFolder = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                File file = new File(downloadsFolder, "export_" + new Date().getTime() + ".pdf");
                T.exportScrollViewToPdf(findViewById(R.id.sv_export), file);

                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        ExportResultDialog customDialog = new ExportResultDialog(DoctorInquiryConfirmActivity.this);
                        customDialog.setResult(Html.fromHtml("The PDF file has been successfully exported and is located in the Download directory. The file name is <font color=red><b>" + file.getName() + "</b></font>. You can send it to the patient or hospital institution via email attachment."));
                        customDialog.show();
                    }
                }, 2000);

            }
        });


        {
            List<ChartModel> list = new ArrayList<>();
            if (!TextUtils.isEmpty(bean.getUserTemp())) {
                String[] strings = bean.getUserTemp().split("-");
                for (String string : strings) {
                    ChartModel itemModel = new ChartModel();
                    itemModel.setValue(Double.parseDouble(string));
                    list.add(itemModel);
                }
            }
            fillChartDataTemp(list);
        }
        {
            List<ChartModel> list = new ArrayList<>();
            if (!TextUtils.isEmpty(bean.getUserPress())) {
                String[] strings = bean.getUserPress().split("-");
                for (String string : strings) {
                    ChartModel itemModel = new ChartModel();
                    itemModel.setValue(Double.parseDouble(string));
                    list.add(itemModel);
                }
            }
            fillChartDataPress(list);
        }


        tvDate = findViewById(R.id.tv_date);
        tvDate.setText("Date：" + bean.getAppoint_date() + "-" + bean.getAppoint_time());

        tvDoctor = findViewById(R.id.tv_doctor);
        tvDoctor.setText("Patient：" + bean.getUser_name());
        tvEmail = findViewById(R.id.tv_email);
        tvEmail.setText("Email：" + (T.isEmpty(bean.getUser_email()) ? "" : bean.getUser_email()));
        etRemark = findViewById(R.id.et_remark);
        etRemark.setText("Note：" + bean.getAppoint_remark());

        etCase = findViewById(R.id.et_case);
        etCase.setText(bean.getInquiry());

        switch0 = findViewById(R.id.switch0);
        switch0.setChecked("true".equals(bean.getIs_record()) ? true : false);
        switch0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!(switch0.isChecked() + "").equals(bean.getIs_record())) {
                    db.collection(FF.APPOINTMENT)
                            .whereEqualTo("appoint_id", bean.getAppoint_id())
                            .get()
                            .addOnSuccessListener(documentReference -> {
                                Log.e("fk", "size=" + documentReference.getDocuments().size());
                                documentReference
                                        .getDocuments()
                                        .forEach(documentSnapshot -> {
                                            Map<String, Object> user = new HashMap<>();
                                            user.put("is_record", switch0.isChecked() + "");
                                            documentSnapshot
                                                    .getReference()
                                                    .update(user)
                                                    .addOnSuccessListener(unused -> {
                                                        Log.i("TAG", "onSuccess");
                                                    }).addOnFailureListener(e -> {
                                                        switch0.setChecked(!switch0.isChecked());
                                                    });
                                        });

                            }).addOnFailureListener(e -> {
                                switch0.setChecked(!switch0.isChecked());
                                Log.d("TAG", "onFailure: " + e.getLocalizedMessage());
                            });
                }
            }
        });

        btnAppointment = findViewById(R.id.btn_appointment);
        btnAppointment.setOnClickListener(v -> {

            if (TextUtils.isEmpty(etCase.getText())) {
                Toast.makeText(DoctorInquiryConfirmActivity.this, "Please enter the case !", Toast.LENGTH_SHORT).show();
                return;
            }
            db.collection(FF.APPOINTMENT)
                    .whereEqualTo("user_id", bean.getUser_id())
                    .whereEqualTo("doctor_id", bean.getDoctor_id())
                    .whereEqualTo("date_id", bean.getDate_id())
                    .get()
                    .addOnSuccessListener(documentReference -> {
                        Log.e("fk", "size=" + documentReference.getDocuments().size());
                        documentReference
                                .getDocuments()
                                .forEach(documentSnapshot -> {
                                    if (!TextUtils.isEmpty(etCase.getText())) {
                                        Map<String, Object> user = new HashMap<>();
                                        user.put("inquiry", etCase.getText().toString());
                                        documentSnapshot
                                                .getReference()
                                                .update(user)
                                                .addOnSuccessListener(unused -> {

                                                    Intent intent = new Intent(DoctorInquiryConfirmActivity.this, DoctorInquiryPrescribeActivity.class);
                                                    Bundle bundle = new Bundle();
                                                    bundle.putString("user_id", bean.getUser_id());
                                                    bundle.putString("doctor_id", bean.getDoctor_id());
                                                    bundle.putString("date_id", bean.getDate_id());
                                                    intent.putExtras(bundle);
                                                    startActivity(intent);
                                                    finish();
                                                }).addOnFailureListener(e -> {
                                                    Toast.makeText(DoctorInquiryConfirmActivity.this, "Inquiry onFailure", Toast.LENGTH_SHORT).show();
                                                    finish();
                                                });
                                    } else {
                                        Toast.makeText(DoctorInquiryConfirmActivity.this, "Please enter the case !", Toast.LENGTH_SHORT).show();
                                    }
                                });

                    }).addOnFailureListener(e -> Log.d("TAG", "onFailure: " + e.getLocalizedMessage()));
        });
    }


    public void fillChartDataTemp(List<ChartModel> list) {
        if (list != null && list.size() > 0) {
            empty_view_temp.setVisibility(View.GONE);
            weightLineChartTempManager.showLineChart(list, "", Color.parseColor("#FF3666FF"), true, 50, "°C");
        } else {
            empty_view_temp.setVisibility(View.VISIBLE);
        }
    }

    public void fillChartDataPress(List<ChartModel> list) {
        if (list != null && list.size() > 0) {
            empty_view_press.setVisibility(View.GONE);
            weightLineChartPressManager.showLineChart(list, "", Color.parseColor("#FF3666FF"), true, 250, "mmHg");
        } else {
            empty_view_press.setVisibility(View.VISIBLE);
        }
    }

}
