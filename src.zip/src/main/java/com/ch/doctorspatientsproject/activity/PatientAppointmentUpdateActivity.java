package com.ch.doctorspatientsproject.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.ch.doctorspatientsproject.R;
import com.ch.doctorspatientsproject.beans.AppointmentBean;
import com.ch.doctorspatientsproject.util.FF;
import com.ch.doctorspatientsproject.views.TopTitleLayout;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class PatientAppointmentUpdateActivity extends AppCompatActivity {


    private FirebaseFirestore db;
    private TextView tvDate;
    private TextView tvDoctor;
    private TextView tvDateTime;
    private EditText etRemark;
    private EditText et_temp, et_press;
    private Button btnOk;
    private Button btnCancel;
    private AppointmentBean bean;
    private AppointmentBean bean1;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_appointment_update);
        ((TopTitleLayout) findViewById(R.id.top_title_layout)).setBackEnable(this);

        bean = (AppointmentBean) getIntent().getExtras().getSerializable("doctor");
        bean1 = (AppointmentBean) getIntent().getExtras().getSerializable("doctor");

        db = FirebaseFirestore.getInstance();

        tvDate = findViewById(R.id.tv_date);
        Date currentDate = new Date();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String formattedDate = dateFormat.format(currentDate);
        tvDate.setText("Date：" + formattedDate);

        tvDoctor = findViewById(R.id.tv_doctor);
        tvDoctor.setText("Doctor：" + bean.getDoctor_name());
        tvDateTime = findViewById(R.id.tv_datetime);
        tvDateTime.setText("DateTime：" + bean.getAppoint_date() + "-" + bean.getAppoint_time());


        etRemark = findViewById(R.id.et_remark);
        etRemark.setText(bean.getAppoint_remark());
        et_temp = findViewById(R.id.et_temp);
        et_temp.setText(bean.getUserTemp());
        et_press = findViewById(R.id.et_press);
        et_press.setText(bean.getUserPress());
        btnOk = findViewById(R.id.btn_ok);
        btnCancel = findViewById(R.id.btn_cancel);
        btnOk.setOnClickListener(v -> {
            if (TextUtils.isEmpty(etRemark.getText())) {
                Toast.makeText(PatientAppointmentUpdateActivity.this, "Symptoms cannot be empty", Toast.LENGTH_SHORT).show();
                return;
            }
            if (TextUtils.isEmpty(et_temp.getText())) {
                Toast.makeText(PatientAppointmentUpdateActivity.this, "Temperature cannot be empty", Toast.LENGTH_SHORT).show();
                return;
            }

            bean1.setAppoint_remark(etRemark.getText().toString());
            bean1.setUserTemp(et_temp.getText().toString());
            bean1.setUserPress(et_press.getText().toString());

            db.collection(FF.APPOINTMENT)
                    .whereEqualTo("appoint_id", bean.getAppoint_id())
                    .get().addOnSuccessListener(queryDocumentSnapshots -> {
                        queryDocumentSnapshots.getDocuments()
                                .forEach(documentSnapshot -> {
                                    Map<String, Object> user = new HashMap<>();
                                    user.put("appoint_remark", bean1.getAppoint_remark());
                                    user.put("userTemp", bean1.getUserTemp());
                                    user.put("userPress", bean1.getUserPress());
                                    documentSnapshot
                                            .getReference()
                                            .update(user)
                                            .addOnSuccessListener(unused -> {
                                                Intent intent = new Intent(PatientAppointmentUpdateActivity.this, PatientAppointmentCaseActivity.class);
                                                intent.putExtra("doctor", bean1);
                                                startActivity(intent);
                                                finish();
                                                Toast.makeText(PatientAppointmentUpdateActivity.this, "Update Successfully", Toast.LENGTH_SHORT).show();
                                            }).addOnFailureListener(e -> {
                                                Toast.makeText(PatientAppointmentUpdateActivity.this, "Update onFailure", Toast.LENGTH_SHORT).show();
                                            });
                                });

                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(PatientAppointmentUpdateActivity.this, "Update onFailure", Toast.LENGTH_SHORT).show();

                        }
                    });
        });

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(PatientAppointmentUpdateActivity.this, PatientAppointmentCaseActivity.class);
                intent.putExtra("doctor", bean);
                startActivity(intent);
                finish();
            }
        });
    }

    @Override
    public void finish() {
        Intent intent = new Intent(PatientAppointmentUpdateActivity.this, PatientAppointmentCaseActivity.class);
        intent.putExtra("doctor", bean);
        startActivity(intent);
        super.finish();
    }

}
