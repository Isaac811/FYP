package com.ch.doctorspatientsproject.activity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import com.ch.doctorspatientsproject.R;
import com.ch.doctorspatientsproject.beans.AppointmentBean;
import com.ch.doctorspatientsproject.util.statistics.ChartModel;
import com.ch.doctorspatientsproject.util.statistics.LineChartManager;
import com.ch.doctorspatientsproject.views.TopTitleLayout;
import com.github.mikephil.charting.charts.LineChart;

import java.util.ArrayList;
import java.util.List;


public class PatientAppointmentCaseActivity extends AppCompatActivity {

    private TextView tvDate;
    private TextView tvDoctor;
    private EditText etRemark;
    private TextView tv_prescribe;
    private EditText etCase;

    public LineChartManager weightLineChartTempManager, weightLineChartPressManager;
    private LineChart lineChartTemp, lineChartPress;
    private LinearLayout empty_view_temp, empty_view_press;
    AppCompatButton btnUpdate;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_appointment_case);
        ((TopTitleLayout) findViewById(R.id.top_title_layout)).setBackEnable(this);

        AppointmentBean bean = (AppointmentBean) getIntent().getSerializableExtra("doctor");

        lineChartTemp = findViewById(R.id.line_chart_temp).findViewById(R.id.lineChartTemp);
        empty_view_temp = findViewById(R.id.line_chart_temp).findViewById(R.id.empty_view_temp);
        lineChartTemp.setNoDataText("");
        weightLineChartTempManager = new LineChartManager(lineChartTemp, this);
        lineChartPress = findViewById(R.id.line_chart_press).findViewById(R.id.lineChartPress);
        empty_view_press = findViewById(R.id.line_chart_press).findViewById(R.id.empty_view_press);
        lineChartPress.setNoDataText("");
        weightLineChartPressManager = new LineChartManager(lineChartPress, this);

        {
            List<ChartModel> list = new ArrayList<>();
            if (!TextUtils.isEmpty(bean.getUserTemp())) {
                String[] strings = bean.getUserTemp().split("-");
                for (String string : strings) {
                    ChartModel itemModel = new ChartModel();
                    itemModel.setValue(Double.parseDouble(string));
                    list.add(itemModel);
                }
            }
            fillChartDataTemp(list);
        }
        {
            List<ChartModel> list = new ArrayList<>();
            if (!TextUtils.isEmpty(bean.getUserPress())) {
                String[] strings = bean.getUserPress().split("-");
                for (String string : strings) {
                    ChartModel itemModel = new ChartModel();
                    itemModel.setValue(Double.parseDouble(string));
                    list.add(itemModel);
                }
            }
            fillChartDataPress(list);
        }

        tvDate = findViewById(R.id.tv_date);

        tvDate.setText("Date：" + bean.getAppoint_date() + "-" + bean.getAppoint_time());

        tvDoctor = findViewById(R.id.tv_doctor);
        tvDoctor.setText("Doctor：" + bean.getDoctor_name());

        etRemark = findViewById(R.id.et_remark);
        etRemark.setText("Note：" + bean.getAppoint_remark());

        etCase = findViewById(R.id.et_case);
        etCase.setText(bean.getInquiry());

        tv_prescribe = findViewById(R.id.tv_prescribe);
        if (TextUtils.isEmpty(bean.getPrescribe())) {
            tv_prescribe.setText("Waiting for the doctor to conduct an inquiry ......");
            tv_prescribe.setTextColor(Color.RED);
        } else {
            tv_prescribe.setTextColor(getResources().getColor(R.color.c_theme));
            tv_prescribe.setText("prescribe: " + bean.getPrescribe() + " \nprescribeDate: " + bean.getPrescribeDate() + " \nprescribeDosage: " + bean.getPrescribeDosage() + " \nprescribeIns: " + bean.getPrescribeIns());
        }

        btnUpdate = findViewById(R.id.btnUpdate);
        btnUpdate.setVisibility("true".equals(bean.getIs_record()) ? View.VISIBLE : View.GONE);
        btnUpdate.setOnClickListener(v -> {

            Intent intent = new Intent(PatientAppointmentCaseActivity.this, PatientAppointmentUpdateActivity.class);
            intent.putExtra("doctor", bean);
            startActivity(intent);
            finish();

        });
    }

    public void fillChartDataTemp(List<ChartModel> list) {
        if (list != null && list.size() > 0) {
            empty_view_temp.setVisibility(View.GONE);
            weightLineChartTempManager.showLineChart(list, "", Color.parseColor("#FF3666FF"), true, 50, "°C");
        } else {
            empty_view_temp.setVisibility(View.VISIBLE);
        }
    }

    public void fillChartDataPress(List<ChartModel> list) {
        if (list != null && list.size() > 0) {
            empty_view_press.setVisibility(View.GONE);
            weightLineChartPressManager.showLineChart(list, "", Color.parseColor("#FF3666FF"), true, 250, "mmHg");
        } else {
            empty_view_press.setVisibility(View.VISIBLE);
        }
    }

}
