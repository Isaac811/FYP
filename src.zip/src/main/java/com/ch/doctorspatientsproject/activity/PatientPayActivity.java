package com.ch.doctorspatientsproject.activity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.widget.AppCompatButton;

import com.ch.doctorspatientsproject.R;
import com.ch.doctorspatientsproject.beans.AppointDateBean;
import com.ch.doctorspatientsproject.beans.AppointmentBean;
import com.ch.doctorspatientsproject.util.FF;
import com.ch.doctorspatientsproject.util.T;
import com.ch.doctorspatientsproject.views.TopTitleLayout;
import com.google.firebase.firestore.FirebaseFirestore;
import com.stripe.android.paymentsheet.PaymentSheetResult;

import java.util.HashMap;
import java.util.Map;


public class PatientPayActivity extends StripePayActivity {

    AppCompatButton bt_pay;
    AppointmentBean bean;
    AppointDateBean appointDoctorDate;
    private FirebaseFirestore db;
    private long amount = 30;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_pay);
        ((TopTitleLayout) findViewById(R.id.top_title_layout)).setBackEnable(this);

        TextView tv_amount = findViewById(R.id.tv_amount);
        tv_amount.setText("€" + amount);

        bean = (AppointmentBean) getIntent().getSerializableExtra("AppointmentBean");
        appointDoctorDate = (AppointDateBean) getIntent().getSerializableExtra("AppointDateBean");
        db = FirebaseFirestore.getInstance();

        bt_pay = findViewById(R.id.bt_pay);
        bt_pay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                doPay(amount);
            }
        });
        bt_pay.performClick();
    }

    @Override
    protected void payCompleted(PaymentSheetResult paymentSheetResult) {
        super.payCompleted(paymentSheetResult);
        db.collection(FF.APPOINTMENT)
                .add(bean)
                .addOnSuccessListener(documentReference -> {
                    updateAppointDate();
                }).addOnFailureListener(e -> Log.d("TAG", "onFailure: " + e.getLocalizedMessage()));
    }

    private void updateAppointDate() {
        db.collection(FF.DOCTOR_APPOINT_DATE)
                .whereEqualTo("date_id", appointDoctorDate.getDate_id())
                .get()
                .addOnSuccessListener(documentReference -> {
                    Log.e("fk", "size=" + documentReference.getDocuments().size());
                    documentReference
                            .getDocuments()
                            .forEach(documentSnapshot -> {
                                Map<String, Object> user = new HashMap<>();
                                user.put("is_appoint", "true");
                                documentSnapshot
                                        .getReference()
                                        .update(user)
                                        .addOnSuccessListener(unused -> {
                                            Toast.makeText(PatientPayActivity.this, "Booking successfully", Toast.LENGTH_SHORT).show();
                                            Intent intent = new Intent(PatientPayActivity.this, PatientPaySuccessActivity.class);
                                            intent.putExtra("doctor", bean);
                                            startActivity(intent);
                                            finish();
                                        }).addOnFailureListener(e -> {
                                            Toast.makeText(PatientPayActivity.this, "Booking Failure", Toast.LENGTH_SHORT).show();
                                            finish();
                                        });
                            });

                }).addOnFailureListener(e -> Log.d("TAG", "onFailure: " + e.getLocalizedMessage()));
    }
}