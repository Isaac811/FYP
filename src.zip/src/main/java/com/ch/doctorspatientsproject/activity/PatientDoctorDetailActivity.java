package com.ch.doctorspatientsproject.activity;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.ch.doctorspatientsproject.App;
import com.ch.doctorspatientsproject.R;
import com.ch.doctorspatientsproject.adapters.CommentRecyclerAdapter;
import com.ch.doctorspatientsproject.beans.DoctorBean;
import com.ch.doctorspatientsproject.beans.RespCommentBean;
import com.ch.doctorspatientsproject.util.FF;
import com.ch.doctorspatientsproject.views.TopTitleLayout;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

public class PatientDoctorDetailActivity extends AppCompatActivity {

    private FirebaseFirestore db;
    private CollectionReference userCollection;

    DoctorBean bean;

    private ImageView iv_avatar;
    private TextView tv_move_name;
    private TextView tv_director;
    private TextView tv_writer;

    private RecyclerView rvComment;
    private CommentRecyclerAdapter commentAdapter;
    private List<RespCommentBean> respComments = new ArrayList<>();

    private EditText etComment;
    private TextView btn_comment;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_doctor_detail);
        ((TopTitleLayout) findViewById(R.id.top_title_layout)).setBackEnable(this);

        bean = (DoctorBean) getIntent().getExtras().getSerializable("DoctorBean");

        iv_avatar = findViewById(R.id.iv_avatar);
        tv_move_name = findViewById(R.id.tv_item_0);
        tv_director = findViewById(R.id.tv_department);
        tv_writer = findViewById(R.id.tv_introduce);
        rvComment = findViewById(R.id.rv_list);
        btn_comment = findViewById(R.id.tv_send);
        etComment = findViewById(R.id.et_message);

        tv_move_name.setText(bean.getUsername());
        tv_director.setText(bean.getDepartments());
        tv_writer.setText(bean.getMedicInfo());

        if ("female".equals(bean.getGender())) {
            iv_avatar.setImageResource(R.mipmap.doctor_header_0);
        } else {
            iv_avatar.setImageResource(R.mipmap.doctor_header_1);
        }

        db = FirebaseFirestore.getInstance();
        userCollection = db.collection(FF.COMMENT);

        selectComment(bean);

        btn_comment.setOnClickListener(v -> {
            if (!TextUtils.isEmpty(etComment.getText())) {
                RespCommentBean comment = new RespCommentBean();
                comment.setId(UUID.randomUUID().toString());
                comment.setComment_uid(App.loginUser.getId());
                comment.setComment_doctor_id(bean.getId());

                comment.setComment_date(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
                comment.setComment_text(etComment.getText().toString());
                comment(comment);
            } else {
                Toast.makeText(PatientDoctorDetailActivity.this, "Please enter a comment", Toast.LENGTH_SHORT).show();
            }
        });
    }


    private void selectComment(DoctorBean bean) {
        userCollection.
                whereEqualTo("comment_doctor_id", bean.getId())
                .get().addOnSuccessListener(queryDocumentSnapshots -> {

                    if (queryDocumentSnapshots.isEmpty()) {
                        return;
                    }
                    List<RespCommentBean> s = queryDocumentSnapshots.toObjects(RespCommentBean.class);

                    respComments.clear();
                    respComments.addAll(s);
                    if (commentAdapter == null) {
                        commentAdapter = new CommentRecyclerAdapter(respComments);
                    }
                    rvComment.setLayoutManager(new LinearLayoutManager(PatientDoctorDetailActivity.this));
                    rvComment.setAdapter(commentAdapter);
                });
    }


    private void comment(RespCommentBean comment) {
        userCollection
                .add(comment)
                .addOnSuccessListener(documentReference -> {
                    respComments.add(comment);
                    etComment.setText("");
                    if (commentAdapter != null) {
                        commentAdapter.notifyDataSetChanged();
                    } else {
                        commentAdapter = new CommentRecyclerAdapter(respComments);
                        rvComment.setLayoutManager(new LinearLayoutManager(PatientDoctorDetailActivity.this));
                        rvComment.setAdapter(commentAdapter);
                    }
                    Toast.makeText(PatientDoctorDetailActivity.this, "Review success", Toast.LENGTH_SHORT).show();
                }).addOnFailureListener(e -> Log.d("TAG", "onFailure: " + e.getLocalizedMessage()));
    }
}
