package com.ch.doctorspatientsproject.activity;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.ch.doctorspatientsproject.util.T;
import com.github.kittinunf.fuel.Fuel;
import com.github.kittinunf.fuel.core.FuelError;
import com.github.kittinunf.fuel.core.Handler;
import com.stripe.android.PaymentConfiguration;
import com.stripe.android.paymentsheet.PaymentSheet;
import com.stripe.android.paymentsheet.PaymentSheetResult;

import org.json.JSONObject;

public abstract class StripePayActivity extends AppCompatActivity {

    final static private String StripePayHost = "http://172.20.10.5:9090";

    protected PaymentSheet paymentSheet;
    protected String paymentIntentClientSecret;
    protected PaymentSheet.CustomerConfiguration customerConfig;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        paymentSheet = new PaymentSheet(this, this::onPaymentSheetResult);
    }

    protected void doPay(long amount_real) {
        if (amount_real <= 0) {
            T.showToast(StripePayActivity.this, "amount cannot be empty");
            return;
        }
        createPaymentIntent(amount_real * 100);
    }

    private void createPaymentIntent(long amount) {
        Fuel.INSTANCE.post(StripePayHost + "/api/payment/create-payment-intent?amount=" + amount, null).responseString(new Handler<String>() {
            @Override
            public void success(String s) {
                try {
                    JSONObject result = new JSONObject(s);
                    customerConfig = new PaymentSheet.CustomerConfiguration(
                            result.getString("customer"),
                            result.getString("ephemeralKey")
                    );
                    paymentIntentClientSecret = result.getString("paymentIntent");
                    PaymentConfiguration.init(getApplicationContext(), result.getString("publishableKey"));

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            showStripePaymentSheet();
                        }
                    });

                } catch (Exception e) {
                    e.printStackTrace();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            T.showToast(StripePayActivity.this, e.getMessage());
                        }
                    });

                }
            }

            @Override
            public void failure(@NonNull FuelError fuelError) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        T.showToast(StripePayActivity.this, fuelError.getMessage());
                    }
                });
            }
        });
    }

    private void showStripePaymentSheet() {
        final PaymentSheet.Configuration configuration = new PaymentSheet.Configuration.Builder("Book Appointment")
                .customer(customerConfig)
                .allowsDelayedPaymentMethods(true)
                .build();
        paymentSheet.presentWithPaymentIntent(paymentIntentClientSecret, configuration);
    }

    protected void onPaymentSheetResult(final PaymentSheetResult paymentSheetResult) {
        if (paymentSheetResult instanceof PaymentSheetResult.Canceled) {
            payCanceled(paymentSheetResult);
        } else if (paymentSheetResult instanceof PaymentSheetResult.Failed) {
            payFailed(paymentSheetResult);
        } else if (paymentSheetResult instanceof PaymentSheetResult.Completed) {
            payCompleted(paymentSheetResult);
        }
    }

    protected void payCanceled(PaymentSheetResult paymentSheetResult) {
        T.showToast(StripePayActivity.this, "Payment Canceled");
    }

    protected void payFailed(PaymentSheetResult paymentSheetResult) {
        T.showToast(StripePayActivity.this, "Payment Failed");
    }

    protected void payCompleted(PaymentSheetResult paymentSheetResult) {
        T.showToast(StripePayActivity.this, "Payment Completed");
    }

}
