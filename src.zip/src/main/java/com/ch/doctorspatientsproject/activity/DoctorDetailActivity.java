package com.ch.doctorspatientsproject.activity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.ch.doctorspatientsproject.App;
import com.ch.doctorspatientsproject.R;
import com.ch.doctorspatientsproject.adapters.CommentRecyclerAdapter;
import com.ch.doctorspatientsproject.beans.RespCommentBean;
import com.ch.doctorspatientsproject.util.FF;
import com.ch.doctorspatientsproject.views.TopTitleLayout;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.List;


public class DoctorDetailActivity extends AppCompatActivity {

    private FirebaseFirestore db;
    private CollectionReference userCollection;

    private ImageView iv_avatar;
    private TextView tv_move_name;
    private TextView tv_director;
    private TextView tv_writer;

    private RecyclerView rvComment;
    private CommentRecyclerAdapter commentAdapter;
    private List<RespCommentBean> respComments = new ArrayList<>();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_detail);
        ((TopTitleLayout) findViewById(R.id.top_title_layout)).setBackEnable(this);

        db = FirebaseFirestore.getInstance();
        userCollection = db.collection(FF.COMMENT);

        iv_avatar = findViewById(R.id.iv_avatar);
        tv_move_name = findViewById(R.id.tv_item_0);
        tv_director = findViewById(R.id.tv_department);
        tv_writer = findViewById(R.id.tv_introduce);
        rvComment = findViewById(R.id.rv_list);

        tv_move_name.setText(App.loginUser.getUsername());
        tv_director.setText(App.loginUser.getDepartments());
        tv_writer.setText(App.loginUser.getMedicInfo());

        if ("female".equals(App.loginUser.getGender())) {
            iv_avatar.setImageResource(R.mipmap.doctor_header_0);
        } else {
            iv_avatar.setImageResource(R.mipmap.doctor_header_1);
        }

        selectComment();
    }

    private void selectComment() {
        userCollection.
                whereEqualTo("comment_doctor_id", App.loginUser.getId())
                .get().addOnSuccessListener(queryDocumentSnapshots -> {

                    if (queryDocumentSnapshots.isEmpty()) {
                        return;
                    }
                    List<RespCommentBean> s = queryDocumentSnapshots.toObjects(RespCommentBean.class);

                    respComments.clear();
                    respComments.addAll(s);
                    if (commentAdapter == null) {
                        commentAdapter = new CommentRecyclerAdapter(respComments);
                    }
                    rvComment.setLayoutManager(new LinearLayoutManager(DoctorDetailActivity.this));
                    rvComment.setAdapter(commentAdapter);
                });
    }
}
