package com.ch.doctorspatientsproject.activity;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.RadioButton;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.ch.doctorspatientsproject.R;
import com.ch.doctorspatientsproject.beans.AppointDateBean;
import com.ch.doctorspatientsproject.beans.UserBean;
import com.ch.doctorspatientsproject.databinding.ActivityRegisterBinding;
import com.ch.doctorspatientsproject.util.FF;
import com.ch.doctorspatientsproject.views.TopTitleLayout;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;


public class RegisterActivity extends AppCompatActivity {

    String departments = "";
    private boolean isDepart = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActivityRegisterBinding binding = ActivityRegisterBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        ((TopTitleLayout) findViewById(R.id.top_title_layout)).setBackEnable(this);

        binding.btRegister.setOnClickListener(v -> {
            String nickname = binding.etNickname.getText().toString();
            String email = binding.etEmail.getText().toString();
            String password = binding.etPassword.getText().toString();
            String password2 = binding.etPasswordConfirm.getText().toString();
            String gender = binding.spGender.getSelectedItem().toString();
            if (nickname.isEmpty()) {
                Toast.makeText(RegisterActivity.this, "Please enter a valid nickname", Toast.LENGTH_SHORT).show();
                return;
            }
            if (!isValidEmail(email)) {
                Toast.makeText(RegisterActivity.this, "Please enter a valid email address", Toast.LENGTH_SHORT).show();
                return;
            }
            if (password.isEmpty()) {
                Toast.makeText(RegisterActivity.this, "Please enter password", Toast.LENGTH_SHORT).show();
                return;
            }
            if (!password.equals(password2)) {
                Toast.makeText(RegisterActivity.this, "The two passwords are inconsistent", Toast.LENGTH_SHORT).show();
                return;
            }
            if (isDepart && TextUtils.isEmpty(departments)) {
                Toast.makeText(RegisterActivity.this, "Please select your department", Toast.LENGTH_SHORT).show();
                return;
            }
            if (TextUtils.isEmpty(gender)) {
                Toast.makeText(RegisterActivity.this, "Please select your gender", Toast.LENGTH_SHORT).show();
                return;
            }

            FirebaseFirestore.getInstance().collection(FF.USER)
                    .get()
                    .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                        @Override
                        public void onSuccess(QuerySnapshot qs) {
                            List<UserBean> collect = qs.toObjects(UserBean.class).stream().filter(user -> user.getEmail().equalsIgnoreCase(email)).collect(Collectors.toList());
                            if (!collect.isEmpty()) {
                                Toast.makeText(RegisterActivity.this, "This email has already been registered", Toast.LENGTH_LONG).show();
                            } else {
                                UserBean data = new UserBean();
                                data.setId(UUID.randomUUID().toString());
                                data.setEmail(email);
                                data.setUsername(nickname);
                                data.setPassword(password);

                                RadioButton rb = findViewById(binding.radioGroup.getCheckedRadioButtonId());
                                data.setRole(rb.getText().toString());
                                data.setDepartments(departments);
                                data.setMedicInfo(binding.etIntroduce.getText().toString());
                                data.setGender(gender);

                                FirebaseFirestore.getInstance().collection(FF.USER)
                                        .add(data)
                                        .addOnSuccessListener(documentReference -> {

                                            for (int i = 0; i < yourChoices.size(); i++) {
                                                registerDoctorAppointDate(data.getId(), doctorDate[yourChoices.get(i)]);
                                            }
                                            Toast.makeText(RegisterActivity.this, "You have successfully registered", Toast.LENGTH_LONG).show();
                                            finish();
                                        });

                            }
                        }
                    });
        });

        binding.radioGroup.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.radioButton2) {
                binding.spDepartments.setVisibility(View.VISIBLE);
                binding.etIntroduce.setVisibility(View.VISIBLE);
                binding.tvDoctorDate.setVisibility(View.VISIBLE);
                binding.spGender.setVisibility(View.VISIBLE);
                isDepart = false;
            } else {
                binding.spDepartments.setVisibility(View.GONE);
                binding.etIntroduce.setVisibility(View.GONE);
                binding.tvDoctorDate.setVisibility(View.GONE);
                binding.spGender.setVisibility(View.GONE);
                isDepart = true;
            }
        });
        binding.tvDoctorDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final boolean initChoseSets[] = {false, false, false, false, false};
                yourChoices.clear();

                AlertDialog.Builder multiDialog = new AlertDialog.Builder(RegisterActivity.this);
                multiDialog.setTitle("Choose your available time slots");
                multiDialog.setMultiChoiceItems(doctorDate, initChoseSets, (dialog, which, isChecked) -> {
                    if (isChecked) {
                        yourChoices.add(which);
                    } else {
                        yourChoices.remove(which);
                    }
                });

                multiDialog.setPositiveButton("Sure", (dialog, which) -> {
                    int size = yourChoices.size();
                    String str = "";
                    for (int i = 0; i < size; i++) {
                        str += doctorDate[yourChoices.get(i)] + " ";
                    }

                    binding.tvDoctorDate.setText(str);
                });
                multiDialog.show();

            }
        });
        binding.spDepartments.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                departments = getResources().getStringArray(R.array.departments)[position];
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    ArrayList<Integer> yourChoices = new ArrayList();
    final String[] doctorDate = {"10:00-11:00", "11:00-12:00", "13:00-14:00", "14:00-15:00", "15:00-16:00"};

    private void registerDoctorAppointDate(String id, String time) {
        AppointDateBean dateBean = new AppointDateBean();
        dateBean.setDoctor_id(id);
        dateBean.setIs_appoint("false");
        dateBean.setDoctor_time(time);

        LocalDate localDate = LocalDate.now();
        for (int i = 0; i < 30; i++) {
            String str_date = localDate.plusDays(i) + "";
            dateBean.setDoctor_date(str_date);
            dateBean.setDate_id(UUID.randomUUID().toString());
            FirebaseFirestore.getInstance().collection(FF.DOCTOR_APPOINT_DATE)
                    .add(dateBean)
                    .addOnSuccessListener(documentReference -> {
                        Log.e("fk", "registerDoctorAppointDate id =" + id + " date =" + time);
                    });
        }
    }

    public static boolean isValidEmail(String email) {
        if (email == null || email.isEmpty()) {
            return false;
        }
        String regex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$";
        return email.matches(regex);
    }
}