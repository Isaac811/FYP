package com.ch.doctorspatientsproject.activity;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.ch.doctorspatientsproject.App;
import com.ch.doctorspatientsproject.R;
import com.ch.doctorspatientsproject.adapters.ConsultationRecyclerAdapter;
import com.ch.doctorspatientsproject.beans.ChatRoom;
import com.ch.doctorspatientsproject.util.FF;
import com.ch.doctorspatientsproject.views.TopTitleLayout;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.List;

public class PatientConsultationActivity extends AppCompatActivity {

    private FirebaseFirestore db;
    private CollectionReference userCollection;

    private RecyclerView rcv;
    private ConsultationRecyclerAdapter adapter;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_consultation);
        ((TopTitleLayout) findViewById(R.id.top_title_layout)).setBackEnable(this);

        db = FirebaseFirestore.getInstance();
        userCollection = db.collection(FF.CHAT_ROOM);

        rcv = findViewById(R.id.rv_list);

        userCollection
                .whereEqualTo("userId", App.loginUser.getId())
                .get().addOnSuccessListener(queryDocumentSnapshots -> {

                    if (queryDocumentSnapshots.isEmpty()) {
                        return;
                    }
                    List<ChatRoom> doctorBeans = queryDocumentSnapshots.toObjects(ChatRoom.class);
                    if (adapter == null) {
                        adapter = new ConsultationRecyclerAdapter(doctorBeans);
                        rcv.setLayoutManager(new LinearLayoutManager(PatientConsultationActivity.this));
                        rcv.setAdapter(adapter);
                    } else {
                        adapter.notifyDataSetChanged();
                    }
                });
    }

}
