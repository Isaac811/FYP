package com.ch.doctorspatientsproject.activity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.ch.doctorspatientsproject.App;
import com.ch.doctorspatientsproject.R;
import com.ch.doctorspatientsproject.adapters.DoctorBookRecyclerAdapter;
import com.ch.doctorspatientsproject.beans.AppointmentBean;
import com.ch.doctorspatientsproject.beans.DoctorBean;
import com.ch.doctorspatientsproject.dialog.AppointmentNumberDialog;
import com.ch.doctorspatientsproject.util.FF;
import com.ch.doctorspatientsproject.views.TopTitleLayout;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.Collections;
import java.util.List;
import java.util.UUID;


public class PatientBookActivity extends AppCompatActivity implements DoctorBookRecyclerAdapter.AppointmentListener, AppointmentNumberDialog.CustomDialogListener {

    private FirebaseFirestore db;
    private CollectionReference userCollection;
    private RecyclerView rv_list;
    private DoctorBookRecyclerAdapter adapter;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_book);
        ((TopTitleLayout) findViewById(R.id.top_title_layout)).setBackEnable(this);

        db = FirebaseFirestore.getInstance();
        userCollection = db.collection(FF.USER);

        rv_list = findViewById(R.id.rv_list);

        userCollection
                .whereEqualTo("role", "Doctor")
                .get().addOnSuccessListener(queryDocumentSnapshots -> {

                    if (queryDocumentSnapshots.isEmpty()) {
                        return;
                    }
                    List<DoctorBean> doctorBeans = queryDocumentSnapshots.toObjects(DoctorBean.class);

                    if (adapter == null) {
                        adapter = new DoctorBookRecyclerAdapter(PatientBookActivity.this);
                        adapter.setDatas(doctorBeans);
                        adapter.setAppointmentListener(PatientBookActivity.this);
                        rv_list.setLayoutManager(new LinearLayoutManager(PatientBookActivity.this));
                        rv_list.setAdapter(adapter);
                    } else {
                        adapter.notifyDataSetChanged();
                    }
                });
    }

    DoctorBean doctorBean;

    @Override
    public void appointment(DoctorBean doctorBean) {
        this.doctorBean = doctorBean;
        appointCount(doctorBean);
    }


    private void appointCount(DoctorBean doctorBean) {
        db.collection(FF.APPOINTMENT)
                .whereEqualTo("doctor_id", doctorBean.getId())
                .whereEqualTo("is_complete", "false")
                .get().addOnSuccessListener(queryDocumentSnapshots -> {
                    if (queryDocumentSnapshots.isEmpty()) {
                        Toast.makeText(PatientBookActivity.this, "No one is booked", Toast.LENGTH_SHORT).show();
                        Ok();
                        return;
                    }
                    List<AppointmentBean> doctorBeans = queryDocumentSnapshots.toObjects(AppointmentBean.class);
                    Collections.reverse(doctorBeans);
                    AppointmentNumberDialog customDialog = new AppointmentNumberDialog(PatientBookActivity.this);
                    customDialog.setDialogListener(this);
                    customDialog.setContext(doctorBeans);
                    customDialog.show();
                });
    }

    @Override
    public void Ok() {
        AppointmentBean bean = new AppointmentBean();
        bean.setAppoint_id(UUID.randomUUID().toString());
        bean.setDoctor_id(doctorBean.getId());
        bean.setDoctor_name(doctorBean.getUsername());
        bean.setDoctor_gender(doctorBean.getGender());
        bean.setUser_id(App.loginUser.getId());
        bean.setUser_name(App.loginUser.getUsername());
        bean.setUser_email(App.loginUser.getEmail());

        Intent intent = new Intent(PatientBookActivity.this, PatientAppointmentConfirmActivity.class);
        Bundle bundle = new Bundle();
        bundle.putSerializable("doctor", bean);
        intent.putExtras(bundle);
        startActivity(intent);
    }
}
