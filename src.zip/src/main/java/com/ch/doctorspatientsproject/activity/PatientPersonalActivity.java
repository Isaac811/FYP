package com.ch.doctorspatientsproject.activity;

import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.ch.doctorspatientsproject.App;
import com.ch.doctorspatientsproject.R;
import com.ch.doctorspatientsproject.databinding.ActivityPatientPersonalBinding;
import com.ch.doctorspatientsproject.util.FF;
import com.ch.doctorspatientsproject.views.TopTitleLayout;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;


public class PatientPersonalActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActivityPatientPersonalBinding binding = ActivityPatientPersonalBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        ((TopTitleLayout) findViewById(R.id.top_title_layout)).setBackEnable(this);
        binding.etNickname.setText(App.loginUser.getUsername());

        binding.btRegister.setOnClickListener(v -> {
            String nickname = binding.etNickname.getText().toString();
            String password = binding.etPassword.getText().toString();
            String password2 = binding.etPasswordConfirm.getText().toString();
            if (nickname.isEmpty()) {
                Toast.makeText(PatientPersonalActivity.this, "Please enter a valid nickname", Toast.LENGTH_SHORT).show();
                return;
            }
            if (password.isEmpty()) {
                Toast.makeText(PatientPersonalActivity.this, "Please enter password", Toast.LENGTH_SHORT).show();
                return;
            }
            if (!password.equals(password2)) {
                Toast.makeText(PatientPersonalActivity.this, "The two passwords are inconsistent", Toast.LENGTH_SHORT).show();
                return;
            }

            FirebaseFirestore instance = FirebaseFirestore.getInstance();
            instance
                    .collection(FF.USER)
                    .whereEqualTo("id", App.loginUser.getId())
                    .get()
                    .addOnSuccessListener(queryDocumentSnapshots -> {
                        queryDocumentSnapshots
                                .getDocuments()
                                .forEach(documentSnapshot -> {
                                    Map<String, Object> user = new HashMap<>();
                                    user.put("username", nickname);
                                    user.put("password", password);

                                    documentSnapshot
                                            .getReference()
                                            .update(user)
                                            .addOnSuccessListener(unused -> {
                                                Toast.makeText(PatientPersonalActivity.this, "Update Info Success", Toast.LENGTH_SHORT).show();
                                                finish();
                                            }).addOnFailureListener(e -> {
                                                Toast.makeText(PatientPersonalActivity.this, "Update Info onFailure", Toast.LENGTH_SHORT).show();
                                                finish();
                                            });
                                });
                    });
        });
    }
}