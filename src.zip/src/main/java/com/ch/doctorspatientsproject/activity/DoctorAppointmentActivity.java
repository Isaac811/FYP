package com.ch.doctorspatientsproject.activity;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.ch.doctorspatientsproject.App;
import com.ch.doctorspatientsproject.R;
import com.ch.doctorspatientsproject.adapters.DoctorAppointmentRecyclerAdapter;
import com.ch.doctorspatientsproject.beans.AppointmentBean;
import com.ch.doctorspatientsproject.util.FF;
import com.ch.doctorspatientsproject.views.TopTitleLayout;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.List;

public class DoctorAppointmentActivity extends AppCompatActivity implements DoctorAppointmentRecyclerAdapter.InquiryListener {

    private FirebaseFirestore db;
    private CollectionReference userCollection;

    private RecyclerView rcv;
    private DoctorAppointmentRecyclerAdapter adapter;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_appointment);
        ((TopTitleLayout) findViewById(R.id.top_title_layout)).setBackEnable(this);

        db = FirebaseFirestore.getInstance();
        userCollection = db.collection(FF.APPOINTMENT);

        rcv = findViewById(R.id.rv_list);

        userCollection
                .whereEqualTo("doctor_id", App.loginUser.getId())
                .get().addOnSuccessListener(queryDocumentSnapshots -> {

                    if (queryDocumentSnapshots.isEmpty()) {
                        return;
                    }
                    List<AppointmentBean> doctorBeans = queryDocumentSnapshots.toObjects(AppointmentBean.class);

                    if (adapter == null) {
                        adapter = new DoctorAppointmentRecyclerAdapter(doctorBeans);
                        adapter.setInquiryListener(this);
                        rcv.setLayoutManager(new LinearLayoutManager(DoctorAppointmentActivity.this));
                        rcv.setAdapter(adapter);
                    } else {
                        adapter.notifyDataSetChanged();
                    }
                });
    }

    @Override
    public void inquiry(AppointmentBean bean) {
        Intent intent = new Intent(this, DoctorInquiryConfirmActivity.class);
        Bundle bundle = new Bundle();
        bundle.putSerializable("doctor", bean);
        intent.putExtras(bundle);
        startActivity(intent);
    }

}
