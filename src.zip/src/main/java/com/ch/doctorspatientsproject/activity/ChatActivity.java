package com.ch.doctorspatientsproject.activity;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;

import androidx.appcompat.app.AppCompatActivity;

import com.ch.doctorspatientsproject.App;
import com.ch.doctorspatientsproject.R;
import com.ch.doctorspatientsproject.adapters.BindAdapter;
import com.ch.doctorspatientsproject.beans.Message;
import com.ch.doctorspatientsproject.databinding.ActivityChatBinding;
import com.ch.doctorspatientsproject.databinding.AdapterRecyclerChatBinding;
import com.ch.doctorspatientsproject.util.FF;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;


public class ChatActivity extends AppCompatActivity {
    private BindAdapter<AdapterRecyclerChatBinding, Message> adapter = new BindAdapter<AdapterRecyclerChatBinding, Message>() {
        @Override
        public AdapterRecyclerChatBinding createHolder(ViewGroup parent) {
            return AdapterRecyclerChatBinding.inflate(getLayoutInflater(), parent, false);
        }

        @Override
        public void bind(AdapterRecyclerChatBinding item, Message message, int position) {
            if (message.getUsername().equals(App.loginUser.getUsername())) {
                item.left.setVisibility(View.GONE);
                item.right.setVisibility(View.VISIBLE);
                item.tvMessage.setText(message.getContent());
            } else {
                item.right.setVisibility(View.GONE);
                item.left.setVisibility(View.VISIBLE);
                item.tvMessage1.setText(message.getContent());
            }

            if (!App.loginUser.getRole().equals("Doctor")) {
                item.ivFace.setImageResource(R.drawable.doctor);
                item.ivFace1.setImageResource(R.drawable.user_a);
            } else {
                item.ivFace.setImageResource(R.drawable.user_a);
                item.ivFace1.setImageResource(R.drawable.doctor);
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActivityChatBinding binding = ActivityChatBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.topTitleLayout.setBackEnable(this);

        String chatRoomId = getIntent().getStringExtra("chatRoomId");

        binding.rvList.setAdapter(adapter);

        FirebaseFirestore
                .getInstance()
                .collection(FF.MESSAGES)
                .whereEqualTo("chatRoomId", chatRoomId)
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    adapter.getDatas().clear();
                    /*Dr.Brian
                    Message=
                    chatRoomId = "ab68a4f1-c1c6-4970-84fc-b21d3a3385f9"
                    content = "This is a Test"
                    dateTime ="2024-11-11 23:47:34"
                    username ="123456"
                     */
                    List<Message> messages = queryDocumentSnapshots.toObjects(Message.class);
                    Collections.sort(messages, new Comparator<Message>() {
                        @Override
                        public int compare(Message o1, Message o2) {
                            return o1.getDateTime().compareTo(o2.getDateTime());
                        }
                    });
                    adapter.getDatas().addAll(messages);
                    adapter.notifyDataSetChanged();
                });

        binding.tvSend.setOnClickListener(v -> {
            String content = binding.etMessage.getText().toString();
            if (content.isEmpty()) return;
            Message message = new Message();
            message.setUsername(App.loginUser.getUsername());
            message.setContent(content);
            message.setDateTime(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
            message.setChatRoomId(chatRoomId);
            FirebaseFirestore.getInstance().collection(FF.MESSAGES)
                    .add(message).addOnSuccessListener(documentReference -> {
                        adapter.getDatas().add(message);
                        adapter.notifyItemInserted(adapter.getDatas().size() - 1);
                        binding.etMessage.setText("");

                    });
        });
    }
}