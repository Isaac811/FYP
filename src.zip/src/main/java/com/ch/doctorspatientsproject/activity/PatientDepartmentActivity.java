package com.ch.doctorspatientsproject.activity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.GridView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.ch.doctorspatientsproject.R;
import com.ch.doctorspatientsproject.adapters.DepartmentGridAdapter;
import com.ch.doctorspatientsproject.views.TopTitleLayout;

public class PatientDepartmentActivity extends AppCompatActivity {

    private GridView regFunction;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_department);
        ((TopTitleLayout) findViewById(R.id.top_title_layout)).setBackEnable(this);

        regFunction = findViewById(R.id.gv_reg_function);
        regFunction.setAdapter(new DepartmentGridAdapter());

        regFunction.setOnItemClickListener((parent, view, position, id) -> {
            Intent intent = new Intent(PatientDepartmentActivity.this, PatientDepartmentBookActivity.class);
            intent.putExtra("departments", position);
            startActivity(intent);
        });
    }
}
