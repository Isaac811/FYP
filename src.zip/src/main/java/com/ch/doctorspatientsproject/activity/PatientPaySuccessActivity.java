package com.ch.doctorspatientsproject.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import com.ch.doctorspatientsproject.App;
import com.ch.doctorspatientsproject.R;
import com.ch.doctorspatientsproject.beans.AppointmentBean;
import com.ch.doctorspatientsproject.beans.ChatRoom;
import com.ch.doctorspatientsproject.util.FF;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.List;
import java.util.UUID;


public class PatientPaySuccessActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_pay_success);

        AppCompatButton bt_message = findViewById(R.id.bt_message);
        bt_message.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseFirestore instance = FirebaseFirestore.getInstance();
                String docId = ((AppointmentBean) getIntent().getSerializableExtra("doctor")).getDoctor_id();
                String userId = App.loginUser.getId();
                instance.collection(FF.CHAT_ROOM)
                        .whereEqualTo("docId", docId)
                        .whereEqualTo("userId", userId)
                        .get()
                        .addOnSuccessListener(queryDocumentSnapshots -> {
                            if (queryDocumentSnapshots.size() > 0) {
                                List<ChatRoom> chatRooms = queryDocumentSnapshots.toObjects(ChatRoom.class);
                                Intent intent = new Intent(PatientPaySuccessActivity.this, ChatActivity.class);
                                intent.putExtra("chatRoomId", chatRooms.get(0).getId());
                                startActivity(intent);
                                finish();
                            } else {
                                ChatRoom chatRoom = new ChatRoom();
                                chatRoom.setUserId(userId);
                                chatRoom.setDocId(docId);
                                chatRoom.setId(UUID.randomUUID().toString());
                                instance
                                        .collection(FF.CHAT_ROOM).
                                        add(chatRoom)
                                        .addOnSuccessListener(documentReference1 -> {
                                                    startActivity(new Intent(PatientPaySuccessActivity.this, ChatActivity.class).putExtra("chatRoomId", chatRoom.getId()));
                                                    finish();
                                                }
                                        );
                            }

                        });
            }
        });

    }
}