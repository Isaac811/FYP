package com.ch.doctorspatientsproject.activity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.ch.doctorspatientsproject.App;
import com.ch.doctorspatientsproject.R;
import com.ch.doctorspatientsproject.adapters.DoctorBookRecyclerAdapter;
import com.ch.doctorspatientsproject.beans.AppointmentBean;
import com.ch.doctorspatientsproject.beans.DoctorBean;
import com.ch.doctorspatientsproject.dialog.AppointmentNumberDialog;
import com.ch.doctorspatientsproject.util.FF;
import com.ch.doctorspatientsproject.views.TopTitleLayout;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.Collections;
import java.util.List;
import java.util.UUID;

public class PatientDepartmentBookActivity extends AppCompatActivity implements DoctorBookRecyclerAdapter.AppointmentListener, AppointmentNumberDialog.CustomDialogListener {

    private FirebaseFirestore db;
    private CollectionReference userCollection;

    private RecyclerView rv_list;
    private DoctorBookRecyclerAdapter adapter;

    private String departments = "";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_book);
        ((TopTitleLayout) findViewById(R.id.top_title_layout)).setBackEnable(this);

        db = FirebaseFirestore.getInstance();
        userCollection = db.collection(FF.USER);

        rv_list = findViewById(R.id.rv_list);

        int departmentsId = getIntent().getIntExtra("departments", -1);
        switch (departmentsId) {
            case 0:
                departments = "dermatology-department";
                break;
//            case 1:
//                departments = "ophthalmology-department";
//                break;
            case 1://2
                departments = "otolaryngology-department";
                break;
            case 2://3
                departments = "stomatology-department";
                break;
//            case 4:
//                departments = "neurology-department";
//                break;
            case 3://5
                departments = "pediatric-department";
                break;
            case 4://6
                departments = "gynecology-department";
                break;
//            case 7:
//                departments = "cardiology-department";
//                break;
            case 5://8
                departments = "psychiatry-department";
                break;
//            case 9:
//                departments = "emergency-department";
//                break;
            default:
                break;
        }
        userCollection
                .whereEqualTo("role", "Doctor")
                .whereEqualTo("departments", departments)
                .get().addOnSuccessListener(queryDocumentSnapshots -> {

                    Log.e("fk", "queryDocumentSnapshots " + queryDocumentSnapshots.isEmpty());
                    if (queryDocumentSnapshots.isEmpty()) {
                        return;
                    }
                    List<DoctorBean> doctorBeans = queryDocumentSnapshots.toObjects(DoctorBean.class);

                    Log.e("fk", "queryDocumentSnapshots " + doctorBeans.size());

                    if (adapter == null) {
                        adapter = new DoctorBookRecyclerAdapter(doctorBeans, PatientDepartmentBookActivity.this);
                        adapter.setAppointmentListener(PatientDepartmentBookActivity.this);
                        rv_list.setLayoutManager(new LinearLayoutManager(PatientDepartmentBookActivity.this));
                        rv_list.setAdapter(adapter);
                    } else {
                        adapter.notifyDataSetChanged();
                    }
                });
    }

    DoctorBean doctorBean;

    @Override
    public void appointment(DoctorBean doctorBean) {
        this.doctorBean = doctorBean;
        appointCount(doctorBean);


    }

    private void appointCount(DoctorBean doctorBean) {
        db
                .collection(FF.APPOINTMENT)
                .whereEqualTo("doctor_id", doctorBean.getId())
                .whereEqualTo("is_complete", "false")
                .get().addOnSuccessListener(queryDocumentSnapshots -> {
                    Log.e("fk", "queryDocumentSnapshots " + queryDocumentSnapshots.isEmpty());
                    if (queryDocumentSnapshots.isEmpty()) {
                        Toast.makeText(PatientDepartmentBookActivity.this, "No one is booked", Toast.LENGTH_SHORT).show();
                        Ok();
                        return;
                    }
                    List<AppointmentBean> doctorBeans = queryDocumentSnapshots.toObjects(AppointmentBean.class);
                    Collections.reverse(doctorBeans);
                    Log.e("fk", "queryDocumentSnapshots " + doctorBeans.size());

                    AppointmentNumberDialog customDialog = new AppointmentNumberDialog(PatientDepartmentBookActivity.this);
                    customDialog.setDialogListener(this);
                    customDialog.setContext(doctorBeans);
                    customDialog.show();

                });
    }

    @Override
    public void Ok() {
        AppointmentBean bean = new AppointmentBean();
        bean.setAppoint_id(UUID.randomUUID().toString());
        bean.setDoctor_id(doctorBean.getId());
        bean.setDoctor_name(doctorBean.getUsername());
        bean.setDoctor_gender(doctorBean.getGender());
        bean.setUser_id(App.loginUser.getId());
        bean.setUser_name(App.loginUser.getUsername());
        bean.setUser_email(App.loginUser.getEmail());

        Intent intent = new Intent(PatientDepartmentBookActivity.this, PatientAppointmentConfirmActivity.class);
        Bundle bundle = new Bundle();
        bundle.putSerializable("doctor", bean);
        intent.putExtras(bundle);
        startActivity(intent);
    }
}
