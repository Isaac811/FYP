package com.ch.doctorspatientsproject.activity;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.ch.doctorspatientsproject.R;
import com.ch.doctorspatientsproject.fragment.MapFragment;
import com.ch.doctorspatientsproject.fragment.PatientHomeFragment;
import com.ch.doctorspatientsproject.fragment.PatientMineFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.List;


public class PatientMainActivity extends AppCompatActivity {

    private Fragment[] fragments = {null, null, null};

    @SuppressLint("NonConstantResourceId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_main);

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        fragments[0] = new PatientHomeFragment();
        fragments[1] = new MapFragment();
        fragments[2] = new PatientMineFragment();
        loadFragment(fragments[0]);

        bottomNavigationView.setOnItemSelectedListener(item -> {
            Fragment selectedFragment = null;
            switch (item.getItemId()) {
                case R.id.navigation_home:
                    selectedFragment = fragments[0];
                    break;
                case R.id.navigation_msg:
                    selectedFragment = fragments[1];
                    break;
                case R.id.navigation_me:
                    selectedFragment = fragments[2];
                    break;
            }
            return loadFragment(selectedFragment);
        });
    }

    private boolean loadFragment(Fragment fragment) {
        if (fragment != null) {
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container, fragment)
                    .commit();
            return true;
        }
        return false;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        List<Fragment> fragments = getSupportFragmentManager().getFragments();
        if (fragments == null) {
            return;
        }
        for (Fragment fragment : fragments) {
            if (fragment != null) {
                fragment.onRequestPermissionsResult(requestCode, permissions, grantResults);
            }
        }
    }
}