package com.ch.doctorspatientsproject.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.ch.doctorspatientsproject.R;
import com.ch.doctorspatientsproject.activity.PatientBookActivity;
import com.ch.doctorspatientsproject.activity.PatientConsultationActivity;
import com.ch.doctorspatientsproject.activity.PatientDepartmentActivity;
import com.ch.doctorspatientsproject.adapters.DoctorRecyclerAdapter;
import com.ch.doctorspatientsproject.adapters.FunctionGridAdapter;
import com.ch.doctorspatientsproject.beans.DoctorBean;
import com.ch.doctorspatientsproject.databinding.FragmentPatientHomeBinding;
import com.ch.doctorspatientsproject.util.FF;
import com.ch.doctorspatientsproject.util.T;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.youth.banner.adapter.BannerImageAdapter;
import com.youth.banner.holder.BannerImageHolder;
import com.youth.banner.indicator.CircleIndicator;
import com.youth.banner.util.BannerUtils;

import java.util.ArrayList;
import java.util.List;


public class PatientHomeFragment extends Fragment {
    FragmentPatientHomeBinding binding;
    private ArrayList<Integer> integers = new ArrayList<>();

    private FirebaseFirestore db;
    private CollectionReference userCollection;

    private DoctorRecyclerAdapter adapter;

    private View rootView;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        if (rootView == null) {
            binding = FragmentPatientHomeBinding.inflate(inflater, container, false);
            rootView = binding.getRoot();
            setup(rootView);
        }
        return T.getNoParentView(rootView);
    }

    private void setup(View rootView) {
        integers.add(R.mipmap.ic_doctor_home_banner_1);
        integers.add(R.mipmap.ic_doctor_home_banner_2);
        integers.add(R.mipmap.ic_doctor_home_banner_3);
        BannerImageAdapter<Integer> bannerAdapter = new BannerImageAdapter<Integer>(integers) {
            @Override
            public void onBindView(BannerImageHolder holder, Integer data, int position, int size) {
                ImageView iv_image = (ImageView) holder.itemView;
                iv_image.setImageResource(data);
            }
        };
        binding.banner.setAdapter(bannerAdapter, true);
        binding.banner.setIndicator(new CircleIndicator(getContext()));
        binding.banner.setIndicatorSelectedWidth(BannerUtils.dp2px(15));

        binding.gvHomeFunction.setAdapter(new FunctionGridAdapter());
        binding.gvHomeFunction.setOnItemClickListener((parent, view, position, id1) -> {
            Intent intent = null;
            switch (position) {
                case 0:
                    intent = new Intent(getActivity(), PatientBookActivity.class);
                    break;
                case 1:
                    intent = new Intent(getActivity(), PatientDepartmentActivity.class);
                    break;
                case 2:
                    intent = new Intent(getActivity(), PatientConsultationActivity.class);
                    break;
            }
            startActivity(intent);
        });

        db = FirebaseFirestore.getInstance();
        userCollection = db.collection(FF.USER);

        userCollection
                .whereEqualTo("role", "Doctor")
                .get().addOnSuccessListener(queryDocumentSnapshots -> {
                    if (queryDocumentSnapshots.isEmpty()) {
                        return;
                    }
                    List<DoctorBean> doctorBeans = queryDocumentSnapshots.toObjects(DoctorBean.class);
                    if (adapter == null) {
                        adapter = new DoctorRecyclerAdapter();
                        adapter.setDatas(doctorBeans);
                        binding.rvList.setLayoutManager(new LinearLayoutManager(getActivity()));
                        binding.rvList.setAdapter(adapter);
                    } else {
                        adapter.notifyDataSetChanged();
                    }
                });
    }
}
