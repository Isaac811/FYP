package com.ch.doctorspatientsproject.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.ch.doctorspatientsproject.App;
import com.ch.doctorspatientsproject.R;
import com.ch.doctorspatientsproject.activity.DoctorAppointmentActivity;
import com.ch.doctorspatientsproject.activity.DoctorDetailActivity;
import com.ch.doctorspatientsproject.beans.AppointmentBean;
import com.ch.doctorspatientsproject.databinding.FragmentDoctorMineBinding;
import com.ch.doctorspatientsproject.util.FF;
import com.ch.doctorspatientsproject.util.T;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.List;


public class DoctorMineFragment extends Fragment {

    private FirebaseFirestore db;
    private CollectionReference userCollection;

    private FragmentDoctorMineBinding binding;
    private View rootView;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        if (rootView == null) {
            binding = FragmentDoctorMineBinding.inflate(inflater, container, false);
            rootView = binding.getRoot();
            setup(rootView);
        }
        return T.getNoParentView(rootView);
    }

    private void setup(View rootView) {
        db = FirebaseFirestore.getInstance();
        userCollection = db.collection(FF.APPOINTMENT);

        binding.txtUsername.setText(App.loginUser.getUsername());
        binding.txtRoleType.setText(App.loginUser.getRole());
        getAppointmentCount();

        binding.yuYueRLLyt.setOnClickListener(v -> {
            Intent intent = new Intent(getActivity(), DoctorAppointmentActivity.class);
            startActivity(intent);
        });

        binding.btnLogout.setOnClickListener(v -> getActivity().finish());

        binding.commentRLLyt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), DoctorDetailActivity.class);
                startActivity(intent);
            }
        });

        if (App.loginUser.getRole().equals("Doctor")) {
            if ("female".equals(App.loginUser.getGender())) {
                binding.personalProfilePhoto.setImageResource(R.mipmap.doctor_header_0);
            } else {
                binding.personalProfilePhoto.setImageResource(R.mipmap.doctor_header_1);
            }
            binding.txtUpdateContent.setVisibility(View.GONE);
        }
    }


    private void getAppointmentCount() {
        Log.e("fk", "getId= " + App.loginUser.getId());
        userCollection.whereEqualTo("doctor_id", App.loginUser.getId()).get().addOnSuccessListener(queryDocumentSnapshots -> {
            Log.e("fk", "queryDocumentSnapshots " + queryDocumentSnapshots.isEmpty());
            if (queryDocumentSnapshots.isEmpty()) {
                return;
            }
            List<AppointmentBean> doctorBeans = queryDocumentSnapshots.toObjects(AppointmentBean.class);

            Log.e("fk", "doctorBeans " + doctorBeans.size());
            // appointment count
            binding.parentUserNameTxt.setText(String.valueOf(doctorBeans.size()));
        });


    }
}