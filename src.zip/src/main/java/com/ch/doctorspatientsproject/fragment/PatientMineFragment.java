package com.ch.doctorspatientsproject.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.ch.doctorspatientsproject.App;
import com.ch.doctorspatientsproject.activity.PatientAppointmentActivity;
import com.ch.doctorspatientsproject.activity.PatientConsultationActivity;
import com.ch.doctorspatientsproject.activity.PatientPersonalActivity;
import com.ch.doctorspatientsproject.beans.AppointmentBean;
import com.ch.doctorspatientsproject.beans.ChatRoom;
import com.ch.doctorspatientsproject.databinding.FragmentPatientMineBinding;
import com.ch.doctorspatientsproject.util.FF;
import com.ch.doctorspatientsproject.util.T;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.List;


public class PatientMineFragment extends Fragment {

    private FirebaseFirestore db;
    private CollectionReference userCollection;
    private FragmentPatientMineBinding binding;
    private View rootView;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        if (rootView == null) {
            binding = FragmentPatientMineBinding.inflate(inflater, container, false);
            rootView = binding.getRoot();
            setup(rootView);
        }
        return T.getNoParentView(rootView);
    }

    private void setup(View rootView) {
        db = FirebaseFirestore.getInstance();
        userCollection = db.collection(FF.APPOINTMENT);

        binding.txtUsername.setText(App.loginUser.getUsername());
        binding.txtRoleType.setText(App.loginUser.getRole());
        getAppointmentCount();
        getConsultationCount();
        binding.yuYueRLLyt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), PatientAppointmentActivity.class);
                startActivity(intent);
            }
        });

        binding.kefuRLLyt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), PatientConsultationActivity.class);
                startActivity(intent);
            }
        });

        binding.btnLogout.setOnClickListener(v -> getActivity().finish());

        binding.txtUpdateContent.setOnClickListener(v -> {
            Intent intent = new Intent(getActivity(), PatientPersonalActivity.class);
            startActivity(intent);
        });

        binding.settingRLLyt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            }
        });
    }


    private void getAppointmentCount() {
        Log.e("fk", "getId= " + App.loginUser.getId());
        userCollection
                .whereEqualTo("user_id", App.loginUser.getId())
                .get().addOnSuccessListener(queryDocumentSnapshots -> {
                    Log.e("fk", "queryDocumentSnapshots " + queryDocumentSnapshots.isEmpty());
                    if (queryDocumentSnapshots.isEmpty()) {
                        return;
                    }
                    List<AppointmentBean> doctorBeans = queryDocumentSnapshots.toObjects(AppointmentBean.class);

                    Log.e("fk", "doctorBeans " + doctorBeans.size());
                    // appointment count
                    binding.parentUserNameTxt.setText(String.valueOf(doctorBeans.size()));
                });


    }

    private void getConsultationCount() {
        Log.e("fk", "getId= " + App.loginUser.getId());
        db.collection(FF.CHAT_ROOM)
                .whereEqualTo("userId", App.loginUser.getId())
                .get().addOnSuccessListener(queryDocumentSnapshots -> {
                    Log.e("fk", "queryDocumentSnapshots " + queryDocumentSnapshots.isEmpty());
                    if (queryDocumentSnapshots.isEmpty()) {
                        return;
                    }
                    List<ChatRoom> doctorBeans = queryDocumentSnapshots.toObjects(ChatRoom.class);

                    Log.e("fk", "doctorBeans " + doctorBeans.size());
                    // appointment count
                    binding.tvConsultation.setText(String.valueOf(doctorBeans.size()));
                });


    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        if (!hidden) {
            getAppointmentCount();
            getConsultationCount();
        }
    }
}