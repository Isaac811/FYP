package com.ch.doctorspatientsproject.fragment;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.ch.doctorspatientsproject.R;
import com.ch.doctorspatientsproject.util.T;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.UiSettings;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.AutocompletePrediction;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.api.model.RectangularBounds;
import com.google.android.libraries.places.api.net.FetchPlaceRequest;
import com.google.android.libraries.places.api.net.FindAutocompletePredictionsRequest;
import com.google.android.libraries.places.api.net.PlacesClient;

import java.util.Arrays;
import java.util.List;


public class MapFragment extends Fragment implements OnMapReadyCallback {

    private GoogleMap mMap;
    private FusedLocationProviderClient fusedLocationClient;
    private LocationCallback locationCallback;
    private PlacesClient placesClient;

    private static final String PREFS_NAME = "LocationPrefs";
    private static final String PREF_LATITUDE = "Latitude";
    private static final String PREF_LONGITUDE = "Longitude";

    private Marker locationMarker;

    private LatLng locLatLng;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_map, null, false);
        setup(rootView);
        return rootView;
    }

    private void setup(View rootView) {
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(requireContext());

        if (!Places.isInitialized()) {
            Places.initialize(requireContext(), "AIzaSyBiXBVnPtI4UJE1vJ-qr8aFuZQvc7iLpIQ");
        }
        placesClient = Places.createClient(requireContext());

        SupportMapFragment mapFragment = (SupportMapFragment) getChildFragmentManager().findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }
    }

    @SuppressLint("MissingPermission")
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);

        UiSettings uiSettings = mMap.getUiSettings();
        uiSettings.setMyLocationButtonEnabled(false);

        showCachedLocation();

        mMap.setMyLocationEnabled(true);
        requestCurrentLocation();
    }

    private void showCachedLocation() {
        SharedPreferences prefs = requireContext().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        if (prefs.contains(PREF_LATITUDE) && prefs.contains(PREF_LONGITUDE)) {
            double latitude = Double.longBitsToDouble(prefs.getLong(PREF_LATITUDE, 0));
            double longitude = Double.longBitsToDouble(prefs.getLong(PREF_LONGITUDE, 0));
            LatLng cachedLatLng = new LatLng(latitude, longitude);
            this.locLatLng = cachedLatLng;

            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(cachedLatLng, 12));

            locationMarker = mMap.addMarker(new MarkerOptions()
                    .position(cachedLatLng)
                    .title("Your Location")
                    .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE)) // 蓝色标记
            );

            searchNearbyHospitals(cachedLatLng);
        }
    }

    @SuppressLint("MissingPermission")
    private void requestCurrentLocation() {
        LocationRequest locationRequest = LocationRequest.create()
                .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
                .setInterval(10000)
                .setFastestInterval(5000);

        locationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult locationResult) {
                if (locationResult == null) {
                    return;
                }
                for (Location location : locationResult.getLocations()) {
                    if (location != null) {
                        LatLng currentLatLng = new LatLng(location.getLatitude(), location.getLongitude());
                        MapFragment.this.locLatLng = currentLatLng;
                        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(currentLatLng, 12));
                        cacheLocation(location);
                        if (locationMarker != null) {
                            locationMarker.setPosition(currentLatLng);
                        } else {
                            locationMarker = mMap.addMarker(new MarkerOptions()
                                    .position(currentLatLng)
                                    .title("Your Location")
                                    .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE))
                            );
                        }

                        searchNearbyHospitals(currentLatLng);

                        fusedLocationClient.removeLocationUpdates(locationCallback);
                        break;
                    }
                }
            }
        };

        fusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, null);
    }


    private void searchNearbyHospitals(LatLng location) {
        String query = "hospital";
        FindAutocompletePredictionsRequest request = FindAutocompletePredictionsRequest.builder()
                .setQuery(query)
                .setLocationBias(RectangularBounds.newInstance(
                        new LatLng(location.latitude - 0.05, location.longitude - 0.05),
                        new LatLng(location.latitude + 0.05, location.longitude + 0.05)
                ))
                .build();

        placesClient.findAutocompletePredictions(request)
                .addOnSuccessListener(response -> {
                    for (AutocompletePrediction prediction : response.getAutocompletePredictions()) {

                        String placeId = prediction.getPlaceId();
                        String name = prediction.getPrimaryText(null).toString();
                        fetchPlaceDetails(placeId, name);
                    }
                })
                .addOnFailureListener(exception -> {
                    exception.printStackTrace();
                });
    }

    private void fetchPlaceDetails(String placeId, String name) {
        List<Place.Field> placeFields = Arrays.asList(Place.Field.ID, Place.Field.NAME, Place.Field.LAT_LNG);
        FetchPlaceRequest request = FetchPlaceRequest.builder(placeId, placeFields).build();

        placesClient.fetchPlace(request)
                .addOnSuccessListener(response -> {
                    Place place = response.getPlace();
                    LatLng hospitalLatLng = place.getLatLng();
                    if (hospitalLatLng != null) {
                        Marker marker = mMap.addMarker(new MarkerOptions()
                                .position(hospitalLatLng)
                                .title(name)
                                .icon(createCustomMarker(requireContext(), name, T.getShowDistance(getActivity(), MapFragment.this.locLatLng, hospitalLatLng))) // 使用自定义图标
                        );
                        marker.setTag(hospitalLatLng);
                    }
                    mMap.setOnMarkerClickListener(marker -> {
                        LatLng latLng = (LatLng) marker.getTag();
                        if (latLng != null) {
                            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("geo:" + latLng.latitude + "," + latLng.longitude + "?q=" + latLng.latitude + "," + latLng.longitude + "(" + marker.getTitle() + ")"));
                            intent.setPackage("com.google.android.apps.maps");
                            startActivity(intent);
                        }
                        return false;
                    });
                })
                .addOnFailureListener(exception -> {
                    exception.printStackTrace();
                });
    }

    private BitmapDescriptor createCustomMarker(Context context, String title, String distance) {
        View markerView = LayoutInflater.from(context).inflate(R.layout.custom_marker, null);
        ImageView markerImage = markerView.findViewById(R.id.marker_image);
        TextView markerTitle = markerView.findViewById(R.id.marker_title);
        markerImage.setImageResource(R.drawable.svg_hospital);
        markerTitle.setText(distance);
        markerView.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
        markerView.layout(0, 0, markerView.getMeasuredWidth(), markerView.getMeasuredHeight());
        markerView.buildDrawingCache();
        Bitmap bitmap = Bitmap.createBitmap(markerView.getMeasuredWidth(), markerView.getMeasuredHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        markerView.draw(canvas);

        return BitmapDescriptorFactory.fromBitmap(bitmap);
    }


    private void cacheLocation(Location location) {
        SharedPreferences prefs = requireContext().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putLong(PREF_LATITUDE, Double.doubleToRawLongBits(location.getLatitude()));
        editor.putLong(PREF_LONGITUDE, Double.doubleToRawLongBits(location.getLongitude()));
        editor.apply();
    }
}
