package com.ch.doctorspatientsproject.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.ch.doctorspatientsproject.App;
import com.ch.doctorspatientsproject.R;
import com.ch.doctorspatientsproject.activity.ChatActivity;
import com.ch.doctorspatientsproject.activity.DoctorInquiryConfirmActivity;
import com.ch.doctorspatientsproject.adapters.DoctorAppointmentRecyclerAdapter;
import com.ch.doctorspatientsproject.beans.AppointmentBean;
import com.ch.doctorspatientsproject.beans.ChatRoom;
import com.ch.doctorspatientsproject.databinding.FragmentDoctorHomeBinding;
import com.ch.doctorspatientsproject.util.FF;
import com.ch.doctorspatientsproject.util.T;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.youth.banner.adapter.BannerImageAdapter;
import com.youth.banner.holder.BannerImageHolder;
import com.youth.banner.indicator.CircleIndicator;
import com.youth.banner.util.BannerUtils;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;


public class DoctorHomeFragment extends Fragment implements DoctorAppointmentRecyclerAdapter.InquiryListener, DoctorAppointmentRecyclerAdapter.MessageListener {

    FragmentDoctorHomeBinding binding;

    private List<Integer> integers = new ArrayList<>();
    private FirebaseFirestore db;
    private CollectionReference userCollection;
    private DoctorAppointmentRecyclerAdapter adapter;
    private View rootView;

    List<AppointmentBean> doctorBeans = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        if (rootView == null) {
            binding = FragmentDoctorHomeBinding.inflate(inflater, container, false);
            rootView = binding.getRoot();
            setup(rootView);
        }
        return T.getNoParentView(rootView);
    }

    private void setup(View rootView) {
        integers.add(R.mipmap.ic_doctor_home_banner_1);
        integers.add(R.mipmap.ic_doctor_home_banner_2);
        integers.add(R.mipmap.ic_doctor_home_banner_3);
        BannerImageAdapter<Integer> bannerAdapter = new BannerImageAdapter<Integer>(integers) {
            @Override
            public void onBindView(BannerImageHolder holder, Integer data, int position, int size) {
                ImageView iv_image = (ImageView) holder.itemView;
                iv_image.setImageResource(data);
            }
        };
        binding.banner.setAdapter(bannerAdapter, true);
        binding.banner.setIndicator(new CircleIndicator(getContext()));
        binding.banner.setIndicatorSelectedWidth(BannerUtils.dp2px(15));

        db = FirebaseFirestore.getInstance();
        userCollection = db.collection(FF.APPOINTMENT);
    }

    private void getInquiry() {
        userCollection
                .whereEqualTo("doctor_id", App.loginUser.getId())
                .get().addOnSuccessListener(queryDocumentSnapshots -> {

                    doctorBeans.clear();
                    if (queryDocumentSnapshots.isEmpty()) {
                        if (adapter != null) {
                            adapter.notifyDataSetChanged();
                        }
                        return;
                    }
                    doctorBeans.addAll(queryDocumentSnapshots.toObjects(AppointmentBean.class));


                    doctorBeans.sort(new Comparator<AppointmentBean>() {
                        @Override
                        public int compare(AppointmentBean o1, AppointmentBean o2) {

                            StringBuffer sb1 = new StringBuffer();
                            sb1.append("true".equals(o1.getIs_complete()) ? "1" : "2");
                            sb1.append("_").append(o1.getAppoint_date());
                            sb1.append("_").append(o1.getAppoint_time());

                            StringBuffer sb2 = new StringBuffer();
                            sb2.append("true".equals(o2.getIs_complete()) ? "1" : "2");
                            sb2.append("_").append(o2.getAppoint_date());
                            sb2.append("_").append(o2.getAppoint_time());

                            return sb2.toString().compareTo(sb1.toString());
                        }
                    });

                    if (adapter == null) {
                        adapter = new DoctorAppointmentRecyclerAdapter(doctorBeans);
                        adapter.setForHome(true);
                        adapter.setInquiryListener(this);
                        adapter.setMessageListener(this);
                        binding.rvList.setLayoutManager(new LinearLayoutManager(getActivity()));
                        binding.rvList.setAdapter(adapter);
                    } else {
                        adapter.notifyDataSetChanged();
                    }
                });
    }

    @Override
    public void onResume() {
        super.onResume();
        getInquiry();
    }

    @Override
    public void inquiry(AppointmentBean bean) {
        Intent intent = new Intent(getActivity(), DoctorInquiryConfirmActivity.class);
        Bundle bundle = new Bundle();
        bundle.putSerializable("doctor", bean);
        intent.putExtras(bundle);
        startActivity(intent);
    }

    @Override
    public void message(AppointmentBean bean) {
        FirebaseFirestore instance = FirebaseFirestore.getInstance();
        instance.collection(FF.CHAT_ROOM)
                .whereEqualTo("docId", bean.getDoctor_id())
                .whereEqualTo("userId", bean.getUser_id())
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    if (queryDocumentSnapshots.size() > 0) {
                        List<ChatRoom> chatRooms = queryDocumentSnapshots.toObjects(ChatRoom.class);
                        Intent intent = new Intent(getContext(), ChatActivity.class);
                        intent.putExtra("chatRoomId", chatRooms.get(0).getId());
                        startActivity(intent);
                    } else {
                        ChatRoom chatRoom = new ChatRoom();
                        chatRoom.setUserId(bean.getUser_id());
                        chatRoom.setDocId(bean.getDoctor_id());
                        chatRoom.setId(UUID.randomUUID().toString());
                        instance
                                .collection(FF.CHAT_ROOM).
                                add(chatRoom)
                                .addOnSuccessListener(documentReference1 -> {
                                            startActivity(new Intent(getContext(), ChatActivity.class).putExtra("chatRoomId", chatRoom.getId()));
                                        }
                                );
                    }
                });

    }
}
