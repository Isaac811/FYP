package com.ch.doctorspatientsproject.adapters;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.ch.doctorspatientsproject.R;
import com.ch.doctorspatientsproject.activity.PatientDoctorDetailActivity;
import com.ch.doctorspatientsproject.beans.DoctorBean;

import java.util.List;


public class DoctorRecyclerAdapter extends RecyclerView.Adapter<DoctorRecyclerAdapter.HomeDoctorAdapterViewHolder> {

    private List<DoctorBean> datas;

    public void setDatas(List<DoctorBean> datas) {
        this.datas = datas;
    }

    static class HomeDoctorAdapterViewHolder extends RecyclerView.ViewHolder {
        private ImageView iv_item;
        private TextView tv_item_0;
        private TextView tv_item_1;
        private TextView tv_item_2;

        public HomeDoctorAdapterViewHolder(@NonNull View view) {
            super(view);
            iv_item = view.findViewById(R.id.iv_item);
            tv_item_0 = view.findViewById(R.id.tv_item_0);
            tv_item_1 = view.findViewById(R.id.tv_item_1);
            tv_item_2 = view.findViewById(R.id.tv_item_2);
        }
    }

    @NonNull
    @Override
    public HomeDoctorAdapterViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_recycler_doctor, parent, false);
        HomeDoctorAdapterViewHolder holder = new HomeDoctorAdapterViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull HomeDoctorAdapterViewHolder holder, int position) {
        DoctorBean data = datas.get(position);
        if ("female".equals(data.getGender())) {
            holder.iv_item.setImageResource(R.mipmap.doctor_header_0);
        } else {
            holder.iv_item.setImageResource(R.mipmap.doctor_header_1);
        }

        holder.tv_item_0.setText(data.getUsername());
        holder.tv_item_1.setText(data.getDepartments());
        holder.tv_item_2.setText(data.getMedicInfo());
        holder.itemView.setOnClickListener(v -> {
            Context context = holder.itemView.getContext();
            Intent intent = new Intent(context, PatientDoctorDetailActivity.class);
            Bundle bundle = new Bundle();
            bundle.putSerializable("DoctorBean", datas.get(position));
            intent.putExtras(bundle);
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return datas == null ? 0 : datas.size();
    }
}
