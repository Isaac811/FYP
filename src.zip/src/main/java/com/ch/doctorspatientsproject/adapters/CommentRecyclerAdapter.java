package com.ch.doctorspatientsproject.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.ch.doctorspatientsproject.R;
import com.ch.doctorspatientsproject.beans.RespCommentBean;

import java.util.List;


public class CommentRecyclerAdapter extends RecyclerView.Adapter<CommentRecyclerAdapter.CommentVH> {

    private List<RespCommentBean> respComments;

    public CommentRecyclerAdapter(List<RespCommentBean> respComments) {
        this.respComments = respComments;
    }

    @NonNull
    @Override
    public CommentVH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new CommentVH(LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_recycler_comment, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull CommentVH holder, int position) {
        holder.tv_comment_name.setText(respComments.get(position).getComment_text());
        holder.tv_comment_date.setText(respComments.get(position).getComment_date());
        holder.tv_comment_user_name.setText("user");
    }

    @Override
    public int getItemCount() {
        return respComments.size();
    }

    public class CommentVH extends RecyclerView.ViewHolder {

        private ImageView civ_user_head;
        private TextView tv_comment_name;
        private TextView tv_comment_user_name;
        private TextView tv_comment_date;


        public CommentVH(@NonNull View itemView) {
            super(itemView);
            civ_user_head = itemView.findViewById(R.id.iv_item);
            tv_comment_name = itemView.findViewById(R.id.tv_item_0);
            tv_comment_user_name = itemView.findViewById(R.id.tv_item_1);
            tv_comment_date = itemView.findViewById(R.id.tv_item_2);
        }
    }
}
