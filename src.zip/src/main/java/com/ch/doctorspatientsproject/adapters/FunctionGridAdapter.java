package com.ch.doctorspatientsproject.adapters;


import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.ch.doctorspatientsproject.R;

public class FunctionGridAdapter extends BaseAdapter {

    @Override
    public int getCount() {
        return 3;
    }

    @Override
    public Object getItem(int i) {
        return i;
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        view = View.inflate(viewGroup.getContext(), R.layout.adapter_grid_function, null);

        ImageView imgPic = view.findViewById(R.id.homeGvImg);
        TextView txtInfo = view.findViewById(R.id.homeGvTxt);

        switch (i) {
            case 0:
                imgPic.setImageResource(R.drawable.frag_gv_function_home_yqhy_icon);
                txtInfo.setText("Appointment");
                break;
            case 1:
                imgPic.setImageResource(R.drawable.frag_gv_function_home_zxkf_icon);
                txtInfo.setText("Department");
                break;
            case 2:
                imgPic.setImageResource(R.drawable.frag_gv_function_shcx_icon);
                txtInfo.setText("Consultation");
                break;
            default:
                break;
        }
        return view;
    }
}
