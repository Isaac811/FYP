package com.ch.doctorspatientsproject.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.ch.doctorspatientsproject.R;
import com.ch.doctorspatientsproject.beans.AppointmentBean;

import java.util.List;


public class PatientAppointmentRecyclerAdapter extends RecyclerView.Adapter<PatientAppointmentRecyclerAdapter.HomeDoctorAdapterViewHolder> {

    private List<AppointmentBean> datas;

    static class HomeDoctorAdapterViewHolder extends RecyclerView.ViewHolder {
        private ImageView iv_item;
        private TextView tv_move_name;
        private TextView tv_director;
        private TextView tv_writer;
        private Button btnAppont;

        public HomeDoctorAdapterViewHolder(@NonNull View view) {
            super(view);
            tv_move_name = view.findViewById(R.id.tv_item_0);
            iv_item = view.findViewById(R.id.iv_item);
            tv_director = view.findViewById(R.id.tv_item_1);
            tv_writer = view.findViewById(R.id.tv_item_2);
            btnAppont = view.findViewById(R.id.btn_appoint);
        }
    }

    public PatientAppointmentRecyclerAdapter(List<AppointmentBean> datas) {
        this.datas = datas;
    }

    @NonNull
    @Override
    public HomeDoctorAdapterViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_recycler_patient_appointment, parent, false);
        HomeDoctorAdapterViewHolder holder = new HomeDoctorAdapterViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull HomeDoctorAdapterViewHolder holder, int position) {
        AppointmentBean data = datas.get(position);
        holder.tv_move_name.setText(data.getDoctor_name());
        holder.tv_director.setText(data.getAppoint_date() + "-" + data.getAppoint_time());
        holder.tv_writer.setText(data.getAppoint_remark());

        if ("female".equals(data.getDoctor_gender())) {
            holder.iv_item.setImageResource(R.mipmap.doctor_header_0);
        } else {
            holder.iv_item.setImageResource(R.mipmap.doctor_header_1);
        }

        holder.btnAppont.setOnClickListener(v -> {

            if (caseListener != null) {
                caseListener.selcase(data);
            }
        });
    }

    @Override
    public int getItemCount() {
        return datas.size();
    }

    private CaseListener caseListener;

    public void setAppointmentListener(CaseListener caseListener) {
        this.caseListener = caseListener;
    }

    public interface CaseListener {
        void selcase(AppointmentBean bean);
    }
}
