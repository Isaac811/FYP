package com.ch.doctorspatientsproject.adapters;


import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.ch.doctorspatientsproject.R;

public class DepartmentGridAdapter extends BaseAdapter {

    @Override
    public int getCount() {
        return 10;
    }

    @Override
    public Object getItem(int i) {
        return i;
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        view = View.inflate(viewGroup.getContext(), R.layout.adapter_grid_department, null);

        ImageView imgPic = view.findViewById(R.id.homeGvImg);
        TextView txtInfo = view.findViewById(R.id.homeGvTxt);

        switch (i) {
            case 0:
                imgPic.setImageResource(R.drawable.pf_departments);
                txtInfo.setText("dermatology");
                break;
            case 1:
                imgPic.setImageResource(R.drawable.yanke_departments);
                txtInfo.setText("otolaryngology");
                break;
            case 2:
                imgPic.setImageResource(R.drawable.ebihou_departments);
                txtInfo.setText("stomatology");
                break;
            case 3:
                imgPic.setImageResource(R.drawable.sj_departments);
                txtInfo.setText("pediatric");
                break;
            case 4:
                imgPic.setImageResource(R.drawable.er_departments);
                txtInfo.setText("gynecology");
                break;
            case 5:
                imgPic.setImageResource(R.drawable.xn_departments);
                txtInfo.setText("psychiatry");
                break;
            default:
                break;
        }
        return view;
    }
}
