package com.ch.doctorspatientsproject.adapters;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.ch.doctorspatientsproject.R;
import com.ch.doctorspatientsproject.beans.AppointmentBean;

import java.util.List;

public class DoctorAppointmentRecyclerAdapter extends RecyclerView.Adapter<DoctorAppointmentRecyclerAdapter.HomeDoctorAdapterViewHolder> {

    private List<AppointmentBean> datas;
    private boolean forHome = false;

    public void setForHome(boolean forHome) {
        this.forHome = forHome;
    }

    static class HomeDoctorAdapterViewHolder extends RecyclerView.ViewHolder {

        private ImageView iv_item;
        private TextView tv_item_0;
        private TextView tv_item_1;
        private TextView tv_item_2;
        private Button btnAppont;
        private Button btnMessage;

        public HomeDoctorAdapterViewHolder(@NonNull View view) {
            super(view);
            iv_item = view.findViewById(R.id.iv_item);
            tv_item_0 = view.findViewById(R.id.tv_item_0);
            tv_item_1 = view.findViewById(R.id.tv_item_1);
            tv_item_2 = view.findViewById(R.id.tv_item_2);
            btnAppont = view.findViewById(R.id.btn_appoint);
            btnMessage = view.findViewById(R.id.btn_message);
        }
    }

    public DoctorAppointmentRecyclerAdapter(List<AppointmentBean> datas) {
        this.datas = datas;
    }

    @NonNull
    @Override
    public HomeDoctorAdapterViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_recycler_doctor_appointment, parent, false);
        HomeDoctorAdapterViewHolder holder = new HomeDoctorAdapterViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull HomeDoctorAdapterViewHolder holder, int position) {

        AppointmentBean data = datas.get(position);

        holder.tv_item_0.setText(data.getUser_name());
        holder.tv_item_1.setText(data.getAppoint_date() + "-" + data.getAppoint_time());
        holder.tv_item_2.setText(data.getAppoint_remark());

        holder.btnAppont.setOnClickListener(v -> {

            if (inquiryListener != null) {
                inquiryListener.inquiry(datas.get(position));
            }
        });

        holder.btnMessage.setOnClickListener(v -> {

            if (messageListener != null) {
                messageListener.message(datas.get(position));
            }
        });

        if (forHome) {
            boolean is_complete = "true".equals(data.getIs_complete());
            if (is_complete) {
                holder.tv_item_0.setTextColor(holder.tv_item_0.getResources().getColor(android.R.color.darker_gray));
                holder.btnAppont.setEnabled(false);
                holder.btnMessage.setEnabled(false);
            } else {
                holder.tv_item_0.setTextColor(Color.BLACK);
                holder.btnAppont.setEnabled(true);
                holder.btnMessage.setEnabled(true);
            }
        }
    }

    @Override
    public int getItemCount() {
        return datas.size();
    }

    private InquiryListener inquiryListener;


    public void setInquiryListener(InquiryListener inquiryListener) {
        this.inquiryListener = inquiryListener;
    }

    public interface InquiryListener {
        void inquiry(AppointmentBean bean);
    }

    private MessageListener messageListener;


    public void setMessageListener(MessageListener messageListener) {
        this.messageListener = messageListener;
    }

    public interface MessageListener {
        void message(AppointmentBean bean);
    }
}
