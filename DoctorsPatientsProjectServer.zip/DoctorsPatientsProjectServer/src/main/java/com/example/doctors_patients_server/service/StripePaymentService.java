package com.example.doctors_patients_server.service;

import com.stripe.Stripe;
import com.stripe.exception.StripeException;
import com.stripe.model.Customer;
import com.stripe.model.EphemeralKey;
import com.stripe.model.PaymentIntent;
import com.stripe.net.RequestOptions;
import com.stripe.param.CustomerCreateParams;
import com.stripe.param.EphemeralKeyCreateParams;
import com.stripe.param.PaymentIntentCreateParams;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class StripePaymentService {

    final static private String publishable_key = "pk_test_51Ql8OJKuvShej72O0Fu3G3YCH12mzJOY2G23ysicw9T5YOubwhqZlrf8QEWE5ffT62UednZA1Ht6bqXbQN3kcQU900xwBcODT8";
    final static private String secret_key = "sk_test_51Ql8OJKuvShej72OkJ6lgP4lf446lN9Wx27AjO9ZPmikmasHQmRIRdmcU7hwmtX8C5LAsPdc0AQWVUpzPQgT56sa00SbzGxc9r";

    static {
        Stripe.apiKey = secret_key;
    }

    public Map<String,String> createPaymentIntent(long amount) {
        Map<String,String> response = new HashMap<>();
        try {
            CustomerCreateParams customerParams = CustomerCreateParams.builder()
                    .setEmail("test@example.com")
                    .build();
            Customer customer = Customer.create(customerParams);

            PaymentIntentCreateParams paymentIntentParams = PaymentIntentCreateParams.builder()
                    .setAmount(amount)
                    .setCurrency("eur")
                    .setCustomer(customer.getId())
                    .build();

            PaymentIntent paymentIntent = PaymentIntent.create(paymentIntentParams);

            EphemeralKeyCreateParams ephemeralKeyParams = EphemeralKeyCreateParams.builder()
                    .setCustomer(customer.getId()).build();

            RequestOptions requestOptions = RequestOptions.builder()
                    .setStripeVersionOverride("2020-08-27")
                    .build();

            EphemeralKey ephemeralKey = EphemeralKey.create(ephemeralKeyParams, requestOptions);


            response.put("customer", customer.getId());
            response.put("ephemeralKey", ephemeralKey.getId());
            response.put("paymentIntent", paymentIntent.getClientSecret());
            response.put("publishableKey", publishable_key);

        } catch (StripeException e) {
            e.printStackTrace();
            response.put("error", e.getMessage());
        }

        return response;
    }
}
