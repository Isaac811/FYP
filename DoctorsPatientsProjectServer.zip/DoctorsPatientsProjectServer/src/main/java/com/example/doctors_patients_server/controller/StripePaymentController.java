package com.example.doctors_patients_server.controller;

import com.example.doctors_patients_server.service.StripePaymentService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.Map;

@RestController
@RequestMapping("/api/payment")
public class StripePaymentController {

    @Resource
    private StripePaymentService paymentService;


    @RequestMapping("/create-payment-intent")
    public Map<String, String> createPaymentIntent(@RequestParam long amount) {
        System.out.println("############### create new payment intent: amount = " + amount + " ###############");
        return paymentService.createPaymentIntent(amount);
    }
}
