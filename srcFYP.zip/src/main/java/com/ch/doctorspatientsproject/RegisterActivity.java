package com.ch.doctorspatientsproject;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.RadioButton;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.ch.doctorspatientsproject.beans.AppointDateBean;
import com.ch.doctorspatientsproject.beans.UserBean;
import com.ch.doctorspatientsproject.databinding.ActivityRegisterBinding;
import com.ch.doctorspatientsproject.systembar.ImmersiveBarUtil;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class RegisterActivity extends AppCompatActivity {

    String departments = "";

    FirebaseFirestore instance;
    String id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ImmersiveBarUtil.immersiveBar(this);
        ActivityRegisterBinding binding = ActivityRegisterBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        instance = FirebaseFirestore.getInstance();

        binding.btRegister.setOnClickListener(v -> {
            String username = binding.editTextText.getText().toString();
            String password = binding.editTextTextPassword.getText().toString();
            String password2 = binding.editTextTextPassword2.getText().toString();
            if (username.isEmpty()) {
                Toast.makeText(RegisterActivity.this, "Please enter a user name！", Toast.LENGTH_SHORT).show();
                return;
            }
            if (password.isEmpty()) {
                Toast.makeText(RegisterActivity.this, "Please enter password！", Toast.LENGTH_SHORT).show();
                return;
            }
            if (!password.equals(password2)) {
                Toast.makeText(RegisterActivity.this, "The two passwords are inconsistent！", Toast.LENGTH_SHORT).show();
                return;
            }

            for (int i = 0; i < yourChoices.size(); i++) {
                Log.e("fk", "fenghj" + doctorDate[yourChoices.get(i)]);
            }

            instance
                    .collection("_user")
                    .get()
                    .addOnSuccessListener(queryDocumentSnapshots -> {
                        List<UserBean> userList = queryDocumentSnapshots.toObjects(UserBean.class);
                        List<UserBean> collect =
                                userList
                                        .stream()
                                        .filter(user -> user.getUsername().equals(username)).collect(Collectors.toList());
                        if (!collect.isEmpty()) {
                            Toast.makeText(RegisterActivity.this, "Registration Failed！", Toast.LENGTH_SHORT).show();
                        } else {
                            UserBean data = new UserBean();
                            data.setPassword(password);
                            data.setUsername(username);
                            id = UUID.randomUUID().toString();
                            data.setId(id);

                            RadioButton rb = findViewById(binding.radioGroup.getCheckedRadioButtonId());
                            data.setRole(rb.getText().toString());
                            if (rb.getText().toString().equals("medic")) {
                                data.setDepartments(departments);
                                data.setMedicInfo(binding.etInfo.getText().toString());
                            } else {
                                data.setDepartments("");
                                data.setMedicInfo("");
                            }

                            instance.collection("_user")
                                    .add(data)
                                    .addOnSuccessListener(documentReference -> {
                                        Log.e("fk", "Registration success");

                                        for (int i = 0; i < yourChoices.size(); i++) {
                                            registerDoctorAppointDate(id, doctorDate[yourChoices.get(i)]);
                                        }
                                        Toast.makeText(RegisterActivity.this, "Registration success", Toast.LENGTH_SHORT).show();
                                        finish();
                                    }).addOnFailureListener(e -> Log.d("TAG", "onFailure: " + e.getLocalizedMessage()));

                        }
                    }).addOnFailureListener(e -> Log.d("TAG", "onFailure: " + e.getLocalizedMessage()));
        });


        binding.radioGroup.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.radioButton2) {
                binding.spDepartments.setVisibility(View.VISIBLE);
                binding.etInfo.setVisibility(View.VISIBLE);
                binding.tvDoctorDate.setVisibility(View.VISIBLE);
            } else {
                binding.spDepartments.setVisibility(View.GONE);
                binding.etInfo.setVisibility(View.GONE);
                binding.tvDoctorDate.setVisibility(View.GONE);
            }
        });
        binding.tvDoctorDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final boolean initChoseSets[] = {false, false, false, false, false};
                yourChoices.clear();

                AlertDialog.Builder multiDialog = new AlertDialog.Builder(RegisterActivity.this);
                multiDialog.setTitle("选择医生问诊时间");
                multiDialog.setMultiChoiceItems(doctorDate, initChoseSets, (dialog, which, isChecked) -> {
                    if (isChecked) {
                        yourChoices.add(which);
                    } else {
                        yourChoices.remove(which);
                    }
                });

                multiDialog.setPositiveButton("确定", (dialog, which) -> {
                    int size = yourChoices.size();
                    String str = "";
                    for (int i = 0; i < size; i++) {
                        str += doctorDate[yourChoices.get(i)] + " ";
                    }

                    binding.tvDoctorDate.setText(str);
                });
                multiDialog.show();

            }
        });
        binding.spDepartments.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                departments = getResources().getStringArray(R.array.departments)[position];
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    ArrayList<Integer> yourChoices = new ArrayList();
    final String[] doctorDate = {"10:00-11:00", "11:00-12:00", "13:00-14:00", "14:00-15:00", "15:00-16:00"};

    private void registerDoctorAppointDate(String id, String date) {

        AppointDateBean dateBean = new AppointDateBean();
        dateBean.setDate_id(UUID.randomUUID().toString());
        dateBean.setDoctor_id(id);
        dateBean.setIs_appoint("false");
        dateBean.setDoctor_date(date);

        instance.collection("doctor_appoint_date")
                .add(dateBean)
                .addOnSuccessListener(documentReference -> {
                    Log.e("fk", "registerDoctorAppointDate id =" + id + " date =" + date);
                }).addOnFailureListener(e -> Log.d("TAG", "onFailure: " + e.getLocalizedMessage()));
    }
}