package com.ch.doctorspatientsproject;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.ch.doctorspatientsproject.adapters.RvMyAppointmentDoctorAdapter;
import com.ch.doctorspatientsproject.beans.AppointmentBean;
import com.ch.doctorspatientsproject.widget.StatusBarCommonTitleWidget;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.List;


public class MyAppointmentAty extends AppCompatActivity implements StatusBarCommonTitleWidget.OnClickBackListener
        , RvMyAppointmentDoctorAdapter.CaseListener {

    private FirebaseFirestore db;
    private CollectionReference userCollection;

    private StatusBarCommonTitleWidget ctv;
    private RecyclerView rcv;
    private RvMyAppointmentDoctorAdapter adapter;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.aty_my_appointment_layout);

        db = FirebaseFirestore.getInstance();
        userCollection = db.collection("appointment");

        ctv = findViewById(R.id.cvTilteCustom);
        ctv.isHiddenCloseBtn();
        ctv.setLeftContent("");
        ctv.setMiddelContent("My Appointment");
        ctv.setOnClickBackListener(this);

        rcv = findViewById(R.id.rv_my_appointment);

        userCollection
                .whereEqualTo("user_id", ParameterInfo.userBean.getId())
                .get().addOnSuccessListener(queryDocumentSnapshots -> {

                    Log.e("fk", "queryDocumentSnapshots " + queryDocumentSnapshots.isEmpty());
                    if (queryDocumentSnapshots.isEmpty()) {
                        return;
                    }
                    List<AppointmentBean> doctorBeans = queryDocumentSnapshots.toObjects(AppointmentBean.class);

                    Log.e("fk", "queryDocumentSnapshots " + doctorBeans.size());

                    if (adapter == null) {
                        adapter = new RvMyAppointmentDoctorAdapter(doctorBeans, MyAppointmentAty.this);
                        adapter.setAppointmentListener(this);
                        rcv.setLayoutManager(new LinearLayoutManager(MyAppointmentAty.this));
                        rcv.setAdapter(adapter);
                    } else {
                        adapter.notifyDataSetChanged();
                    }
                });
    }

    @Override
    public void selcase(AppointmentBean bean) {
        Intent intent =new Intent(this,SelCaseAty.class);
        Bundle bundle =new Bundle();
        bundle.putParcelable("doctor",bean);
        intent.putExtras(bundle);
        startActivity(intent);
    }

    @Override
    public void OnClickBack() {
        finish();
    }

    @Override
    public void OnClickFinch() {
        finish();
    }


}
