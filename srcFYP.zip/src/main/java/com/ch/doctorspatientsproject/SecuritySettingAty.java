package com.ch.doctorspatientsproject;

import android.os.Bundle;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.ch.doctorspatientsproject.adapters.ConsultationAdapter;
import com.ch.doctorspatientsproject.beans.ChatRoom;
import com.ch.doctorspatientsproject.widget.StatusBarCommonTitleWidget;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.List;


public class SecuritySettingAty extends AppCompatActivity
        implements StatusBarCommonTitleWidget.OnClickBackListener {

    private StatusBarCommonTitleWidget ctv;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.aty_setting_layout);


        ctv = findViewById(R.id.cvTilteCustom);
        ctv.isHiddenCloseBtn();
        ctv.setLeftContent("");
        ctv.setMiddelContent("Security Settings");
        ctv.setOnClickBackListener(this);


    }


    @Override
    public void OnClickBack() {
        finish();
    }

    @Override
    public void OnClickFinch() {
        finish();
    }


}
