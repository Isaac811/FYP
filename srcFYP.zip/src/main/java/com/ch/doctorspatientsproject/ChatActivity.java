package com.ch.doctorspatientsproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;

import com.ch.doctorspatientsproject.adapters.BindAdapter;
import com.ch.doctorspatientsproject.beans.Message;
import com.ch.doctorspatientsproject.databinding.ActivityChatBinding;
import com.ch.doctorspatientsproject.databinding.ItemChatBinding;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import org.checkerframework.checker.units.qual.A;

import java.text.SimpleDateFormat;
import java.util.Date;

public class ChatActivity extends AppCompatActivity {

    private BindAdapter<ItemChatBinding, Message> adapter = new BindAdapter<ItemChatBinding, Message>() {
        @Override
        public ItemChatBinding createHolder(ViewGroup parent) {
            return ItemChatBinding.inflate(getLayoutInflater(), parent, false);
        }

        @Override
        public void bind(ItemChatBinding item, Message message, int position) {
            if (message.getUsername().equals(ParameterInfo.userBean.getUsername())) {
                item.left.setVisibility(View.GONE);
                item.right.setVisibility(View.VISIBLE);
                item.tvMessage.setText(message.getContent());
                if (!ParameterInfo.userBean.getRole().equals("medic")) {
                    item.ivFace1.setImageResource(R.drawable.user_a);
                } else {
                    item.ivFace1.setImageResource(R.drawable.doctor);
                }
            } else {
                item.right.setVisibility(View.GONE);
                item.left.setVisibility(View.VISIBLE);
                item.tvMessage1.setText(message.getContent());
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActivityChatBinding binding = ActivityChatBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        String chatRoomId = getIntent().getStringExtra("chatRoomId");

        binding.rvMessage.setAdapter(adapter);

        FirebaseFirestore
                .getInstance()
                .collection("messages")
                .whereEqualTo("chatRoomId", chatRoomId)
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    adapter.getData().clear();
                    adapter.getData().addAll(queryDocumentSnapshots.toObjects(Message.class));
                    adapter.notifyDataSetChanged();
                });

        binding.tvSend.setOnClickListener(v -> {
            String content = binding.etMessage.getText().toString();
            if (content.isEmpty()) return;
            Message message = new Message();
            message.setUsername(ParameterInfo.userBean.getUsername());
            message.setContent(content);
            message.setDateTime(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
            message.setChatRoomId(chatRoomId);
            FirebaseFirestore.getInstance().collection("messages")
                    .add(message).addOnSuccessListener(documentReference -> {
                        adapter.getData().add(message);
                        adapter.notifyItemInserted(adapter.getData().size() - 1);
                        binding.etMessage.setText("");
                    });
        });
    }
}