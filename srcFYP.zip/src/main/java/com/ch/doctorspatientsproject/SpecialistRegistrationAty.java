package com.ch.doctorspatientsproject;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.ch.doctorspatientsproject.adapters.RvAppointmentDoctorAdapter;
import com.ch.doctorspatientsproject.adapters.SpecialistRegistrationGVAdapter;
import com.ch.doctorspatientsproject.beans.AppointmentBean;
import com.ch.doctorspatientsproject.beans.DoctorBean;
import com.ch.doctorspatientsproject.widget.StatusBarCommonTitleWidget;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.List;
import java.util.UUID;


public class SpecialistRegistrationAty extends AppCompatActivity implements StatusBarCommonTitleWidget.OnClickBackListener {


    private StatusBarCommonTitleWidget ctv;

    private GridView regFunction;
    private SpecialistRegistrationGVAdapter gvAdapter;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.aty_specialist_registration_layout);

        ctv = findViewById(R.id.cvTilteCustom);
        ctv.isHiddenCloseBtn();
        ctv.setLeftContent("");
        ctv.setMiddelContent("PhysicianSpecialist");
        ctv.setOnClickBackListener(this);


        gvAdapter = new SpecialistRegistrationGVAdapter(this);
        regFunction = findViewById(R.id.gv_reg_function);
        regFunction.setAdapter(gvAdapter);

        regFunction.setOnItemClickListener((parent, view, position, id) -> {
            Intent intent = new Intent(SpecialistRegistrationAty.this, SpecialistAppointmentAty.class);
            intent.putExtra("departments",position);
            startActivity(intent);
        });
    }


    @Override
    public void OnClickBack() {
        finish();
    }

    @Override
    public void OnClickFinch() {
        finish();
    }


}
