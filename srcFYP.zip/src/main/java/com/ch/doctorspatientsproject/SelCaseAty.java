package com.ch.doctorspatientsproject;

import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.ch.doctorspatientsproject.beans.AppointmentBean;
import com.ch.doctorspatientsproject.statistics.LineChartManager;
import com.ch.doctorspatientsproject.statistics.RespChartItemModel;
import com.ch.doctorspatientsproject.widget.StatusBarCommonTitleWidget;
import com.github.mikephil.charting.charts.LineChart;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class SelCaseAty extends AppCompatActivity implements StatusBarCommonTitleWidget.OnClickBackListener {

    private StatusBarCommonTitleWidget ctv;

    private FirebaseFirestore db;
    private CollectionReference userCollection;

    private TextView tvDate;
    private TextView tvDoctor;
    private EditText etRemark;
    private TextView tv_prescribe;
    private EditText etCase;

    public LineChartManager weightLineChartManager;
    private LineChart lineChart;
    private LinearLayout emptyview;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.aty_sel_case_layout);

        ctv = findViewById(R.id.cvTilteCustom);
        ctv.isHiddenCloseBtn();
        ctv.setLeftContent("");
        ctv.setMiddelContent("My Appointment");
        ctv.setOnClickBackListener(this);

        AppointmentBean bean = getIntent().getExtras().getParcelable("doctor");

        lineChart = findViewById(R.id.line_chart_right).findViewById(R.id.lineChart);
        emptyview = findViewById(R.id.line_chart_right).findViewById(R.id.emptyview);
        lineChart.setNoDataText("");
        weightLineChartManager = new LineChartManager(lineChart, this);

        List<RespChartItemModel> list = new ArrayList<>();
        String[] strings = bean.getUserTemp().split("-");
        for (String string : strings) {
            RespChartItemModel itemModel = new RespChartItemModel();
            itemModel.setValue(Double.parseDouble(string));
            list.add(itemModel);
        }
        fillChartDataTemper(list);


        db = FirebaseFirestore.getInstance();
        userCollection = db.collection("_user");

        tvDate = findViewById(R.id.tv_date);

        tvDate.setText("Date：" + bean.getAppoint_date() + "-" + bean.getAppoint_time());

        tvDoctor = findViewById(R.id.tv_doctor);
        tvDoctor.setText("Doctor：" + bean.getDoctor_name());

        etRemark = findViewById(R.id.et_remark);
        etRemark.setText("Remark：" + bean.getAppoint_remark());

        etCase = findViewById(R.id.et_case);
        etCase.setText(bean.getInquiry());

        tv_prescribe = findViewById(R.id.tv_prescribe);
        tv_prescribe.setText("prescribe: "+bean.getPrescribe()+" \nprescribeDate: "+bean.getPrescribeDate()+" \nprescribeDosage: "+bean.getPrescribeDosage()+" \nprescribeIns: "+bean.getPrescribeIns());


    }

    public void fillChartDataTemper(List<RespChartItemModel> list) {
        if (list != null && list.size() > 0) {
            emptyview.setVisibility(View.GONE);
            weightLineChartManager.showLineChart(list, "", Color.parseColor("#FF3666FF"), true, 50, "°C");
            Drawable drawable = getResources().getDrawable(R.drawable.onefamily_earning_geren_linechart_shape);
            // weightLineChartManager.setChartFillDrawable(drawable);
        } else {
            emptyview.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void OnClickBack() {
        finish();
    }

    @Override
    public void OnClickFinch() {
        finish();
    }

}
