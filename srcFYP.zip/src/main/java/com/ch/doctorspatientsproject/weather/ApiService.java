package com.ch.doctorspatientsproject.weather;


import com.ch.doctorspatientsproject.weather.currentweather.CurrentWeatherResponse;
import io.reactivex.Single;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface ApiService {

    /**
     * Get current weather of city
     *
     * @param q     String name of city
     * @param units String units of response
     * @param lang  String language of response
     * @param appId String api key
     * @return instance of {@link CurrentWeatherResponse}
     */
    @GET("weather")
    Single<CurrentWeatherResponse> getCurrentWeather(
            @Query("q") String q,
            @Query("units") String units,
            @Query("lang") String lang,
            @Query("appid") String appId
    );


    //https://openweathermap.org/current#one
    // https://api.openweathermap.org/data/2.5/weather?lat=33.44&lon=-94.04&appid={API key}
    @GET("weather")
    Single<CurrentWeatherResponse> getCurrentWeatherByLocation(
            @Query("lat") String lat,
            @Query("lon") String lon,
            @Query("appid") String appId
    );
}
