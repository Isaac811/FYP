package com.ch.doctorspatientsproject.widget;


import android.content.Context;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.ch.doctorspatientsproject.R;


public class StatusBarCommonTitleWidget extends RelativeLayout {

    private Context context;
    private View view;
    private RelativeLayout viewBgLLyt;
    private TextView leftTxt;
    private TextView closeTxt;
    private TextView middelTxt;
    private TextView rightTxt;
    OnClickBackListener onClickBackListener;

    public StatusBarCommonTitleWidget(Context context) {
        this(context, null);
    }

    public StatusBarCommonTitleWidget(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public StatusBarCommonTitleWidget(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        this.context = context;
        view = LayoutInflater.from(context).inflate(R.layout.statusbar_view_common_title_layout, this, true);
        //
        viewBgLLyt = ((RelativeLayout) view.findViewById(R.id.commonTitleRLt));
        leftTxt = (TextView) view.findViewById(R.id.leftTxt);
        leftTxt.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (onClickBackListener != null) {
                    onClickBackListener.OnClickBack();
                }
            }
        });
        closeTxt = (TextView) view.findViewById(R.id.leftCloseTxt);
        closeTxt.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (onClickBackListener != null) {
                    onClickBackListener.OnClickFinch();
                }
            }
        });
        middelTxt = (TextView) view.findViewById(R.id.middleTitleTxt);
        rightTxt = (TextView) view.findViewById(R.id.rightTxt);
    }


    public void setBgWhite() {
        Drawable drawable = getResources().getDrawable(R.drawable.common_title_bg_layer);
        drawable.setBounds(0, 0, drawable.getIntrinsicWidth(), (int) (drawable.getMinimumHeight()));
        viewBgLLyt.setBackground(drawable);
    }

    public TextView getRightObj() {
        return rightTxt;
    }


    public void isHiddenLeftIcon(Drawable left) {
        leftTxt.setCompoundDrawables(left, null, null, null);
    }

    public void isHiddenLeftContent() {
        leftTxt.setText("");
    }


    public void setLeftContentColor(int color) {
        leftTxt.setTextColor(context.getResources().getColor(color));
    }


    public void setLeftContentSize(int textSzie) {
        leftTxt.setTextSize(context.getResources().getDimension(textSzie));
    }

    public void setLeftContent(String leftTxtStr) {
        leftTxt.setText(leftTxtStr);
    }

    public void isHiddenCloseBtn() {
        closeTxt.setVisibility(View.GONE);
    }


    public void setRightContent(String rightTxtStr) {
        rightTxt.setText(rightTxtStr);
    }

    public void isHiddenRightIcon(Drawable drawable) {
        drawable.setBounds(0,0,drawable.getMinimumWidth(),drawable.getMinimumHeight());
        rightTxt.setCompoundDrawables(drawable, null, null, null);
    }

    public void setMiddelContent(String middelTxtStr) {
        middelTxt.setText(middelTxtStr);
    }

    public void setMiddelContetColor(int color) {
        middelTxt.setTextColor(context.getResources().getColor(color));
    }

    public void setMiddelTextSize(int textSzie) {
        middelTxt.setTextSize(context.getResources().getDimension(textSzie));
    }

    public interface OnClickBackListener {
        void OnClickBack();

        void OnClickFinch();
    }

    public void setOnClickBackListener(OnClickBackListener onClickBackListener) {
        this.onClickBackListener = onClickBackListener;
    }
}
