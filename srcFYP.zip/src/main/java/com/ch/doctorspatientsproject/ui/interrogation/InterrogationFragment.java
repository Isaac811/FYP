package com.ch.doctorspatientsproject.ui.interrogation;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.ch.doctorspatientsproject.ParameterInfo;
import com.ch.doctorspatientsproject.R;
import com.ch.doctorspatientsproject.adapters.ConsultAdapter;
import com.ch.doctorspatientsproject.adapters.ConsultationAdapter;
import com.ch.doctorspatientsproject.adapters.DoctorConsultationAdapter;
import com.ch.doctorspatientsproject.adapters.UserAdapter;
import com.ch.doctorspatientsproject.beans.ChatRoom;
import com.ch.doctorspatientsproject.beans.DoctorBean;
import com.ch.doctorspatientsproject.beans.UserBean;
import com.ch.doctorspatientsproject.databinding.FragmentInterrogationBinding;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

public class InterrogationFragment extends Fragment {

    private FragmentInterrogationBinding binding;
    private ArrayList<UserBean> userList = new ArrayList<>();
    UserAdapter userDdapter;

    private ArrayList<ChatRoom> chatRoomsList = new ArrayList<>();
    DoctorConsultationAdapter medicDatper;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentInterrogationBinding.inflate(inflater, container, false);
        View root = binding.getRoot();
        init(root);
        return root;
    }


    private void init(View root) {
        RecyclerView recyclerView = root.findViewById(R.id.recyclerView);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(layoutManager);

        if (ParameterInfo.userBean.getRole().equals("medic")) {
            medicDatper = new DoctorConsultationAdapter(chatRoomsList, getContext());
            recyclerView.setAdapter(medicDatper);
        } else {
            userDdapter = new UserAdapter(userList, getContext());
            recyclerView.setAdapter(userDdapter);
        }

        if (ParameterInfo.userBean.getRole().equals("medic")) {
            // initUserItem("user");
            FirebaseFirestore instance = FirebaseFirestore.getInstance();
            instance.collection("chatRoom")
                    .whereEqualTo("docId", ParameterInfo.userBean.getUsername())
                    .get()
                    .addOnSuccessListener(queryDocumentSnapshots -> {

                        List<ChatRoom> doctorBeans = queryDocumentSnapshots.toObjects(ChatRoom.class);
                        chatRoomsList.clear();
                        chatRoomsList.addAll(doctorBeans);
                        medicDatper.notifyDataSetChanged();

                    });
        } else {
            initUserItem("medic");
        }
    }

    private void initUserItem(String user) {
        FirebaseFirestore instance = FirebaseFirestore.getInstance();
        instance.collection("_user")
                .whereEqualTo("role", user)
                .get().addOnSuccessListener(queryDocumentSnapshots -> {
                    userList.clear();
                    userList.addAll(queryDocumentSnapshots.toObjects(UserBean.class));
                    userDdapter.notifyDataSetChanged();
                });
    }


    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        if (!hidden) {
            init(binding.getRoot());
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}