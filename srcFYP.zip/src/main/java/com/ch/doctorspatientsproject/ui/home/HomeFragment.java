package com.ch.doctorspatientsproject.ui.home;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.RequestOptions;
import com.ch.doctorspatientsproject.ChatActivity;
import com.ch.doctorspatientsproject.MedicAppointmentAty;
import com.ch.doctorspatientsproject.ParameterInfo;
import com.ch.doctorspatientsproject.SpecialistRegistrationAty;
import com.ch.doctorspatientsproject.UserAppointmentAty;
import com.ch.doctorspatientsproject.R;
import com.ch.doctorspatientsproject.UserConsultationAty;
import com.ch.doctorspatientsproject.adapters.HomeFunctionGVAdapter;
import com.ch.doctorspatientsproject.adapters.RvAppointmentDoctorAdapter;
import com.ch.doctorspatientsproject.adapters.RvHomeDoctorAdapter;
import com.ch.doctorspatientsproject.beans.DoctorBean;
import com.ch.doctorspatientsproject.databinding.FragmentHomeBinding;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.youth.banner.adapter.BannerImageAdapter;
import com.youth.banner.holder.BannerImageHolder;
import com.youth.banner.indicator.CircleIndicator;
import com.youth.banner.util.BannerUtils;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment {

    FragmentHomeBinding binding;

    private ArrayList<Integer> integers = new ArrayList<>();
    BannerImageAdapter bannerAdapter;
    private HomeFunctionGVAdapter gvAdapter;

    private FirebaseFirestore db;
    private CollectionReference userCollection;

    private RvHomeDoctorAdapter adapter;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentHomeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        if (binding.searchView != null) {
            try {
                Class<?> argClass = binding.searchView.getClass();
                Field ownField = argClass.getDeclaredField("mSearchPlate");
                ownField.setAccessible(true);
                View mView = (View) ownField.get(binding.searchView);
                mView.setBackgroundColor(Color.TRANSPARENT);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        int imgId = binding.searchView.getContext().getResources().getIdentifier("android:id/search_mag_icon", null, null);
        ImageView searchButton = binding.searchView.findViewById(imgId);
        searchButton.setImageResource(R.drawable.aty_directory_search_icon);
        binding.searchView.setIconifiedByDefault(false);

        int id = binding.searchView.getContext().getResources().getIdentifier("android:id/search_src_text", null, null);
        TextView textView = binding.searchView.findViewById(id);
        textView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        textView.setTextColor(Color.parseColor("#333333"));
        textView.setHintTextColor(Color.parseColor("#66333333"));

        integers.add(R.drawable.banner_one);
        integers.add(R.drawable.banner_two);
        integers.add(R.drawable.banner_three);
        if (bannerAdapter == null) {
            bannerAdapter = new BannerImageAdapter<Integer>(integers) {
                @Override
                public void onBindView(BannerImageHolder holder, Integer data, int position, int size) {
                    holder.imageView.setAdjustViewBounds(true);
                    Glide.with(holder.itemView)
                            .load(data)
                            .thumbnail(Glide.with(holder.itemView).load(R.drawable.error_icon))
                            .apply(RequestOptions.bitmapTransform(new RoundedCorners(30)))
                            .into(holder.imageView);
                }
            };
        } else {
            bannerAdapter.setDatas(integers);
        }


        binding.banner.setAdapter(bannerAdapter, true);
        binding.banner.setIndicator(new CircleIndicator(getContext()));
        binding.banner.setIndicatorSelectedWidth(BannerUtils.dp2px(15));
        binding.banner.setOnBannerListener((data, position) -> {
        });

        gvAdapter = new HomeFunctionGVAdapter(getActivity());
        binding.gvHomeFunction.setAdapter(gvAdapter);
        binding.gvHomeFunction.setOnItemClickListener((parent, view, position, id1) -> {
            Intent intent = null;
            switch (position) {
                case 0:
                    if (ParameterInfo.userBean.getRole().equals("medic")) {
                        intent = new Intent(getActivity(), MedicAppointmentAty.class);
                    } else {
                        intent = new Intent(getActivity(), UserAppointmentAty.class);
                    }
                    break;
                case 1:
                    intent = new Intent(getActivity(), SpecialistRegistrationAty.class);
                    break;
                case 2:
                    intent = new Intent(getActivity(), UserConsultationAty.class);
                    Toast.makeText(getActivity(), "Consultation", Toast.LENGTH_SHORT).show();
                    break;
            }
            startActivity(intent);
        });

        db = FirebaseFirestore.getInstance();
        userCollection = db.collection("_user");

        userCollection
                .whereEqualTo("role", "medic")
                .get().addOnSuccessListener(queryDocumentSnapshots -> {

                    Log.e("fk", "queryDocumentSnapshots " + queryDocumentSnapshots.isEmpty());
                    if (queryDocumentSnapshots.isEmpty()) {
                        return;
                    }
                    List<DoctorBean> doctorBeans = queryDocumentSnapshots.toObjects(DoctorBean.class);

                    if (adapter == null) {
                        adapter = new RvHomeDoctorAdapter(doctorBeans, getActivity());
                        binding.rcv.setLayoutManager(new LinearLayoutManager(getActivity()));
                        binding.rcv.setAdapter(adapter);
                    } else {
                        adapter.notifyDataSetChanged();
                    }
                });
        return root;
    }
}
