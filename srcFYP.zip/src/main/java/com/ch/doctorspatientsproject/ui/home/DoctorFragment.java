package com.ch.doctorspatientsproject.ui.home;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.RequestOptions;
import com.ch.doctorspatientsproject.InquiryConfirmAty;
import com.ch.doctorspatientsproject.MyAppointmentAty;
import com.ch.doctorspatientsproject.ParameterInfo;
import com.ch.doctorspatientsproject.R;
import com.ch.doctorspatientsproject.SelCaseAty;
import com.ch.doctorspatientsproject.adapters.RvMyAppointmentDoctorAdapter;
import com.ch.doctorspatientsproject.adapters.RvMyAppointmentUserAdapter;
import com.ch.doctorspatientsproject.beans.AppointmentBean;
import com.ch.doctorspatientsproject.databinding.FragmentDoctorBinding;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.youth.banner.adapter.BannerImageAdapter;
import com.youth.banner.holder.BannerImageHolder;
import com.youth.banner.indicator.CircleIndicator;
import com.youth.banner.util.BannerUtils;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

public class DoctorFragment extends Fragment implements RvMyAppointmentUserAdapter.InquiryListener {


    FragmentDoctorBinding binding;

    private ArrayList<Integer> integers = new ArrayList<>();
    BannerImageAdapter bannerAdapter;

    private FirebaseFirestore db;
    private CollectionReference userCollection;

    private RvMyAppointmentUserAdapter adapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentDoctorBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        if (binding.searchView != null) {
            try {
                Class<?> argClass = binding.searchView.getClass();
                Field ownField = argClass.getDeclaredField("mSearchPlate");
                ownField.setAccessible(true);
                View mView = (View) ownField.get(binding.searchView);
                mView.setBackgroundColor(Color.TRANSPARENT);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        int imgId = binding.searchView.getContext().getResources().getIdentifier("android:id/search_mag_icon", null, null);
        ImageView searchButton = binding.searchView.findViewById(imgId);
        searchButton.setImageResource(R.drawable.aty_directory_search_icon);
        binding.searchView.setIconifiedByDefault(false);

        int id = binding.searchView.getContext().getResources().getIdentifier("android:id/search_src_text", null, null);
        TextView textView = binding.searchView.findViewById(id);
        textView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        textView.setTextColor(Color.parseColor("#333333"));
        textView.setHintTextColor(Color.parseColor("#66333333"));

        integers.add(R.drawable.banner_one);
        integers.add(R.drawable.banner_two);
        integers.add(R.drawable.banner_three);
        if (bannerAdapter == null) {
            bannerAdapter = new BannerImageAdapter<Integer>(integers) {
                @Override
                public void onBindView(BannerImageHolder holder, Integer data, int position, int size) {
                    holder.imageView.setAdjustViewBounds(true);
                    Glide.with(holder.itemView)
                            .load(data)
                            .thumbnail(Glide.with(holder.itemView).load(R.drawable.error_icon))
                            .apply(RequestOptions.bitmapTransform(new RoundedCorners(30)))
                            .into(holder.imageView);
                }
            };
        } else {
            bannerAdapter.setDatas(integers);
        }


        binding.banner.setAdapter(bannerAdapter, true);
        binding.banner.setIndicator(new CircleIndicator(getContext()));
        binding.banner.setIndicatorSelectedWidth(BannerUtils.dp2px(15));
        binding.banner.setOnBannerListener((data, position) -> {
        });

        db = FirebaseFirestore.getInstance();
        userCollection = db.collection("appointment");

        return root;
    }


    List<AppointmentBean> doctorBeans = new ArrayList<>();
    private void getInquiry() {
        userCollection
                .whereEqualTo("doctor_id", ParameterInfo.userBean.getId())
                .whereEqualTo("is_complete", "false")
                .get().addOnSuccessListener(queryDocumentSnapshots -> {

                    doctorBeans.clear();
                    Log.e("fk", "queryDocumentSnapshots " + queryDocumentSnapshots.isEmpty());
                    if (queryDocumentSnapshots.isEmpty()) {
                        if (adapter != null) {
                            adapter.notifyDataSetChanged();
                        }
                        return;
                    }
                    doctorBeans.addAll(queryDocumentSnapshots.toObjects(AppointmentBean.class));
                    Log.e("fk", "queryDocumentSnapshots " + doctorBeans.size());

                    if (adapter == null) {
                        adapter = new RvMyAppointmentUserAdapter(doctorBeans, getActivity());
                        adapter.setInquiryListener(this);
                        binding.rcv.setLayoutManager(new LinearLayoutManager(getActivity()));
                        binding.rcv.setAdapter(adapter);
                    } else {
                        adapter.notifyDataSetChanged();
                    }
                });
    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        if (!hidden) {
            getInquiry();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        getInquiry();
    }

    @Override
    public void inquiry(AppointmentBean bean) {
        Intent intent = new Intent(getActivity(), InquiryConfirmAty.class);
        Bundle bundle = new Bundle();
        bundle.putParcelable("doctor", bean);
        intent.putExtras(bundle);
        startActivity(intent);
    }
}
