package com.ch.doctorspatientsproject.ui.chart;

import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.RequestOptions;
import com.ch.doctorspatientsproject.R;
import com.ch.doctorspatientsproject.adapters.RvHospitalAdapter;
import com.ch.doctorspatientsproject.beans.HospitalBean;
import com.ch.doctorspatientsproject.databinding.FragmentChartBinding;
import com.ch.doctorspatientsproject.databinding.FragmentNewChartBinding;
import com.ch.doctorspatientsproject.statistics.LineChartManager;
import com.ch.doctorspatientsproject.statistics.RespChartItemModel;
import com.github.mikephil.charting.charts.LineChart;
import com.youth.banner.adapter.BannerImageAdapter;
import com.youth.banner.holder.BannerImageHolder;
import com.youth.banner.indicator.CircleIndicator;
import com.youth.banner.util.BannerUtils;

import java.util.ArrayList;
import java.util.List;

public class ChartNewFragment extends Fragment {

    FragmentNewChartBinding binding;

    public LineChartManager weightLineChartManager;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentNewChartBinding.inflate(inflater, container, false);


        binding.lineChartRight.lineChart.setNoDataText("");
        weightLineChartManager = new LineChartManager( binding.lineChartRight.lineChart, getActivity());

        List<RespChartItemModel> list = new ArrayList<>();
        RespChartItemModel model = new RespChartItemModel();
        model.setTime("2023-02-03");
        model.setValue(38.3);
        RespChartItemModel model2 = new RespChartItemModel();
        model2.setTime("2023-02-04");
        model2.setValue(36);
        RespChartItemModel model3 = new RespChartItemModel();
        model3.setTime("2023-02-05");
        model3.setValue(37.4);
        RespChartItemModel model4 = new RespChartItemModel();
        model4.setTime("2023-02-05");
        model4.setValue(40.5);
        RespChartItemModel model5 = new RespChartItemModel();
        model5.setTime("2023-02-05");
        model5.setValue(35.5);
        RespChartItemModel model6 = new RespChartItemModel();
        model6.setTime("2023-02-05");
        model6.setValue(36.5);
        RespChartItemModel model7 = new RespChartItemModel();
        model7.setTime("2023-02-05");
        model7.setValue(39.5);
        list.add(model);
        list.add(model2);
        list.add(model3);
        list.add(model4);
        list.add(model5);
        list.add(model6);
        list.add(model7);

        fillChartDataTemper(list);
        return binding.getRoot();
    }

    public void fillChartDataTemper(List<RespChartItemModel> list) {
        if (list != null && list.size() > 0) {
            binding.lineChartRight.emptyview.setVisibility(View.GONE);
            weightLineChartManager.showLineChart(list, "", Color.parseColor("#FF3666FF"), true, 50, "°C");
            Drawable drawable = getResources().getDrawable(R.drawable.onefamily_earning_geren_linechart_shape);
           // weightLineChartManager.setChartFillDrawable(drawable);
        } else {
            binding.lineChartRight.emptyview.setVisibility(View.VISIBLE);
        }
    }
}
