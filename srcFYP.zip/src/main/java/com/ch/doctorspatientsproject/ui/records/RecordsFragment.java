package com.ch.doctorspatientsproject.ui.records;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.ch.doctorspatientsproject.ParameterInfo;
import com.ch.doctorspatientsproject.R;
import com.ch.doctorspatientsproject.adapters.ConsultAdapter;
import com.ch.doctorspatientsproject.beans.ConsultBean;
import com.ch.doctorspatientsproject.databinding.FragmentRecordsBinding;

import java.util.ArrayList;

public class RecordsFragment extends Fragment {

    private FragmentRecordsBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentRecordsBinding.inflate(inflater, container, false);
        View root = binding.getRoot();
        init(root);
        return root;
    }

    /**
     * Initialization operation
     *
     * @param root
     */
    private ArrayList<ConsultBean> consultList = new ArrayList<>();
    ConsultAdapter consultAdapter;

    private void init(View root) {
        RecyclerView recyclerView = root.findViewById(R.id.recyclerView);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(layoutManager);
        if (ParameterInfo.identity.equals("user")) {
            consultAdapter = new ConsultAdapter(consultList, getContext());
            recyclerView.setAdapter(consultAdapter);
            initConsultItem();
        }
    }

    private void initConsultItem() {
        for (int i = 0; i < 20; i++) {
            ConsultBean doctorBean = new ConsultBean("medic " + i);
            consultList.add(doctorBean);
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}