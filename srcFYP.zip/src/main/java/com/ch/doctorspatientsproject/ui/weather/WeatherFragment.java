package com.ch.doctorspatientsproject.ui.weather;

import static android.Manifest.permission.ACCESS_FINE_LOCATION;

import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.ch.doctorspatientsproject.R;
import com.ch.doctorspatientsproject.databinding.FragmentWeatherBinding;
import com.ch.doctorspatientsproject.utils.AppUtil;
import com.ch.doctorspatientsproject.weather.ApiClient;
import com.ch.doctorspatientsproject.weather.ApiService;
import com.ch.doctorspatientsproject.weather.CityInfo;
import com.ch.doctorspatientsproject.weather.CurrentWeather;
import com.ch.doctorspatientsproject.weather.currentweather.CurrentWeatherResponse;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.Task;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.net.PlacesClient;

import java.util.List;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.observers.DisposableSingleObserver;
import io.reactivex.schedulers.Schedulers;

public class WeatherFragment extends Fragment implements OnMapReadyCallback, GoogleMap.OnMapClickListener {

    FragmentWeatherBinding binding;

    private static final String TAG = WeatherFragment.class.getSimpleName();

    private CompositeDisposable disposable = new CompositeDisposable();
    private ApiService apiService;

    private GoogleMap map;
    private PlacesClient placesClient;
    private FusedLocationProviderClient fusedLocationProviderClient;

    private static final int DEFAULT_ZOOM = 15;

    private static final int PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION = 1;
    private boolean locationPermissionGranted;

    private Location lastKnownLocation;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentWeatherBinding.inflate(getLayoutInflater(), container, false);

        apiService = ApiClient.getClient().create(ApiService.class);

        Places.initialize(getActivity(), "AIzaSyDmI8f4AGk5ZuqwsvgM7nnXOiZHUBEgcp0");
        placesClient = Places.createClient(getActivity());

        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(getActivity());
        SupportMapFragment mapFragment = SupportMapFragment.newInstance();
        getParentFragmentManager()
                .beginTransaction()
                .add(R.id.my_container, mapFragment)
                .commit();
        mapFragment.getMapAsync(this);
        return binding.getRoot();
    }

    @Override
    public void onMapClick(@NonNull LatLng latLng) {
        Toast.makeText(WeatherFragment.this.getContext(), " latLng=" + latLng.longitude, Toast.LENGTH_SHORT).show();
        requestWeather(String.valueOf(latLng.latitude), String.valueOf(latLng.longitude), true);
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        this.map = googleMap;
        this.map.setOnMapClickListener(this);
        getLocationPermission();

        updateLocationUI();
        getDeviceLocation();
    }

    private void getLocationPermission() {
        if (ContextCompat.checkSelfPermission(getActivity().getApplicationContext(),
                ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            locationPermissionGranted = true;
        } else {
            ActivityCompat.requestPermissions(getActivity(),
                    new String[]{ACCESS_FINE_LOCATION},
                    PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        locationPermissionGranted = false;
        if (requestCode
                == PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION) {
            if (grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                locationPermissionGranted = true;
            }
        } else {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
        updateLocationUI();
    }

    private void updateLocationUI() {
        if (map == null) {
            return;
        }
        try {
            if (locationPermissionGranted) {
                map.setMyLocationEnabled(true);
                map.getUiSettings().setMyLocationButtonEnabled(true);
            } else {
                map.setMyLocationEnabled(false);
                map.getUiSettings().setMyLocationButtonEnabled(false);
                lastKnownLocation = null;
                getLocationPermission();
            }
        } catch (SecurityException e) {
            Log.e("Exception: %s", e.getMessage());
        }
    }

    private void getDeviceLocation() {
        try {
            if (locationPermissionGranted) {
                Task<Location> locationResult = fusedLocationProviderClient.getLastLocation();
                locationResult.addOnCompleteListener(getActivity(), task -> {
                    if (task.isSuccessful()) {
                        lastKnownLocation = task.getResult();
                        if (lastKnownLocation != null) {
                            map.moveCamera(CameraUpdateFactory.newLatLngZoom(
                                    new LatLng(lastKnownLocation.getLatitude(),
                                            lastKnownLocation.getLongitude()), DEFAULT_ZOOM));

                            Log.e("fk", "lat =" + lastKnownLocation.getLatitude() + " long =" + lastKnownLocation.getLongitude());
                            requestWeather(String.valueOf(lastKnownLocation.getLatitude())
                                    , String.valueOf(lastKnownLocation.getLongitude()), false);
                        }
                    } else {
                        Log.d(TAG, "Current location is null. Using defaults.");
                        Log.e(TAG, "Exception: %s", task.getException());

                        map.getUiSettings().setMyLocationButtonEnabled(false);
                    }
                });
            }
        } catch (SecurityException e) {
            Log.e("Exception: %s", e.getMessage(), e);
        }
    }

    private void requestWeather(String lat, String lon, boolean isClickMap) {
        if (AppUtil.isNetworkConnected()) {
            getCurrentWeather(lat, lon, isClickMap);
        } else {
        }
    }

    private void getCurrentWeather(String lat, String lon, boolean isClickMap) {
        disposable.add(
                apiService.getCurrentWeatherByLocation(lat, lon, "71ae7c6ed6ba8068cbb93853da78617e")
                        .subscribeOn(Schedulers.io())
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribeWith(new DisposableSingleObserver<CurrentWeatherResponse>() {
                            @Override
                            public void onSuccess(CurrentWeatherResponse currentWeatherResponse) {
                                Log.e("fk", "humidity =" + currentWeatherResponse.getMain().getHumidity());

                                CurrentWeather currentWeather = storeCurrentWeather(currentWeatherResponse);
                                CityInfo cityInfo = storeCityInfo(currentWeatherResponse);

                                // https://www.bscooling.com.cn/html/28.html
                                int celsius = (int) (currentWeatherResponse.getMain().getTemp() - 273.15);

                                if (isClickMap) {
                                    Toast.makeText(getActivity(), cityInfo.getName() + " " + celsius + "°C", Toast.LENGTH_SHORT).show();
                                } else {
                                    Log.e("fk", "currentWeather.getTemp() " + currentWeather.getTemp());
                                    map.addMarker(new MarkerOptions()
                                                    .position(new LatLng(Double.valueOf(lat), Double.valueOf(lon)))
                                                    .title(cityInfo.getName() + " " + celsius + "°C"
                                                    ))
                                            .showInfoWindow();
                                }
                            }

                            @Override
                            public void onError(Throwable e) {
                                Log.e("fk", "onError =" + e.getMessage());
                            }
                        })
        );
    }

    private CurrentWeather storeCurrentWeather(CurrentWeatherResponse response) {
        CurrentWeather currentWeather = new CurrentWeather();
        currentWeather.setTemp(response.getMain().getTemp());
        currentWeather.setHumidity(response.getMain().getHumidity());
        currentWeather.setDescription(response.getWeather().get(0).getDescription());
        currentWeather.setMain(response.getWeather().get(0).getMain());
        currentWeather.setWeatherId(response.getWeather().get(0).getId());
        currentWeather.setWindDeg(response.getWind().getDeg());
        currentWeather.setWindSpeed(response.getWind().getSpeed());
        currentWeather.setStoreTimestamp(System.currentTimeMillis());

        return currentWeather;
    }

    private CityInfo storeCityInfo(CurrentWeatherResponse response) {
        CityInfo cityInfo = new CityInfo();
        cityInfo.setCountry(response.getSys().getCountry());
        cityInfo.setId(response.getId());
        cityInfo.setName(response.getName());
        return cityInfo;
    }

}
