package com.ch.doctorspatientsproject.ui.mine;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.ch.doctorspatientsproject.DoctorAppointmentAty;
import com.ch.doctorspatientsproject.DoctorCommentAty;
import com.ch.doctorspatientsproject.MyAppointmentAty;
import com.ch.doctorspatientsproject.ParameterInfo;
import com.ch.doctorspatientsproject.beans.AppointmentBean;
import com.ch.doctorspatientsproject.databinding.FragmentDoctorBinding;
import com.ch.doctorspatientsproject.databinding.FragmentDoctorMineBinding;
import com.ch.doctorspatientsproject.databinding.FragmentMineBinding;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.List;

public class DoctorMineFragment extends Fragment {

    private FirebaseFirestore db;
    private CollectionReference userCollection;

    private FragmentDoctorMineBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentDoctorMineBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        db = FirebaseFirestore.getInstance();
        userCollection = db.collection("appointment");

        binding.txtUsername.setText(ParameterInfo.userBean.getUsername());
        binding.txtRoleType.setText(ParameterInfo.userBean.getRole());
        getAppointmentCount();

        binding.yuYueRLLyt.setOnClickListener(v -> {
            Intent intent = new Intent(getActivity(), DoctorAppointmentAty.class);
            startActivity(intent);
        });

        binding.outlogin.setOnClickListener(v -> getActivity().finish());

        binding.commentRLLyt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), DoctorCommentAty.class);
                startActivity(intent);
            }
        });
        return root;
    }


    private void getAppointmentCount() {
        Log.e("fk", "getId= " + ParameterInfo.userBean.getId());
        userCollection
                .whereEqualTo("doctor_id", ParameterInfo.userBean.getId())
                .get().addOnSuccessListener(queryDocumentSnapshots -> {
                    Log.e("fk", "queryDocumentSnapshots " + queryDocumentSnapshots.isEmpty());
                    if (queryDocumentSnapshots.isEmpty()) {
                        return;
                    }
                    List<AppointmentBean> doctorBeans = queryDocumentSnapshots.toObjects(AppointmentBean.class);

                    Log.e("fk", "doctorBeans " + doctorBeans.size());
                    // appointment count
                    binding.parentUserNameTxt.setText(String.valueOf(doctorBeans.size()));
                });


    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        if (!hidden) {
            getAppointmentCount();
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}