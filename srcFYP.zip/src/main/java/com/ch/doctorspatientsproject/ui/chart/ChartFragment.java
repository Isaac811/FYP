package com.ch.doctorspatientsproject.ui.chart;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.RequestOptions;
import com.ch.doctorspatientsproject.R;
import com.ch.doctorspatientsproject.adapters.RvHomeDoctorAdapter;
import com.ch.doctorspatientsproject.adapters.RvHospitalAdapter;
import com.ch.doctorspatientsproject.beans.HospitalBean;
import com.ch.doctorspatientsproject.databinding.FragmentChartBinding;
import com.google.firebase.firestore.FirebaseFirestore;
import com.youth.banner.adapter.BannerImageAdapter;
import com.youth.banner.holder.BannerImageHolder;
import com.youth.banner.indicator.CircleIndicator;
import com.youth.banner.util.BannerUtils;

import java.util.ArrayList;

public class ChartFragment extends Fragment {

    FragmentChartBinding binding;

    private ArrayList<Integer> integers = new ArrayList<>();
    BannerImageAdapter bannerAdapter;

    private ArrayList<HospitalBean> hospitalBeans = new ArrayList<>();
    private RvHospitalAdapter adapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentChartBinding.inflate(inflater, container, false);

        integers.add(R.drawable.banner_one);
        integers.add(R.drawable.banner_two);
        integers.add(R.drawable.banner_three);
        if (bannerAdapter == null) {
            bannerAdapter = new BannerImageAdapter<Integer>(integers) {
                @Override
                public void onBindView(BannerImageHolder holder, Integer data, int position, int size) {
                    holder.imageView.setAdjustViewBounds(true);
                    Glide.with(holder.itemView)
                            .load(data)
                            .thumbnail(Glide.with(holder.itemView).load(R.drawable.error_icon))
                            .apply(RequestOptions.bitmapTransform(new RoundedCorners(30)))
                            .into(holder.imageView);
                }
            };
        } else {
            bannerAdapter.setDatas(integers);
        }


        binding.banner.setAdapter(bannerAdapter, true);
        binding.banner.setIndicator(new CircleIndicator(getContext()));
        binding.banner.setIndicatorSelectedWidth(BannerUtils.dp2px(15));
        binding.banner.setOnBannerListener((data, position) -> {
        });

        for (int i = 0; i < 10; i++) {
            HospitalBean bean = new HospitalBean();
            bean.setHospitalInfo("Cavity, one of the medical disciplines. The main oral diseases include: oral and maxillofacial dermoid, epidermal submaxillary space infection, maxillofacial lymphangioma, odontoid development malformation, maxillary sinus malignancy, jaw ameloblastoma, chronic ethmoiditis, mandibular retraction, tetracycline teeth, tongue leukoplakia and other diseases. With technology, many periodontal diseases can be completely cured. The development of tissue bioengineering technology. " + i);
            bean.setHospitalName("HospitalBean" + i);
            bean.setHospitalPic("hos");
            hospitalBeans.add(bean);
        }

        if (adapter == null) {
            adapter = new RvHospitalAdapter(hospitalBeans, getActivity());
            binding.rcv.setLayoutManager(new LinearLayoutManager(getActivity()));
            binding.rcv.setAdapter(adapter);
        } else {
            adapter.notifyDataSetChanged();
        }
        return binding.getRoot();
    }
}
