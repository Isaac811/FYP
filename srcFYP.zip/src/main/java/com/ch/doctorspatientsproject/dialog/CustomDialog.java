package com.ch.doctorspatientsproject.dialog;

import android.app.AlertDialog;
import android.content.Context;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.ch.doctorspatientsproject.R;
import com.ch.doctorspatientsproject.beans.AppointmentBean;

import java.util.List;

public class CustomDialog extends AlertDialog {


    private Context context;

    public CustomDialog(@NonNull Context context) {
        this(context, R.style.CustomDialog);
        this.context = context;
    }

    protected CustomDialog(@NonNull Context context, int themeResId) {
        super(context, themeResId);
    }


    List<AppointmentBean> doctorBeans;

    public void setContext(List<AppointmentBean> doctorBeans) {
        this.doctorBeans = doctorBeans;
    }


    public TextView tv;
    public Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_layout);
        this.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        getWindow().setGravity(Gravity.CENTER);
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM);

        tv = findViewById(R.id.tv_info_value);
        TextView tvNumber = findViewById(R.id.tv_info);
        tvNumber.setText("Reservation number：" + (doctorBeans.size() + 1));

        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < doctorBeans.size(); i++) {
            builder.append((i + 1) + "." + doctorBeans.get(i).getUser_name() + "\n");
        }
        tv.setText(builder.toString());

        btn = findViewById(R.id.btn);
        btn.setOnClickListener(v -> {
            if (dialogListener != null) {
                dismiss();
                dialogListener.Ok();
            }
        });
    }

    private CustomDialogListener dialogListener;

    public void setDialogListener(CustomDialogListener dialogListener) {
        this.dialogListener = dialogListener;
    }

    public interface CustomDialogListener {
        void Ok();
    }
}
