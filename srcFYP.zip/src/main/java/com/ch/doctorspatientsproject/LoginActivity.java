package com.ch.doctorspatientsproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.ch.doctorspatientsproject.beans.UserBean;
import com.ch.doctorspatientsproject.systembar.ImmersiveBarUtil;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;

public class LoginActivity extends AppCompatActivity {


    RadioGroup radioGroup;
    // Default selected user
    String radioNameStr = "user";
    TextView bt_register;
    Button bt_login;
    EditText userName;
    EditText userPwd;

    private FirebaseFirestore db;
    private CollectionReference userCollection;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ImmersiveBarUtil.immersiveBar(this);
        setContentView(R.layout.aty_login);


        db = FirebaseFirestore.getInstance();
        userCollection = db.collection("_user");

        radioGroup = findViewById(R.id.radioGroup);
        bt_register = findViewById(R.id.txt_login_register);
        bt_login = findViewById(R.id.btn_login);
        userName = findViewById(R.id.et_login_username);
        userPwd = findViewById(R.id.et_login_pwd);

        radioGroup.setOnCheckedChangeListener((radioGroup, i) -> {
            RadioButton radioButton = findViewById(i);
            radioNameStr = radioButton.getText().toString();
        });

        bt_register.setOnClickListener(view -> {
            Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
            startActivity(intent);
        });

        bt_login.setOnClickListener(view -> {
            if (!TextUtils.isEmpty(userName.getText())
                    &&
                    !TextUtils.isEmpty(userPwd.getText())) {
                userCollection.
                        whereEqualTo("username", userName.getText().toString())
                        .whereEqualTo("password", userPwd.getText().toString())
                        .whereEqualTo("role", radioNameStr)
                        .get().addOnSuccessListener(queryDocumentSnapshots -> {
                            if (queryDocumentSnapshots.isEmpty()) {
                                Toast.makeText(LoginActivity.this, "The user name or password is incorrect！", Toast.LENGTH_SHORT).show();
                                return;
                            }
                            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                            ParameterInfo.userBean = queryDocumentSnapshots.toObjects(UserBean.class).get(0);
                            startActivity(intent);
                        });
            } else {
                Toast.makeText(LoginActivity.this,
                        "Please enter your username and password!", Toast.LENGTH_SHORT).show();
            }
        });
    }
}