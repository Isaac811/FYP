package com.ch.doctorspatientsproject;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.ch.doctorspatientsproject.beans.AppointmentBean;
import com.ch.doctorspatientsproject.statistics.LineChartManager;
import com.ch.doctorspatientsproject.statistics.RespChartItemModel;
import com.ch.doctorspatientsproject.widget.StatusBarCommonTitleWidget;
import com.github.mikephil.charting.charts.LineChart;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

public class InquiryConfirmAty extends AppCompatActivity implements StatusBarCommonTitleWidget.OnClickBackListener {

    private StatusBarCommonTitleWidget ctv;

    private FirebaseFirestore db;

    private TextView tvDate;
    private TextView tvDoctor;
    private EditText etRemark;
    private EditText etCase;
    private Button btnAppointment;

    public LineChartManager weightLineChartManager;
    private LineChart lineChart;
    private LinearLayout emptyview;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.aty_inquiry_confirm_layout);

        ctv = findViewById(R.id.cvTilteCustom);
        ctv.isHiddenCloseBtn();
        ctv.setLeftContent("");
        ctv.setMiddelContent("Inquiry");
        ctv.setOnClickBackListener(this);

        AppointmentBean bean = getIntent().getExtras().getParcelable("doctor");

        db = FirebaseFirestore.getInstance();

        lineChart = findViewById(R.id.line_chart_right).findViewById(R.id.lineChart);
        emptyview = findViewById(R.id.line_chart_right).findViewById(R.id.emptyview);
        lineChart.setNoDataText("");
        weightLineChartManager = new LineChartManager(lineChart, this);

        List<RespChartItemModel> list = new ArrayList<>();
        String[] strings = bean.getUserTemp().split("-");
        for (String string : strings) {
            RespChartItemModel itemModel = new RespChartItemModel();
            itemModel.setValue(Double.parseDouble(string));
            list.add(itemModel);
        }
        fillChartDataTemper(list);


        tvDate = findViewById(R.id.tv_date);
        tvDate.setText("Date：" + bean.getAppoint_date() + "-" + bean.getAppoint_time());

        tvDoctor = findViewById(R.id.tv_doctor);
        tvDoctor.setText("Patient：" + bean.getUser_name());
        etRemark = findViewById(R.id.et_remark);
        etRemark.setText("Remark：" + bean.getAppoint_remark());

        etCase = findViewById(R.id.et_case);
        etCase.setText(bean.getInquiry());


        btnAppointment = findViewById(R.id.btn_appointment);
        btnAppointment.setOnClickListener(v -> {

            db.collection("appointment")
                    .whereEqualTo("user_id", bean.getUser_id())
                    .whereEqualTo("doctor_id", bean.getDoctor_id())
                    .get()
                    .addOnSuccessListener(documentReference -> {
                        Log.e("fk", "size=" + documentReference.getDocuments().size());
                        documentReference
                                .getDocuments()
                                .forEach(documentSnapshot -> {
                                    if (!TextUtils.isEmpty(etCase.getText())) {
                                        Map<String, Object> user = new HashMap<>();
                                        user.put("inquiry", etCase.getText().toString());
                                        documentSnapshot
                                                .getReference()
                                                .update(user)
                                                .addOnSuccessListener(unused -> {
                                                    Intent intent = new Intent(InquiryConfirmAty.this, InquiryPrescribeAty.class);
                                                    Bundle bundle = new Bundle();
                                                    bundle.putString("user_id", bean.getUser_id());
                                                    bundle.putString("doctor_id", bean.getDoctor_id());
                                                    intent.putExtras(bundle);
                                                    startActivity(intent);
                                                    finish();
                                                }).addOnFailureListener(e -> {
                                                    Toast.makeText(InquiryConfirmAty.this, "Inquiry onFailure", Toast.LENGTH_SHORT).show();
                                                    finish();
                                                });
                                    }
                                });

                    }).addOnFailureListener(e -> Log.d("TAG", "onFailure: " + e.getLocalizedMessage()));
        });
    }

    public void fillChartDataTemper(List<RespChartItemModel> list) {
        if (list != null && list.size() > 0) {
            emptyview.setVisibility(View.GONE);
            weightLineChartManager.showLineChart(list, "", Color.parseColor("#FF3666FF"), true, 50, "°C");
            Drawable drawable = getResources().getDrawable(R.drawable.onefamily_earning_geren_linechart_shape);
            // weightLineChartManager.setChartFillDrawable(drawable);
        } else {
            emptyview.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void OnClickBack() {
        finish();
    }

    @Override
    public void OnClickFinch() {
        finish();
    }
}
