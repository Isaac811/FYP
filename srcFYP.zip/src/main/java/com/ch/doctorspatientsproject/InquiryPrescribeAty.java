package com.ch.doctorspatientsproject;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.ch.doctorspatientsproject.widget.StatusBarCommonTitleWidget;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class InquiryPrescribeAty extends AppCompatActivity implements StatusBarCommonTitleWidget.OnClickBackListener {

    private StatusBarCommonTitleWidget ctv;

    private FirebaseFirestore db;

    private Spinner spPrescribe;
    private String prescribe = "Epinephrine";
    private Button btnAppointment;

    private EditText etDate;
    private EditText etDosage;
    private EditText etInstructions;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.aty_inquiry_prescsribe);

        ctv = findViewById(R.id.cvTilteCustom);
        ctv.isHiddenCloseBtn();
        ctv.setLeftContent("");
        ctv.setMiddelContent("Inquiry");
        ctv.setOnClickBackListener(this);

        db = FirebaseFirestore.getInstance();

        spPrescribe = findViewById(R.id.sp_prescribe);
        spPrescribe.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                prescribe = getResources().getStringArray(R.array.restoratives)[position];
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        etDate = findViewById(R.id.tv_date);
        etDosage = findViewById(R.id.tv_doctor);
        etInstructions = findViewById(R.id.et_remark);

        btnAppointment = findViewById(R.id.btn_appointment);
        btnAppointment = findViewById(R.id.btn_appointment);
        btnAppointment = findViewById(R.id.btn_appointment);
        btnAppointment.setOnClickListener(v -> {

            if (!TextUtils.isEmpty(etDate.getText())
                    && !TextUtils.isEmpty(etDosage.getText())
                    && !TextUtils.isEmpty(etInstructions.getText())) {

                db.collection("appointment")
                        .whereEqualTo("user_id", getIntent().getExtras().getString("user_id"))
                        .whereEqualTo("doctor_id", getIntent().getExtras().getString("doctor_id"))
                        .get()
                        .addOnSuccessListener(documentReference -> {
                            Log.e("fk", "size=" + documentReference.getDocuments().size());
                            documentReference
                                    .getDocuments()
                                    .forEach(documentSnapshot -> {
                                        if (!TextUtils.isEmpty(prescribe)) {
                                            Map<String, Object> user = new HashMap<>();
                                            user.put("prescribeDate", etDate.getText().toString());
                                            user.put("prescribeDosage", etDosage.getText().toString());
                                            user.put("prescribeIns", etInstructions.getText().toString());
                                            user.put("prescribe", prescribe);
                                            user.put("is_complete", "true");
                                            documentSnapshot
                                                    .getReference()
                                                    .update(user)
                                                    .addOnSuccessListener(unused -> {
                                                        Toast.makeText(InquiryPrescribeAty.this, "Inquiry Success", Toast.LENGTH_SHORT).show();
                                                        finish();
                                                    }).addOnFailureListener(e -> {
                                                        Toast.makeText(InquiryPrescribeAty.this, "Inquiry onFailure", Toast.LENGTH_SHORT).show();
                                                        finish();
                                                    });
                                        }
                                    });

                        }).addOnFailureListener(e -> Log.d("TAG", "onFailure: " + e.getLocalizedMessage()));
            } else {
                Toast.makeText(InquiryPrescribeAty.this, "Incomplete data entry", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void OnClickBack() {
        finish();
    }

    @Override
    public void OnClickFinch() {
        finish();
    }
}
