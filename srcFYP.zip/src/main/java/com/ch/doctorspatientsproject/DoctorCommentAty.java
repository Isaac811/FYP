package com.ch.doctorspatientsproject;

import android.os.Bundle;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.ch.doctorspatientsproject.adapters.RvCommentAdapter;
import com.ch.doctorspatientsproject.beans.RespCommentBean;
import com.ch.doctorspatientsproject.widget.StatusBarCommonTitleWidget;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.List;


public class DoctorCommentAty extends AppCompatActivity implements StatusBarCommonTitleWidget.OnClickBackListener {

    private FirebaseFirestore db;
    private CollectionReference userCollection;

    private StatusBarCommonTitleWidget ctv;

    private TextView tv_move_name;
    private TextView tv_director;
    private TextView tv_writer;

    private RecyclerView rvComment;
    private RvCommentAdapter commentAdapter;
    private List<RespCommentBean> respComments = new ArrayList<>();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.aty_doctor_comment_layout);

        db = FirebaseFirestore.getInstance();
        userCollection = db.collection("comment");

        ctv = findViewById(R.id.cvTilteCustom);
        ctv.isHiddenCloseBtn();
        ctv.setLeftContent("");
        ctv.setMiddelContent("My Comment");
        ctv.setOnClickBackListener(this);


        tv_move_name = findViewById(R.id.tv_move_name);
        tv_director = findViewById(R.id.tv_director);
        tv_writer = findViewById(R.id.tv_writer);
        rvComment = findViewById(R.id.rv_comment);

        tv_move_name.setText(ParameterInfo.userBean.getUsername());
        tv_director.setText(ParameterInfo.userBean.getDepartments());
        tv_writer.setText(ParameterInfo.userBean.getMedicInfo());

        selectComment();
    }

    private void selectComment() {
        userCollection.
                whereEqualTo("comment_doctor_id", ParameterInfo.userBean.getId())
                .get().addOnSuccessListener(queryDocumentSnapshots -> {

                    if (queryDocumentSnapshots.isEmpty()) {
                        return;
                    }
                    List<RespCommentBean> s = queryDocumentSnapshots.toObjects(RespCommentBean.class);

                    respComments.clear();
                    respComments.addAll(s);
                    if (commentAdapter == null) {
                        commentAdapter = new RvCommentAdapter(respComments);
                    }
                    rvComment.setLayoutManager(new LinearLayoutManager(DoctorCommentAty.this));
                    rvComment.setAdapter(commentAdapter);
                });
    }


    @Override
    public void OnClickBack() {
        finish();
    }

    @Override
    public void OnClickFinch() {
        finish();
    }


}
