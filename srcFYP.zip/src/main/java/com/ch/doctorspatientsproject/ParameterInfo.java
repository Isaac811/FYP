package com.ch.doctorspatientsproject;

import com.ch.doctorspatientsproject.beans.UserBean;

public class ParameterInfo {

    public static String identity = "user";
    public static UserBean userBean;
}
