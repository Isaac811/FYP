package com.ch.doctorspatientsproject;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.RadioButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.ch.doctorspatientsproject.beans.UserBean;
import com.ch.doctorspatientsproject.databinding.ActivityRegisterBinding;
import com.ch.doctorspatientsproject.databinding.ActivityUpdateBinding;
import com.ch.doctorspatientsproject.systembar.ImmersiveBarUtil;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class UpdatePersonalActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ImmersiveBarUtil.immersiveBar(this);
        ActivityUpdateBinding binding = ActivityUpdateBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.btRegister.setOnClickListener(v -> {
            String username = binding.editTextText.getText().toString();
            String password = binding.editTextTextPassword.getText().toString();
            String password2 = binding.editTextTextPassword2.getText().toString();
            if (username.isEmpty()) {
                Toast.makeText(UpdatePersonalActivity.this, "Please enter a user name！", Toast.LENGTH_SHORT).show();
                return;
            }
            if (password.isEmpty()) {
                Toast.makeText(UpdatePersonalActivity.this, "Please enter password！", Toast.LENGTH_SHORT).show();
                return;
            }
            if (!password.equals(password2)) {
                Toast.makeText(UpdatePersonalActivity.this, "The two passwords are inconsistent！", Toast.LENGTH_SHORT).show();
                return;
            }

            FirebaseFirestore instance = FirebaseFirestore.getInstance();
            instance
                    .collection("_user")
                    .whereEqualTo("id", ParameterInfo.userBean.getId())
                    .get()
                    .addOnSuccessListener(queryDocumentSnapshots -> {

                        Log.e("fk", "size=" + queryDocumentSnapshots.getDocuments().size());

                        queryDocumentSnapshots
                                .getDocuments()
                                .forEach(documentSnapshot -> {

                                    if (!TextUtils.isEmpty(binding.editTextText.getText())) {
                                        Map<String, Object> user = new HashMap<>();
                                        user.put("username", binding.editTextText.getText().toString());
                                        user.put("password", binding.editTextTextPassword2.getText().toString());

                                        documentSnapshot
                                                .getReference()
                                                .update(user)
                                                .addOnSuccessListener(unused -> {
                                                    Toast.makeText(UpdatePersonalActivity.this, "Update Info Success", Toast.LENGTH_SHORT).show();
                                                    finish();
                                                }).addOnFailureListener(e -> {
                                                    Toast.makeText(UpdatePersonalActivity.this, "Update Info  onFailure", Toast.LENGTH_SHORT).show();
                                                    finish();
                                                });
                                    }
                                });
                    }).addOnFailureListener(e -> Log.d("TAG", "onFailure: " + e.getLocalizedMessage()));
        });
    }
}