package com.ch.doctorspatientsproject.utils;


import com.ch.doctorspatientsproject.BuildConfig;

public class IntentActionUtil {

    /**
     * Actions
     */
    public static final String ACTION_CHANGE_MODULE = BuildConfig.APPLICATION_ID + ".ACTION_CHANGE_MODULE";
}
