package com.ch.doctorspatientsproject.systembar;

import android.app.Activity;

public class ImmersiveBarUtil {

    public static void immersiveBar(Activity activity) {
        JaegerStatusBarUtil.setTranslucent(activity, 0);
        JaegerStatusBarUtil.setLightMode(activity);
    }


    public static void immersiveImageBar(Activity activity) {
        JaegerStatusBarUtil.setTranslucentForImageView(activity, 0, null);
        JaegerStatusBarUtil.setLightMode(activity);
    }
}
