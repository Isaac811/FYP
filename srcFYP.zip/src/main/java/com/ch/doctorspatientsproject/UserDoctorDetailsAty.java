package com.ch.doctorspatientsproject;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.ch.doctorspatientsproject.adapters.RvCommentAdapter;
import com.ch.doctorspatientsproject.beans.DoctorBean;
import com.ch.doctorspatientsproject.beans.RespCommentBean;
import com.ch.doctorspatientsproject.widget.StatusBarCommonTitleWidget;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.UUID;


public class UserDoctorDetailsAty extends AppCompatActivity implements StatusBarCommonTitleWidget.OnClickBackListener {

    private StatusBarCommonTitleWidget ctv;
    private FirebaseFirestore db;
    private CollectionReference userCollection;

    DoctorBean bean;

    private TextView tv_move_name;
    private TextView tv_director;
    private TextView tv_writer;

    private RecyclerView rvComment;
    private RvCommentAdapter commentAdapter;
    private List<RespCommentBean> respComments = new ArrayList<>();


    private EditText etComment;
    private Button btn_comment;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.aty_user_doctor_details_layout);

        ctv = findViewById(R.id.cvTilteCustom);
        ctv.isHiddenCloseBtn();
        ctv.setLeftContent("");
        ctv.setMiddelContent("DoctorDetails");
        ctv.setOnClickBackListener(this);


        bean = getIntent().getExtras().getParcelable("DoctorBean");

        tv_move_name = findViewById(R.id.tv_move_name);
        tv_director = findViewById(R.id.tv_director);
        tv_writer = findViewById(R.id.tv_writer);
        rvComment = findViewById(R.id.rv_comment);
        btn_comment = findViewById(R.id.btn_comment);
        etComment = findViewById(R.id.et_comment);

        tv_move_name.setText(bean.getUsername());
        tv_director.setText(bean.getDepartments());
        tv_writer.setText(bean.getMedicInfo());

        db = FirebaseFirestore.getInstance();
        userCollection = db.collection("comment");

        selectComment(bean);

        btn_comment.setOnClickListener(v -> {
            if (!TextUtils.isEmpty(etComment.getText())) {
                RespCommentBean comment = new RespCommentBean();
                comment.setId(UUID.randomUUID().toString());
                comment.setComment_uid(ParameterInfo.userBean.getId());
                comment.setComment_doctor_id(bean.getId());
                Calendar c = Calendar.getInstance();
                c.setTimeInMillis(System.currentTimeMillis());

                int year = c.get(Calendar.YEAR);
                int month = c.get(Calendar.MONTH);

                int mHour = c.get(Calendar.HOUR_OF_DAY);
                int mMinute = c.get(Calendar.MINUTE);

                String monthS;
                if (month < 10) {
                    monthS = "0" + month;
                } else {
                    monthS = "" + month;
                }
                String hourOfDayS;
                if (mHour < 10) {
                    hourOfDayS = "0" + mHour;
                } else {
                    hourOfDayS = "" + mHour;
                }
                String minuteS;
                if (mMinute < 10) {
                    minuteS = "0" + mMinute;
                } else {
                    minuteS = "" + mMinute;
                }

                comment.setComment_date(year + "-" + monthS + " " + hourOfDayS + ":" + minuteS);
                comment.setComment_text(etComment.getText().toString());
                comment(comment);
            } else {
                Toast.makeText(UserDoctorDetailsAty.this, "Please enter a comment", Toast.LENGTH_SHORT).show();
            }
        });
    }


    private void selectComment(DoctorBean bean) {
        userCollection.
                whereEqualTo("comment_doctor_id", bean.getId())
                .get().addOnSuccessListener(queryDocumentSnapshots -> {

                    if (queryDocumentSnapshots.isEmpty()) {
                        return;
                    }
                    List<RespCommentBean> s = queryDocumentSnapshots.toObjects(RespCommentBean.class);

                    respComments.clear();
                    respComments.addAll(s);
                    if (commentAdapter == null) {
                        commentAdapter = new RvCommentAdapter(respComments);
                    }
                    rvComment.setLayoutManager(new LinearLayoutManager(UserDoctorDetailsAty.this));
                    rvComment.setAdapter(commentAdapter);
                });
    }


    private void comment(RespCommentBean comment) {
        userCollection
                .add(comment)
                .addOnSuccessListener(documentReference -> {
                    respComments.add(comment);
                    etComment.setText("");
                    if (commentAdapter != null) {
                        commentAdapter.notifyDataSetChanged();
                    } else {
                        commentAdapter = new RvCommentAdapter(respComments);
                        rvComment.setLayoutManager(new LinearLayoutManager(UserDoctorDetailsAty.this));
                        rvComment.setAdapter(commentAdapter);
                    }
                    Toast.makeText(UserDoctorDetailsAty.this, "Review success", Toast.LENGTH_SHORT).show();
                }).addOnFailureListener(e -> Log.d("TAG", "onFailure: " + e.getLocalizedMessage()));
    }

    @Override
    public void OnClickBack() {
        finish();
    }

    @Override
    public void OnClickFinch() {
        finish();
    }


}
