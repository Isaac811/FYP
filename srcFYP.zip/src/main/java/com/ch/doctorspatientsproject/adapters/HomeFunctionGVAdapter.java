package com.ch.doctorspatientsproject.adapters;


import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.ch.doctorspatientsproject.R;


public class HomeFunctionGVAdapter extends BaseAdapter {

    private Context context;


    public HomeFunctionGVAdapter(Context context) {
        this.context = context;
    }

    @Override
    public int getCount() {
        return 3;
    }

    @Override
    public Object getItem(int i) {
        return i;
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        view = View.inflate(context, R.layout.frag_home_function_gv_item_layout, null);

        ImageView imgPic = view.findViewById(R.id.homeGvImg);
        TextView txtInfo = view.findViewById(R.id.homeGvTxt);

            switch (i) {
                case 0:
                    imgPic.setImageResource(R.drawable.frag_gv_function_home_yqhy_icon);
                    txtInfo.setText("Appointment");
                    break;
                case 1:
                    imgPic.setImageResource(R.drawable.frag_gv_function_home_zxkf_icon);
                    txtInfo.setText("PhysicianSpecialist");
                    break;
                case 2:
                    imgPic.setImageResource(R.drawable.frag_gv_function_shcx_icon);
                    txtInfo.setText("Consultation");
                    break;
                default:
                    break;
            }
        return view;
    }
}
