package com.ch.doctorspatientsproject.adapters;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.ch.doctorspatientsproject.R;
import com.ch.doctorspatientsproject.UserDoctorDetailsAty;
import com.ch.doctorspatientsproject.beans.DoctorBean;

import java.util.List;

import kotlin.jvm.internal.Ref;


public class RvAppointmentDoctorAdapter extends RecyclerView.Adapter<RvAppointmentDoctorAdapter.HomeDoctorAdapterViewHolder> {

    private List<DoctorBean> myViewInfo;
    Activity activity;

    static class HomeDoctorAdapterViewHolder extends RecyclerView.ViewHolder {

        private ImageView iv_move_pic;
        private TextView tv_move_name;
        private TextView tv_director;
        private TextView tv_writer;
        private Button btnAppont;


        public HomeDoctorAdapterViewHolder(@NonNull View view) {
            super(view);
            tv_move_name = view.findViewById(R.id.tv_move_name);
            iv_move_pic = view.findViewById(R.id.iv_move_pic);
            tv_director = view.findViewById(R.id.tv_director);
            tv_writer = view.findViewById(R.id.tv_writer);
            btnAppont = view.findViewById(R.id.btn_appoint);
        }
    }

    public RvAppointmentDoctorAdapter(List<DoctorBean> viewInfoList, Activity activity) {
        myViewInfo = viewInfoList;
        this.activity = activity;
    }

    @NonNull
    @Override
    public HomeDoctorAdapterViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.aty_rcv_apponit_item_doctor, parent, false);
        HomeDoctorAdapterViewHolder holder = new HomeDoctorAdapterViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull HomeDoctorAdapterViewHolder holder, int position) {

        Log.e("fk", "getDoctor_name =" + myViewInfo.get(position).getUsername());
        holder.tv_move_name.setText(myViewInfo.get(position).getUsername());
        holder.tv_director.setText(myViewInfo.get(position).getDepartments());
        holder.tv_writer.setText(myViewInfo.get(position).getMedicInfo());


        Glide.with(holder.itemView.getContext())
                .load(R.drawable.home_doctor_patient_icon)
                .centerCrop()
                .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
                .into(holder.iv_move_pic);

        holder.btnAppont.setOnClickListener(v -> {
            if (appointmentListener != null) {
                appointmentListener.appointment(myViewInfo.get(position));
            }
        });

        holder.itemView.setOnClickListener(v -> {

            Intent intent = new Intent(activity, UserDoctorDetailsAty.class);
            Bundle bundle = new Bundle();
            bundle.putParcelable("DoctorBean", myViewInfo.get(position));
            intent.putExtras(bundle);
            activity.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return myViewInfo.size();
    }

    private AppointmentListener appointmentListener;

    public void setAppointmentListener(AppointmentListener appointmentListener) {
        this.appointmentListener = appointmentListener;
    }

    public interface AppointmentListener {
        void appointment(DoctorBean doctorBean);
    }
}
