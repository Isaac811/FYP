package com.ch.doctorspatientsproject.adapters;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.ch.doctorspatientsproject.R;
import com.ch.doctorspatientsproject.beans.DoctorBean;
import com.ch.doctorspatientsproject.beans.HospitalBean;

import java.util.List;


public class RvHospitalAdapter extends RecyclerView.Adapter<RvHospitalAdapter.HomeDoctorAdapterViewHolder> {
    private List<HospitalBean> myViewInfo;
    Activity activity;

    static class HomeDoctorAdapterViewHolder extends RecyclerView.ViewHolder {

        private ImageView iv_move_pic;
        private TextView tv_move_name;
        private TextView tv_writer;


        public HomeDoctorAdapterViewHolder(@NonNull View view) {
            super(view);
            tv_move_name = view.findViewById(R.id.tv_move_name);
            iv_move_pic = view.findViewById(R.id.iv_move_pic);
            tv_writer = view.findViewById(R.id.tv_writer);
        }
    }

    public RvHospitalAdapter(List<HospitalBean> viewInfoList, Activity activity) {
        myViewInfo = viewInfoList;
        this.activity = activity;
    }

    @NonNull
    @Override
    public HomeDoctorAdapterViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.frag_rcv_item_hospital, parent, false);
        HomeDoctorAdapterViewHolder holder = new HomeDoctorAdapterViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull HomeDoctorAdapterViewHolder holder, int position) {


        holder.iv_move_pic.setImageDrawable(activity.getDrawable(activity.getResources().getIdentifier(myViewInfo.get(position).getHospitalPic(),"drawable",activity.getPackageName())));

        holder.tv_move_name.setText(myViewInfo.get(position).getHospitalName());
        holder.tv_writer.setText(myViewInfo.get(position).getHospitalInfo());

    }

    @Override
    public int getItemCount() {
        return myViewInfo.size();
    }
}
