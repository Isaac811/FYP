package com.ch.doctorspatientsproject.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import com.ch.doctorspatientsproject.R;
import com.ch.doctorspatientsproject.beans.ConsultBean;
import com.ch.doctorspatientsproject.beans.DoctorBean;

import java.util.List;

public class ConsultAdapter extends RecyclerView.Adapter<ConsultAdapter.ViewHolder> {
    private List<ConsultBean> mList;
    private Context mContext;

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tv;
        Button bt1;

        public ViewHolder(View view) {
            super(view);
            tv = (TextView) view.findViewById(R.id.tv);
            bt1 = (Button) view.findViewById(R.id.bt1);
        }
    }

    public ConsultAdapter(List<ConsultBean> list, Context context) {
        mList = list;
        mContext = context;
    }

    public void setList(List<ConsultBean> list) {
        mList = list;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.layout_item, parent, false);
        ViewHolder holder = new ViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        ConsultBean itemBean = mList.get(position);
        holder.tv.setText(itemBean.getDoctor_name());

        holder.bt1.setText("records");
        holder.bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(mContext, "records", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return mList.size();
    }
}