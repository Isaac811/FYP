package com.ch.doctorspatientsproject.adapters;

import android.app.Activity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.ch.doctorspatientsproject.R;
import com.ch.doctorspatientsproject.beans.AppointmentBean;
import com.ch.doctorspatientsproject.beans.DoctorBean;

import java.util.List;


public class RvMedicAppointmentDoctorAdapter extends RecyclerView.Adapter<RvMedicAppointmentDoctorAdapter.HomeDoctorAdapterViewHolder> {

    private List<AppointmentBean> myViewInfo;
    Activity activity;

    static class HomeDoctorAdapterViewHolder extends RecyclerView.ViewHolder {

        private ImageView iv_move_pic;
        private TextView tv_move_name;
        private TextView tv_user_name;


        public HomeDoctorAdapterViewHolder(@NonNull View view) {
            super(view);
            tv_move_name = view.findViewById(R.id.tv_move_name);
            iv_move_pic = view.findViewById(R.id.iv_move_pic);
            tv_user_name = view.findViewById(R.id.tv_user_name);
        }
    }

    public RvMedicAppointmentDoctorAdapter(List<AppointmentBean> viewInfoList, Activity activity) {
        myViewInfo = viewInfoList;
        this.activity = activity;
    }

    @NonNull
    @Override
    public HomeDoctorAdapterViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.aty_rcv_medic_apponit_item_doctor, parent, false);
        HomeDoctorAdapterViewHolder holder = new HomeDoctorAdapterViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull HomeDoctorAdapterViewHolder holder, int position) {


        holder.tv_user_name.setText("patient: "+myViewInfo.get(position).getUser_name());
        holder.tv_move_name.setText(" doctor: "+myViewInfo.get(position).getDoctor_name());

        Glide.with(holder.itemView.getContext())
                .load(R.drawable.home_doctor_patient_icon)
                .centerCrop()
                .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
                .into(holder.iv_move_pic);

    }

    @Override
    public int getItemCount() {
        return myViewInfo.size();
    }
}
