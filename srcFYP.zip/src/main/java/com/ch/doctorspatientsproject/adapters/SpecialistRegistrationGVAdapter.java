package com.ch.doctorspatientsproject.adapters;


import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.ch.doctorspatientsproject.R;


public class SpecialistRegistrationGVAdapter extends BaseAdapter {

    private Context context;

    public SpecialistRegistrationGVAdapter(Context context) {
        this.context = context;
    }

    @Override
    public int getCount() {
        return 10;
    }

    @Override
    public Object getItem(int i) {
        return i;
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        view = View.inflate(context, R.layout.aty_specialist_reg_gv_item_layout, null);

        ImageView imgPic = view.findViewById(R.id.homeGvImg);
        TextView txtInfo = view.findViewById(R.id.homeGvTxt);

        switch (i) {
            case 0:
                imgPic.setImageResource(R.drawable.pf_departments);
                txtInfo.setText("dermatology");
                break;
            case 1:
                imgPic.setImageResource(R.drawable.yanke_departments);
                txtInfo.setText("ophthalmology");
                break;
            case 2:
                imgPic.setImageResource(R.drawable.yanke_departments);
                txtInfo.setText("otolaryngology");
                break;
            case 3:
                imgPic.setImageResource(R.drawable.ebihou_departments);
                txtInfo.setText("stomatology");
                break;
            case 4:
                imgPic.setImageResource(R.drawable.kouqian_departments);
                txtInfo.setText("neurology");
                break;
            case 5:
                imgPic.setImageResource(R.drawable.sj_departments);
                txtInfo.setText("pediatric");
                break;
            case 6:
                imgPic.setImageResource(R.drawable.er_departments);
                txtInfo.setText("gynecology");
                break;
            case 7:
                imgPic.setImageResource(R.drawable.fu_departments);
                txtInfo.setText("Cardiology");
                break;
            case 8:
                imgPic.setImageResource(R.drawable.xn_departments);
                txtInfo.setText("psychiatry");
                break;
            case 9:
                imgPic.setImageResource(R.drawable.js_departments);
                txtInfo.setText("emergency");
                break;
            default:
                break;
        }
        return view;
    }
}
