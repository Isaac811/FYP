package com.ch.doctorspatientsproject.adapters;

import android.app.Activity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.ch.doctorspatientsproject.R;
import com.ch.doctorspatientsproject.beans.AppointmentBean;
import com.ch.doctorspatientsproject.beans.DoctorBean;

import java.util.List;


public class RvMyAppointmentDoctorAdapter extends RecyclerView.Adapter<RvMyAppointmentDoctorAdapter.HomeDoctorAdapterViewHolder> {

    private List<AppointmentBean> myViewInfo;
    Activity activity;

    static class HomeDoctorAdapterViewHolder extends RecyclerView.ViewHolder {

        private ImageView iv_move_pic;
        private TextView tv_move_name;
        private TextView tv_director;
        private TextView tv_writer;
        private Button btnAppont;


        public HomeDoctorAdapterViewHolder(@NonNull View view) {
            super(view);
            tv_move_name = view.findViewById(R.id.tv_move_name);
            iv_move_pic = view.findViewById(R.id.iv_move_pic);
            tv_director = view.findViewById(R.id.tv_director);
            tv_writer = view.findViewById(R.id.tv_writer);
            btnAppont = view.findViewById(R.id.btn_appoint);
        }
    }

    public RvMyAppointmentDoctorAdapter(List<AppointmentBean> viewInfoList, Activity activity) {
        myViewInfo = viewInfoList;
        this.activity = activity;
    }

    @NonNull
    @Override
    public HomeDoctorAdapterViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.aty_rcv_my_apponit_item_doctor, parent, false);
        HomeDoctorAdapterViewHolder holder = new HomeDoctorAdapterViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull HomeDoctorAdapterViewHolder holder, int position) {

        holder.tv_move_name.setText(myViewInfo.get(position).getDoctor_name());
        holder.tv_director.setText(myViewInfo.get(position).getAppoint_date() + "-" + myViewInfo.get(position).getAppoint_time());
        holder.tv_writer.setText(myViewInfo.get(position).getAppoint_remark());


        Glide.with(holder.itemView.getContext())
                .load(R.drawable.home_doctor_patient_icon)
                .centerCrop()
                .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
                .into(holder.iv_move_pic);

        holder.btnAppont.setOnClickListener(v -> {

            if (caseListener != null) {
                caseListener.selcase(myViewInfo.get(position));
            }
        });
    }

    @Override
    public int getItemCount() {
        return myViewInfo.size();
    }

    private CaseListener caseListener;

    public void setAppointmentListener(CaseListener caseListener) {
        this.caseListener = caseListener;
    }

    public interface CaseListener {
        void selcase(AppointmentBean bean);
    }
}
