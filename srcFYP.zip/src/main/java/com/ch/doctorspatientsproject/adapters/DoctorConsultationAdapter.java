package com.ch.doctorspatientsproject.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.ch.doctorspatientsproject.ChatActivity;
import com.ch.doctorspatientsproject.ParameterInfo;
import com.ch.doctorspatientsproject.R;
import com.ch.doctorspatientsproject.beans.ChatRoom;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.List;
import java.util.UUID;

public class DoctorConsultationAdapter extends RecyclerView.Adapter<DoctorConsultationAdapter.ViewHolder> {
    private List<ChatRoom> mList;

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tv;
        Button bt1;

        public ViewHolder(View view) {
            super(view);
            tv = view.findViewById(R.id.tv);
            bt1 = view.findViewById(R.id.bt1);
        }
    }

    public DoctorConsultationAdapter(List<ChatRoom> list, Context context) {
        mList = list;
    }

    public void setList(List<ChatRoom> list) {
        mList = list;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.consultation_item, parent, false);
        ViewHolder holder = new ViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        ChatRoom itemBean = mList.get(position);
        holder.tv.setText(itemBean.getDocId());

        holder.bt1.setOnClickListener(view -> {
            Context context = view.getContext();
            FirebaseFirestore instance = FirebaseFirestore.getInstance();

            String docId = ParameterInfo.userBean.getUsername();
            String userId = itemBean.getUserId();


            instance.collection("chatRoom")
                    .whereEqualTo("docId", docId)
                    .whereEqualTo("userId", userId)
                    .get()
                    .addOnSuccessListener(queryDocumentSnapshots -> {
                        if (queryDocumentSnapshots.size() > 0) {
                            List<ChatRoom> chatRooms = queryDocumentSnapshots.toObjects(ChatRoom.class);
                            Intent intent = new Intent(context, ChatActivity.class);
                            intent.putExtra("chatRoomId", chatRooms.get(0).getId());
                            context.startActivity(intent);
                        } else {
                            ChatRoom chatRoom = new ChatRoom();
                            chatRoom.setUserId(userId);
                            chatRoom.setDocId(docId);
                            chatRoom.setId(UUID.randomUUID().toString());
                            instance
                                    .collection("chatRoom").
                                    add(chatRoom)
                                    .addOnSuccessListener(documentReference ->
                                            context.startActivity(
                                                    new Intent(context, ChatActivity.class)
                                                            .putExtra("chatRoomId", chatRoom.getId())));
                        }
                    });
        });
    }

    @Override
    public int getItemCount() {
        return mList.size();
    }
}