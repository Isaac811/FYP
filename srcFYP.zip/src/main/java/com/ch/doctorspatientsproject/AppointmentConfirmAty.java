package com.ch.doctorspatientsproject;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.ch.doctorspatientsproject.adapters.RvMyAppointmentUserAdapter;
import com.ch.doctorspatientsproject.beans.AppointDateBean;
import com.ch.doctorspatientsproject.beans.AppointmentBean;
import com.ch.doctorspatientsproject.widget.StatusBarCommonTitleWidget;
import com.google.common.io.BaseEncoding;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AppointmentConfirmAty extends AppCompatActivity implements StatusBarCommonTitleWidget.OnClickBackListener {

    private FirebaseFirestore db;
    private CollectionReference userCollection;

    private StatusBarCommonTitleWidget ctv;

    private TextView tvDate;
    private TextView tvDoctor;
    private Spinner spAppointDate;
    private AppointDateBean appointDoctorDate;
    private EditText etRemark;
    private EditText et_temp;
    private Button btnAppointment;

    List<AppointDateBean> appointDateBeans;
    private AppointmentBean bean;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.aty_appointment_confirm_layout);

        ctv = findViewById(R.id.cvTilteCustom);
        ctv.isHiddenCloseBtn();
        ctv.setLeftContent("");
        ctv.setMiddelContent("Appointment Confirm");
        ctv.setOnClickBackListener(this);


        bean = getIntent().getExtras().getParcelable("doctor");

        db = FirebaseFirestore.getInstance();
        userCollection = db.collection("_user");

        tvDate = findViewById(R.id.tv_date);
        Date currentDate = new Date();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String formattedDate = dateFormat.format(currentDate);
        tvDate.setText("Date：" + formattedDate);

        tvDoctor = findViewById(R.id.tv_doctor);
        tvDoctor.setText("Doctor：" + bean.getDoctor_name());
        spAppointDate = findViewById(R.id.sp_appoint_date);
        getDoctorAppointDate();
        spAppointDate.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                appointDoctorDate = appointDateBeans.get(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        etRemark = findViewById(R.id.et_remark);
        et_temp = findViewById(R.id.et_temp);
        btnAppointment = findViewById(R.id.btn_appointment);
        btnAppointment.setOnClickListener(v -> {

            if (appointDoctorDate != null
                    &&
                    !TextUtils.isEmpty(appointDoctorDate.getDoctor_date())
                    && !TextUtils.isEmpty(et_temp.getText())) {


                bean.setAppoint_date(tvDate.getText().toString().substring(5));
                bean.setAppoint_time(appointDoctorDate.getDoctor_date());
                bean.setIs_complete("false");
                bean.setInquiry("");
                bean.setUserTemp(et_temp.getText().toString());
                if (!TextUtils.isEmpty(etRemark.getText())) {
                    bean.setAppoint_remark(etRemark.getText().toString());
                }
                db.collection("appointment")
                        .add(bean)
                        .addOnSuccessListener(documentReference -> {
                            updateAppointDate();
                        }).addOnFailureListener(e -> Log.d("TAG", "onFailure: " + e.getLocalizedMessage()));
            } else {
                Toast.makeText(AppointmentConfirmAty.this,
                        "Please enter your date!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void getDoctorAppointDate() {
        db.collection("doctor_appoint_date")
                .whereEqualTo("doctor_id", bean.getDoctor_id())
                .whereEqualTo("is_appoint", "false")
                .get().addOnSuccessListener(queryDocumentSnapshots -> {

                    if (queryDocumentSnapshots.isEmpty()) {
                        return;
                    }

                    appointDateBeans = queryDocumentSnapshots.toObjects(AppointDateBean.class);
                    spAppointDate.setAdapter(new BaseAdapter() {
                        @Override
                        public int getCount() {
                            return appointDateBeans.size();
                        }

                        @Override
                        public Object getItem(int position) {
                            return appointDateBeans.get(position);
                        }

                        @Override
                        public long getItemId(int position) {
                            return position;
                        }

                        @Override
                        public View getView(int position, View convertView, ViewGroup parent) {
                            convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.aty_appoint_date, parent, false
                            );

                            TextView tv_appoint_date = convertView.findViewById(R.id.tv_appoint_date);
                            tv_appoint_date.setText(appointDateBeans.get(position).getDoctor_date() + " bookable");
                            return convertView;
                        }
                    });
                });
    }

    private void updateAppointDate() {
        db.collection("doctor_appoint_date")
                .whereEqualTo("date_id", appointDoctorDate.getDate_id())
                .get()
                .addOnSuccessListener(documentReference -> {
                    Log.e("fk", "size=" + documentReference.getDocuments().size());
                    documentReference
                            .getDocuments()
                            .forEach(documentSnapshot -> {
                                Map<String, Object> user = new HashMap<>();
                                user.put("is_appoint", "true");
                                documentSnapshot
                                        .getReference()
                                        .update(user)
                                        .addOnSuccessListener(unused -> {
                                            Toast.makeText(AppointmentConfirmAty.this, "Appointment Success", Toast.LENGTH_SHORT).show();
                                            finish();
                                        }).addOnFailureListener(e -> {
                                            Toast.makeText(AppointmentConfirmAty.this, "Appointment onFailure", Toast.LENGTH_SHORT).show();
                                            finish();
                                        });
                            });

                }).addOnFailureListener(e -> Log.d("TAG", "onFailure: " + e.getLocalizedMessage()));
    }

    @Override
    public void OnClickBack() {
        finish();
    }

    @Override
    public void OnClickFinch() {
        finish();
    }
}
