package com.ch.doctorspatientsproject;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.ch.doctorspatientsproject.adapters.RvAppointmentDoctorAdapter;
import com.ch.doctorspatientsproject.beans.AppointmentBean;
import com.ch.doctorspatientsproject.beans.DoctorBean;
import com.ch.doctorspatientsproject.dialog.CustomDialog;
import com.ch.doctorspatientsproject.widget.StatusBarCommonTitleWidget;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.Collections;
import java.util.List;
import java.util.UUID;


public class SpecialistAppointmentAty extends AppCompatActivity implements StatusBarCommonTitleWidget.OnClickBackListener, RvAppointmentDoctorAdapter.AppointmentListener, CustomDialog.CustomDialogListener {

    private FirebaseFirestore db;
    private CollectionReference userCollection;

    private StatusBarCommonTitleWidget ctv;
    private RecyclerView rcv;
    private RvAppointmentDoctorAdapter adapter;

    private String departments = "";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.aty_appointment_layout);

        db = FirebaseFirestore.getInstance();
        userCollection = db.collection("_user");

        ctv = findViewById(R.id.cvTilteCustom);
        ctv.isHiddenCloseBtn();
        ctv.setLeftContent("");
        ctv.setMiddelContent("SpecialistAppointment");
        ctv.setOnClickBackListener(this);

        rcv = findViewById(R.id.rv_appointment);

        int departmentsId = getIntent().getIntExtra("departments", -1);
        switch (departmentsId) {
            case 0:
                departments = "dermatology-department";
                break;
            case 1:
                departments = "ophthalmology-department";
                break;
            case 2:
                departments = "otolaryngology-department";
                break;
            case 3:
                departments = "stomatology-department";
                break;
            case 4:
                departments = "neurology-department";
                break;
            case 5:
                departments = "pediatric-department";
                break;
            case 6:
                departments = "gynecology-department";
                break;
            case 7:
                departments = "cardiology-department";
                break;
            case 8:
                departments = "psychiatry-department";
                break;
            case 9:
                departments = "emergency-department";
                break;
            default:
                break;
        }
        userCollection
                .whereEqualTo("role", "medic")
                .whereEqualTo("departments", departments)
                .get().addOnSuccessListener(queryDocumentSnapshots -> {

                    Log.e("fk", "queryDocumentSnapshots " + queryDocumentSnapshots.isEmpty());
                    if (queryDocumentSnapshots.isEmpty()) {
                        return;
                    }
                    List<DoctorBean> doctorBeans = queryDocumentSnapshots.toObjects(DoctorBean.class);

                    Log.e("fk", "queryDocumentSnapshots " + doctorBeans.size());

                    if (adapter == null) {
                        adapter = new RvAppointmentDoctorAdapter(doctorBeans, SpecialistAppointmentAty.this);
                        adapter.setAppointmentListener(SpecialistAppointmentAty.this);
                        rcv.setLayoutManager(new LinearLayoutManager(SpecialistAppointmentAty.this));
                        rcv.setAdapter(adapter);
                    } else {
                        adapter.notifyDataSetChanged();
                    }
                });
    }

    DoctorBean doctorBean;

    @Override
    public void appointment(DoctorBean doctorBean) {
        this.doctorBean = doctorBean;
        appointCount(doctorBean);


    }

    private void appointCount(DoctorBean doctorBean) {
        db
                .collection("appointment")
                .whereEqualTo("doctor_id", doctorBean.getId())
                .get().addOnSuccessListener(queryDocumentSnapshots -> {
                    Log.e("fk", "queryDocumentSnapshots " + queryDocumentSnapshots.isEmpty());
                    if (queryDocumentSnapshots.isEmpty()) {
                        Toast.makeText(SpecialistAppointmentAty.this, "No one is booked", Toast.LENGTH_SHORT).show();
                        Ok();
                        return;
                    }
                    List<AppointmentBean> doctorBeans = queryDocumentSnapshots.toObjects(AppointmentBean.class);
                    Collections.reverse(doctorBeans);
                    Log.e("fk", "queryDocumentSnapshots " + doctorBeans.size());

                    CustomDialog customDialog = new CustomDialog(SpecialistAppointmentAty.this);
                    customDialog.setDialogListener(this);
                    customDialog.setContext(doctorBeans);
                    customDialog.show();

                });
    }

    @Override
    public void Ok() {
        AppointmentBean bean = new AppointmentBean();
        bean.setAppoint_id(UUID.randomUUID().toString());
        bean.setDoctor_id(doctorBean.getId());
        bean.setDoctor_name(doctorBean.getUsername());
        bean.setUser_id(ParameterInfo.userBean.getId());
        bean.setUser_name(ParameterInfo.userBean.getUsername());

        Intent intent = new Intent(SpecialistAppointmentAty.this, AppointmentConfirmAty.class);
        Bundle bundle = new Bundle();
        bundle.putParcelable("doctor", bean);
        intent.putExtras(bundle);
        startActivity(intent);
    }

    @Override
    public void OnClickBack() {
        finish();
    }

    @Override
    public void OnClickFinch() {
        finish();
    }


}
