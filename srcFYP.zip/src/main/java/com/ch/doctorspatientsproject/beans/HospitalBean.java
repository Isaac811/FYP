package com.ch.doctorspatientsproject.beans;

public class HospitalBean {

    private String hospitalName;
    private String hospitalInfo;
    private String hospitalPic;

    public String getHospitalName() {
        return hospitalName;
    }

    public void setHospitalName(String hospitalName) {
        this.hospitalName = hospitalName;
    }

    public String getHospitalInfo() {
        return hospitalInfo;
    }

    public void setHospitalInfo(String hospitalInfo) {
        this.hospitalInfo = hospitalInfo;
    }

    public String getHospitalPic() {
        return hospitalPic;
    }

    public void setHospitalPic(String hospitalPic) {
        this.hospitalPic = hospitalPic;
    }
}
