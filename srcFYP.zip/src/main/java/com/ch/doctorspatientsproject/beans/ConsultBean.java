package com.ch.doctorspatientsproject.beans;

public class ConsultBean {

    private String doctor_name;

    public ConsultBean(String doctor_name) {
        this.doctor_name = doctor_name;
    }

    @Override
    public String toString() {
        return "DoctorBean{" +
                "doctor_name='" + doctor_name + '\'' +
                '}';
    }

    public String getDoctor_name() {
        return doctor_name;
    }

    public void setDoctor_name(String doctor_name) {
        this.doctor_name = doctor_name;
    }
}
