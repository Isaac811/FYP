package com.ch.doctorspatientsproject.beans;

import android.os.Parcel;
import android.os.Parcelable;

public class DoctorBean implements Parcelable {

    private String id;
    private String username;
    private String departments;
    private String medicInfo;


    public DoctorBean() {
    }

    public DoctorBean(String username) {
        this.username = username;
    }


    @Override
    public String toString() {
        return "DoctorBean{" +
                "id='" + id + '\'' +
                ", username='" + username + '\'' +
                ", departments='" + departments + '\'' +
                ", medicInfo='" + medicInfo + '\'' +
                '}';
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getDepartments() {
        return departments;
    }

    public void setDepartments(String departments) {
        this.departments = departments;
    }

    public String getMedicInfo() {
        return medicInfo;
    }

    public void setMedicInfo(String medicInfo) {
        this.medicInfo = medicInfo;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.id);
        dest.writeString(this.username);
        dest.writeString(this.departments);
        dest.writeString(this.medicInfo);
    }

    public void readFromParcel(Parcel source) {
        this.id = source.readString();
        this.username = source.readString();
        this.departments = source.readString();
        this.medicInfo = source.readString();
    }

    protected DoctorBean(Parcel in) {
        this.id = in.readString();
        this.username = in.readString();
        this.departments = in.readString();
        this.medicInfo = in.readString();
    }

    public static final Parcelable.Creator<DoctorBean> CREATOR = new Parcelable.Creator<DoctorBean>() {
        @Override
        public DoctorBean createFromParcel(Parcel source) {
            return new DoctorBean(source);
        }

        @Override
        public DoctorBean[] newArray(int size) {
            return new DoctorBean[size];
        }
    };
}
