package com.ch.doctorspatientsproject.beans;

import android.os.Parcel;
import android.os.Parcelable;

public class AppointmentBean implements Parcelable {
    private String appoint_id;
    private String doctor_id;
    private String doctor_name;
    private String user_id;
    private String user_name;

    private String appoint_date;
    private String appoint_time;
    private String appoint_remark;
    private String inquiry;
    private String prescribe;
    private String is_complete;
    private String userTemp;

    private String prescribeDate;
    private String prescribeDosage;
    private String prescribeIns;


    public String getAppoint_id() {
        return appoint_id;
    }

    public void setAppoint_id(String appoint_id) {
        this.appoint_id = appoint_id;
    }

    public String getDoctor_id() {
        return doctor_id;
    }

    public void setDoctor_id(String doctor_id) {
        this.doctor_id = doctor_id;
    }

    public String getDoctor_name() {
        return doctor_name;
    }

    public void setDoctor_name(String doctor_name) {
        this.doctor_name = doctor_name;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getUser_name() {
        return user_name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public String getAppoint_date() {
        return appoint_date;
    }

    public void setAppoint_date(String appoint_date) {
        this.appoint_date = appoint_date;
    }

    public String getAppoint_time() {
        return appoint_time;
    }

    public void setAppoint_time(String appoint_time) {
        this.appoint_time = appoint_time;
    }

    public String getAppoint_remark() {
        return appoint_remark;
    }

    public void setAppoint_remark(String appoint_remark) {
        this.appoint_remark = appoint_remark;
    }

    public String getInquiry() {
        return inquiry;
    }

    public void setInquiry(String inquiry) {
        this.inquiry = inquiry;
    }

    public String getPrescribe() {
        return prescribe;
    }

    public void setPrescribe(String prescribe) {
        this.prescribe = prescribe;
    }

    public String getIs_complete() {
        return is_complete;
    }

    public void setIs_complete(String is_complete) {
        this.is_complete = is_complete;
    }


    public String getUserTemp() {
        return userTemp;
    }

    public void setUserTemp(String userTemp) {
        this.userTemp = userTemp;
    }


    public String getPrescribeDate() {
        return prescribeDate;
    }

    public void setPrescribeDate(String prescribeDate) {
        this.prescribeDate = prescribeDate;
    }

    public String getPrescribeDosage() {
        return prescribeDosage;
    }

    public void setPrescribeDosage(String prescribeDosage) {
        this.prescribeDosage = prescribeDosage;
    }

    public String getPrescribeIns() {
        return prescribeIns;
    }

    public void setPrescribeIns(String prescribeIns) {
        this.prescribeIns = prescribeIns;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.appoint_id);
        dest.writeString(this.doctor_id);
        dest.writeString(this.doctor_name);
        dest.writeString(this.user_id);
        dest.writeString(this.user_name);
        dest.writeString(this.appoint_date);
        dest.writeString(this.appoint_time);
        dest.writeString(this.appoint_remark);
        dest.writeString(this.inquiry);
        dest.writeString(this.prescribe);
        dest.writeString(this.is_complete);
        dest.writeString(this.userTemp);
        dest.writeString(this.prescribeDate);
        dest.writeString(this.prescribeDosage);
        dest.writeString(this.prescribeIns);
    }

    public void readFromParcel(Parcel source) {
        this.appoint_id = source.readString();
        this.doctor_id = source.readString();
        this.doctor_name = source.readString();
        this.user_id = source.readString();
        this.user_name = source.readString();
        this.appoint_date = source.readString();
        this.appoint_time = source.readString();
        this.appoint_remark = source.readString();
        this.inquiry = source.readString();
        this.prescribe = source.readString();
        this.is_complete = source.readString();
        this.userTemp = source.readString();
        this.prescribeDate = source.readString();
        this.prescribeDosage = source.readString();
        this.prescribeIns = source.readString();
    }

    public AppointmentBean() {
    }

    protected AppointmentBean(Parcel in) {
        this.appoint_id = in.readString();
        this.doctor_id = in.readString();
        this.doctor_name = in.readString();
        this.user_id = in.readString();
        this.user_name = in.readString();
        this.appoint_date = in.readString();
        this.appoint_time = in.readString();
        this.appoint_remark = in.readString();
        this.inquiry = in.readString();
        this.prescribe = in.readString();
        this.is_complete = in.readString();
        this.userTemp = in.readString();
        this.prescribeDate = in.readString();
        this.prescribeDosage = in.readString();
        this.prescribeIns = in.readString();
    }

    public static final Creator<AppointmentBean> CREATOR = new Creator<AppointmentBean>() {
        @Override
        public AppointmentBean createFromParcel(Parcel source) {
            return new AppointmentBean(source);
        }

        @Override
        public AppointmentBean[] newArray(int size) {
            return new AppointmentBean[size];
        }
    };
}
