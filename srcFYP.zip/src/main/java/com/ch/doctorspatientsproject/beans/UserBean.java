package com.ch.doctorspatientsproject.beans;

public class UserBean {

    private String id;
    private String username;
    private String password;
    private String role;
    private String departments;
    private String medicInfo;

    public void setRole(String role) {
        this.role = role;
    }

    public String getRole() {
        return role;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getDepartments() {
        return departments;
    }

    public void setDepartments(String departments) {
        this.departments = departments;
    }

    public String getMedicInfo() {
        return medicInfo;
    }

    public void setMedicInfo(String medicInfo) {
        this.medicInfo = medicInfo;
    }
}
